"""
CoinDCX Algo — Enhanced Backtesting Engine
==========================================
EXTENDS: backtesting/engine.py

Adds:
  - pandas-based vectorized metrics computation
  - Monthly returns heatmap data
  - Trade markers for price chart overlay
  - Walk-forward validation
  - Drawdown series
  - Pre-built demo strategies with seeded results

Requires: pandas, numpy (no ta-lib)
"""
from __future__ import annotations

import math
import random
import time
from dataclasses import dataclass, field
from typing import Optional

import numpy as np

try:
    import pandas as pd
    PANDAS_AVAILABLE = True
except ImportError:
    PANDAS_AVAILABLE = False


# ─────────────────────────────────────────────────────────────────────────────
# Rich performance metrics (extends existing PerformanceMetrics)
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class RichMetrics:
    """Full metrics suite for backtest results display."""

    # Core
    total_return_pct:      float = 0.0
    annualized_return_pct: float = 0.0
    sharpe_ratio:          float = 0.0
    sortino_ratio:         float = 0.0
    calmar_ratio:          float = 0.0
    max_drawdown_pct:      float = 0.0
    avg_drawdown_pct:      float = 0.0
    win_rate_pct:          float = 0.0
    profit_factor:         float = 0.0
    total_trades:          int   = 0
    winning_trades:        int   = 0
    losing_trades:         int   = 0
    avg_win:               float = 0.0
    avg_loss:              float = 0.0
    best_trade:            float = 0.0
    worst_trade:           float = 0.0
    avg_hold_hours:        float = 0.0
    total_fees_paid:       float = 0.0

    # Series (for charts)
    equity_curve:      list = field(default_factory=list)   # [[ts, value], ...]
    drawdown_series:   list = field(default_factory=list)   # [[ts, dd_pct], ...]
    monthly_returns:   list = field(default_factory=list)   # [{"month": "Jan-24", "return": 4.2}, ...]
    trade_markers:     list = field(default_factory=list)   # buy/sell markers on price chart
    price_series:      list = field(default_factory=list)   # [[ts, price], ...]

    def to_dict(self) -> dict:
        return {
            "metrics": {
                "total_return_pct":      round(self.total_return_pct, 4),
                "annualized_return_pct": round(self.annualized_return_pct, 4),
                "sharpe_ratio":          round(self.sharpe_ratio, 4),
                "sortino_ratio":         round(self.sortino_ratio, 4),
                "calmar_ratio":          round(self.calmar_ratio, 4),
                "max_drawdown_pct":      round(self.max_drawdown_pct, 4),
                "avg_drawdown_pct":      round(self.avg_drawdown_pct, 4),
                "win_rate_pct":          round(self.win_rate_pct, 2),
                "profit_factor":         round(self.profit_factor, 4),
                "total_trades":          self.total_trades,
                "winning_trades":        self.winning_trades,
                "losing_trades":         self.losing_trades,
                "avg_win":               round(self.avg_win, 4),
                "avg_loss":              round(self.avg_loss, 4),
                "best_trade":            round(self.best_trade, 4),
                "worst_trade":           round(self.worst_trade, 4),
                "avg_hold_hours":        round(self.avg_hold_hours, 2),
                "total_fees_paid":       round(self.total_fees_paid, 4),
            },
            "equity_curve":    self.equity_curve,
            "drawdown_series": self.drawdown_series,
            "monthly_returns": self.monthly_returns,
            "trade_markers":   self.trade_markers,
            "price_series":    self.price_series,
        }


# ─────────────────────────────────────────────────────────────────────────────
# Metrics Calculator
# ─────────────────────────────────────────────────────────────────────────────

class MetricsCalculator:
    """
    Computes comprehensive performance metrics from equity curve + trades.
    Uses pandas when available, pure Python otherwise.
    """

    @staticmethod
    def compute(
        equity_curve: list[tuple],   # [(timestamp_ms, value), ...]
        trades: list[dict],          # from backtest engine
        initial_capital: float,
        price_series: list[tuple],   # [(timestamp_ms, close), ...]
        fee_rate: float = 0.001,
    ) -> RichMetrics:
        m = RichMetrics()

        if not equity_curve or len(equity_curve) < 2:
            return m

        values = [v for _, v in equity_curve]
        times  = [t for t, _ in equity_curve]

        # ── Returns ──────────────────────────────────────────────────────────
        m.total_return_pct = (values[-1] - values[0]) / values[0] * 100

        # Duration in years
        duration_ms = times[-1] - times[0]
        duration_y  = max(duration_ms / (365.25 * 24 * 3600 * 1000), 1/365)
        if duration_y > 0 and values[0] > 0:
            m.annualized_return_pct = ((values[-1] / values[0]) ** (1 / duration_y) - 1) * 100

        # ── Drawdown series ───────────────────────────────────────────────────
        peak = values[0]
        dd_series = []
        drawdowns = []
        for ts, v in zip(times, values):
            peak = max(peak, v)
            dd = (v - peak) / peak * 100 if peak > 0 else 0
            dd_series.append([ts, round(dd, 4)])
            if dd < 0:
                drawdowns.append(dd)

        m.drawdown_series   = dd_series
        m.max_drawdown_pct  = min(drawdowns) if drawdowns else 0
        m.avg_drawdown_pct  = sum(drawdowns) / len(drawdowns) if drawdowns else 0

        # ── Sharpe / Sortino ─────────────────────────────────────────────────
        if len(values) > 1:
            returns = [(values[i] - values[i-1]) / values[i-1]
                       for i in range(1, len(values))]
            mean_r  = sum(returns) / len(returns)
            std_r   = math.sqrt(sum((r - mean_r)**2 for r in returns) / max(len(returns)-1, 1))
            neg_r   = [r for r in returns if r < 0]
            down_std = math.sqrt(sum(r**2 for r in neg_r) / max(len(neg_r)-1, 1)) if neg_r else std_r

            # Annualise (assume returns are per-bar)
            bars_per_year = max(len(values), 1)
            ann_factor = math.sqrt(bars_per_year)
            rf_annual  = 0.05  # 5% risk-free rate
            rf_per_bar = rf_annual / bars_per_year

            m.sharpe_ratio  = ((mean_r - rf_per_bar) / std_r * ann_factor) if std_r > 0 else 0
            m.sortino_ratio = ((mean_r - rf_per_bar) / down_std * ann_factor) if down_std > 0 else 0

        # ── Calmar ───────────────────────────────────────────────────────────
        if m.max_drawdown_pct < 0:
            m.calmar_ratio = m.annualized_return_pct / abs(m.max_drawdown_pct)

        # ── Trade metrics ─────────────────────────────────────────────────────
        if trades:
            pnls = [t.get("net_pnl", t.get("pnl", 0)) for t in trades
                    if t.get("net_pnl", t.get("pnl", 0)) != 0]
            wins  = [p for p in pnls if p > 0]
            loses = [p for p in pnls if p < 0]

            m.total_trades   = len(pnls)
            m.winning_trades = len(wins)
            m.losing_trades  = len(loses)
            m.win_rate_pct   = len(wins) / len(pnls) * 100 if pnls else 0
            m.avg_win        = sum(wins) / len(wins) if wins else 0
            m.avg_loss       = sum(loses) / len(loses) if loses else 0
            m.best_trade     = max(pnls) if pnls else 0
            m.worst_trade    = min(pnls) if pnls else 0
            m.profit_factor  = (sum(wins) / abs(sum(loses))) if loses and sum(loses) != 0 else 0
            m.total_fees_paid = sum(
                t.get("fee", t.get("quantity", 0) * t.get("fill_price", t.get("entry_price", 0)) * fee_rate)
                for t in trades
            )

        # ── Monthly returns ──────────────────────────────────────────────────
        m.monthly_returns = MetricsCalculator._compute_monthly(equity_curve)

        # ── Trade markers ────────────────────────────────────────────────────
        m.trade_markers = MetricsCalculator._compute_markers(trades)

        # ── Store series ─────────────────────────────────────────────────────
        m.equity_curve  = [[t, round(v, 2)] for t, v in equity_curve]
        m.price_series  = [[t, round(p, 2)] for t, p in price_series] if price_series else []

        return m

    @staticmethod
    def _compute_monthly(equity_curve: list[tuple]) -> list[dict]:
        """Compute monthly return breakdown."""
        if not equity_curve or len(equity_curve) < 2:
            return []

        # Group by month
        months: dict[str, list[float]] = {}
        for ts_ms, val in equity_curve:
            ts = ts_ms / 1000
            import time as t
            dt = t.gmtime(ts)
            key = f"{dt.tm_year}-{dt.tm_mon:02d}"
            months.setdefault(key, []).append(val)

        MONTH_NAMES = ["Jan","Feb","Mar","Apr","May","Jun",
                       "Jul","Aug","Sep","Oct","Nov","Dec"]
        result = []
        prev_last = None
        for key in sorted(months.keys()):
            vals = months[key]
            if prev_last is not None and vals:
                ret = (vals[-1] - prev_last) / prev_last * 100
            else:
                ret = 0.0
            y, m = key.split("-")
            result.append({
                "month": f"{MONTH_NAMES[int(m)-1]} {y}",
                "key": key,
                "return_pct": round(ret, 2),
            })
            if vals:
                prev_last = vals[-1]

        return result

    @staticmethod
    def _compute_markers(trades: list[dict]) -> list[dict]:
        """Convert trades to chart markers (buy/sell overlays on price chart)."""
        markers = []
        for t in trades:
            # Handle both backtest trade format and paper trade format
            entry_ts = t.get("entry_ts_ms", t.get("fill_time_ms", t.get("time_ms", 0)))
            exit_ts  = t.get("exit_ts_ms",  0)
            entry_p  = t.get("entry_price", t.get("fill_price", t.get("price", 0)))
            exit_p   = t.get("exit_price",  0)
            side     = t.get("side", "BUY")
            pnl      = t.get("net_pnl", t.get("pnl", 0))

            if entry_ts and entry_p:
                markers.append({
                    "type": "entry",
                    "side": side,
                    "timestamp_ms": int(entry_ts),
                    "price": float(entry_p),
                    "pnl": float(pnl),
                    "color": "#00D4AA" if side == "BUY" else "#FF3D57",
                })
            if exit_ts and exit_p:
                markers.append({
                    "type": "exit",
                    "side": "SELL" if side == "BUY" else "BUY",
                    "timestamp_ms": int(exit_ts),
                    "price": float(exit_p),
                    "pnl": float(pnl),
                    "color": "#FF6B35",
                })
        return markers


# ─────────────────────────────────────────────────────────────────────────────
# Demo Strategy Results Generator
# ─────────────────────────────────────────────────────────────────────────────

class DemoResultsGenerator:
    """
    Generates realistic-looking pre-seeded backtest results for demo purposes.
    Used by the /api/v1/demo/seed endpoint to populate the UI.
    """

    @staticmethod
    def generate(
        strategy_name: str = "EMA Crossover",
        symbol: str        = "BTC",
        initial_capital:  float = 100_000.0,
        n_bars: int        = 365,
        target_return_pct: float = 28.4,
        seed: int          = 42,
    ) -> dict:
        random.seed(seed)
        np.random.seed(seed)

        # Generate equity curve
        daily_ret = target_return_pct / 100 / n_bars
        vol       = 0.015
        equity    = [initial_capital]
        now_ms    = int(time.time() * 1000)
        bar_ms    = 3600 * 1000  # 1h bars

        for i in range(n_bars):
            r = random.gauss(daily_ret, vol)
            equity.append(max(equity[-1] * (1 + r), initial_capital * 0.5))

        times  = [now_ms - (n_bars - i) * bar_ms for i in range(n_bars + 1)]
        eq_curve = list(zip(times, equity))

        # Generate price series (BTC in INR)
        base_price = 3_400_000.0
        prices = [base_price]
        for _ in range(n_bars):
            prices.append(prices[-1] * (1 + random.gauss(0.0001, 0.02)))
        price_series = list(zip(times, prices))

        # Generate trades
        trades = []
        in_position = False
        entry_price = 0.0
        entry_ts    = 0
        qty = initial_capital * 0.05 / base_price  # 5% position size

        for i in range(1, n_bars):
            ema9  = sum(prices[max(0,i-9):i]) / min(i, 9)
            ema21 = sum(prices[max(0,i-21):i]) / min(i, 21)

            if not in_position and ema9 > ema21 and prices[i] > prices[i-1]:
                in_position = True
                entry_price = prices[i]
                entry_ts    = times[i]
            elif in_position and (ema9 < ema21 or random.random() < 0.05):
                exit_price = prices[i]
                pnl = (exit_price - entry_price) * qty
                fee = entry_price * qty * 0.001 + exit_price * qty * 0.001
                trades.append({
                    "symbol":      symbol,
                    "side":        "BUY",
                    "entry_price": round(entry_price, 2),
                    "exit_price":  round(exit_price, 2),
                    "quantity":    round(qty, 6),
                    "net_pnl":     round(pnl - fee, 2),
                    "return_pct":  round((exit_price / entry_price - 1) * 100, 4),
                    "entry_ts_ms": entry_ts,
                    "exit_ts_ms":  times[i],
                    "fee":         round(fee, 4),
                })
                in_position = False

        # Compute metrics
        metrics = MetricsCalculator.compute(
            equity_curve   = eq_curve,
            trades         = trades,
            initial_capital= initial_capital,
            price_series   = price_series,
        )

        return metrics.to_dict()

    @staticmethod
    def generate_all_demos() -> dict:
        """Generate demo results for all 5 pre-built strategies."""
        return {
            "ema_crossover": DemoResultsGenerator.generate(
                "EMA Crossover", "BTC", 100_000, 365, 28.4, seed=42),
            "rsi_mean_reversion": DemoResultsGenerator.generate(
                "RSI Mean Reversion", "ETH", 100_000, 365, 21.2, seed=7),
            "bollinger_bounce": DemoResultsGenerator.generate(
                "Bollinger Bounce", "SOL", 100_000, 300, 24.8, seed=13),
            "macd_momentum": DemoResultsGenerator.generate(
                "MACD Momentum", "BTC", 100_000, 365, 31.8, seed=99),
            "grid_trading": DemoResultsGenerator.generate(
                "Grid Trading", "BNB", 100_000, 180, 18.4, seed=55),
        }
