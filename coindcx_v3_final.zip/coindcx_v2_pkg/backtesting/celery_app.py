"""
CoinDCX Algo Platform — Celery Application

Defines all async tasks:
  - run_backtest: full backtest execution on historical data
  - run_param_sweep: grid search over parameter combinations
  - run_walk_forward: walk-forward validation
  - generate_strategy_report: compute and cache full analytics
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import time
import uuid
from decimal import Decimal

from celery import Celery
from celery.utils.log import get_task_logger

logger = get_task_logger(__name__)

BROKER_URL = os.environ.get("CELERY_BROKER_URL", "redis://localhost:6379/1")
RESULT_BACKEND = os.environ.get("CELERY_RESULT_BACKEND", "redis://localhost:6379/2")

app = Celery("coindcx_algo", broker=BROKER_URL, backend=RESULT_BACKEND)

app.conf.update(
    task_serializer="json",
    accept_content=["json"],
    result_serializer="json",
    timezone="UTC",
    enable_utc=True,
    task_track_started=True,
    task_acks_late=True,
    worker_prefetch_multiplier=1,
    task_routes={
        "coindcx_algo.backtesting.celery_app.run_backtest": {"queue": "backtest_normal"},
        "coindcx_algo.backtesting.celery_app.run_param_sweep": {"queue": "backtest_high"},
        "coindcx_algo.backtesting.celery_app.run_walk_forward": {"queue": "backtest_high"},
        "coindcx_algo.backtesting.celery_app.generate_strategy_report": {"queue": "backtest_low"},
    },
    task_soft_time_limit=600,   # 10min soft limit
    task_time_limit=900,        # 15min hard limit
)


def _run_async(coro):
    """Run an async coroutine from a sync Celery task."""
    loop = asyncio.new_event_loop()
    try:
        return loop.run_until_complete(coro)
    finally:
        loop.close()


@app.task(bind=True, name="coindcx_algo.backtesting.celery_app.run_backtest",
          max_retries=2, default_retry_delay=30)
def run_backtest(self, job_id: str, strategy_code: str, strategy_params: dict,
                 symbol: str, resolution: str, start_ms: int, end_ms: int,
                 initial_capital: float, maker_fee: float, taker_fee: float,
                 slippage_pct: float, user_id: str):
    """
    Execute a full backtest. Called by the API when user submits a backtest job.
    Runs on a Celery worker with up to 4 parallel workers per node.
    """
    logger.info(f"Starting backtest job {job_id} for user {user_id}")
    self.update_state(state="STARTED", meta={"job_id": job_id, "progress": 0})

    try:
        # Update job status in DB to "running"
        _update_job_status(job_id, "running")

        # Load strategy class from code string
        strategy_class = _load_strategy_from_code(strategy_code)

        # Fetch historical bars
        self.update_state(state="STARTED", meta={"job_id": job_id, "progress": 10, "stage": "fetching_data"})
        bars = _run_async(_fetch_bars(symbol, resolution, start_ms, end_ms))
        logger.info(f"Fetched {len(bars)} bars for {symbol} {resolution}")

        if len(bars) < 10:
            raise ValueError(f"Insufficient historical data: only {len(bars)} bars available")

        self.update_state(state="STARTED", meta={"job_id": job_id, "progress": 20, "stage": "running_backtest"})

        # Build backtest config
        from coindcx_algo.backtesting.engine import BacktestConfig, BacktestEngine
        config = BacktestConfig(
            strategy_class=strategy_class,
            strategy_params=strategy_params,
            symbol=symbol,
            resolution=resolution,
            start_ms=start_ms,
            end_ms=end_ms,
            initial_capital=Decimal(str(initial_capital)),
            maker_fee=Decimal(str(maker_fee)),
            taker_fee=Decimal(str(taker_fee)),
            slippage_pct=Decimal(str(slippage_pct)),
        )

        engine = BacktestEngine(config)
        result = _run_async(engine.run(bars))

        self.update_state(state="STARTED", meta={"job_id": job_id, "progress": 80, "stage": "saving_results"})

        # Serialize result
        result_data = {
            "run_id": result.run_id,
            "bars_processed": result.bars_processed,
            "duration_seconds": result.duration_seconds,
            "metrics": {
                "total_return_pct": result.metrics.total_return_pct,
                "annualized_return_pct": result.metrics.annualized_return_pct,
                "sharpe_ratio": result.metrics.sharpe_ratio,
                "sortino_ratio": result.metrics.sortino_ratio,
                "calmar_ratio": result.metrics.calmar_ratio,
                "max_drawdown_pct": result.metrics.max_drawdown_pct,
                "win_rate_pct": result.metrics.win_rate_pct,
                "profit_factor": result.metrics.profit_factor,
                "total_trades": result.metrics.total_trades,
                "total_fees_paid": str(result.metrics.total_fees_paid),
                "daily_volatility_pct": result.metrics.daily_volatility_pct,
                "annualized_volatility_pct": result.metrics.annualized_volatility_pct,
            },
            "equity_curve": [
                {"timestamp_ms": ts, "equity": float(eq)}
                for ts, eq in result.equity_curve
            ],
            "trades": [
                {
                    "symbol": t.symbol,
                    "side": t.side.value,
                    "entry_price": float(t.entry_price),
                    "exit_price": float(t.exit_price),
                    "quantity": float(t.quantity),
                    "net_pnl": float(t.net_pnl),
                    "fees": float(t.fees),
                    "return_pct": t.return_pct,
                    "entry_time_ms": t.entry_time_ms,
                    "exit_time_ms": t.exit_time_ms,
                    "hold_duration_bars": t.hold_duration_bars,
                }
                for t in result.trades
            ],
            "errors": result.errors,
        }

        # Save to S3 / local storage
        _save_result(job_id, result_data)

        # Update DB with summary metrics
        _update_job_completed(job_id, result_data["metrics"], result.duration_seconds)

        logger.info(
            f"Backtest {job_id} complete: "
            f"return={result.metrics.total_return_pct:.2f}%, "
            f"sharpe={result.metrics.sharpe_ratio:.2f}, "
            f"trades={result.metrics.total_trades}, "
            f"time={result.duration_seconds:.1f}s"
        )
        return {"job_id": job_id, "status": "completed", "metrics": result_data["metrics"]}

    except Exception as exc:
        logger.error(f"Backtest {job_id} failed: {exc}", exc_info=True)
        _update_job_status(job_id, "failed", error=str(exc))
        raise self.retry(exc=exc, countdown=30) if self.request.retries < 2 else exc


@app.task(bind=True, name="coindcx_algo.backtesting.celery_app.run_param_sweep")
def run_param_sweep(self, job_id: str, strategy_code: str, base_params: dict,
                    param_grid: dict, symbol: str, resolution: str,
                    start_ms: int, end_ms: int, initial_capital: float):
    """
    Grid search over parameter combinations.
    param_grid example: {"fast_period": [5, 10, 20], "slow_period": [20, 30, 50]}
    """
    logger.info(f"Starting param sweep {job_id}")
    strategy_class = _load_strategy_from_code(strategy_code)
    bars = _run_async(_fetch_bars(symbol, resolution, start_ms, end_ms))

    # Generate all combinations
    import itertools
    keys = list(param_grid.keys())
    values = list(param_grid.values())
    combinations = list(itertools.product(*values))
    total = len(combinations)
    logger.info(f"Testing {total} parameter combinations")

    results = []
    from coindcx_algo.backtesting.engine import BacktestConfig, BacktestEngine

    for i, combo in enumerate(combinations):
        params = {**base_params, **dict(zip(keys, combo))}
        config = BacktestConfig(
            strategy_class=strategy_class,
            strategy_params=params,
            symbol=symbol,
            resolution=resolution,
            start_ms=start_ms,
            end_ms=end_ms,
            initial_capital=Decimal(str(initial_capital)),
            simulate_latency=False,
        )
        engine = BacktestEngine(config)
        result = _run_async(engine.run(bars))
        results.append({
            "params": params,
            "sharpe": result.metrics.sharpe_ratio,
            "total_return_pct": result.metrics.total_return_pct,
            "max_drawdown_pct": result.metrics.max_drawdown_pct,
            "win_rate_pct": result.metrics.win_rate_pct,
            "total_trades": result.metrics.total_trades,
        })
        self.update_state(state="STARTED", meta={
            "job_id": job_id,
            "progress": int((i + 1) / total * 100),
            "combinations_done": i + 1,
            "total_combinations": total,
        })

    # Sort by Sharpe ratio
    results.sort(key=lambda r: r["sharpe"], reverse=True)
    best = results[0] if results else {}
    _save_result(f"sweep_{job_id}", {"results": results, "best": best})
    logger.info(f"Param sweep {job_id}: best Sharpe={best.get('sharpe', 0):.2f} with {best.get('params')}")
    return {"job_id": job_id, "status": "completed", "best_params": best, "total_tested": total}


# ─────────────────────────────────────────────────
# Internal helpers
# ─────────────────────────────────────────────────

def _load_strategy_from_code(code: str):
    """Compile strategy code and return the class."""
    import tempfile, importlib.util, sys
    with tempfile.NamedTemporaryFile(suffix=".py", mode="w", delete=False) as f:
        f.write(code)
        tmp_path = f.name
    spec = importlib.util.spec_from_file_location("_user_strat", tmp_path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    from coindcx_algo.sdk.strategy import BaseStrategy
    classes = [
        v for v in vars(mod).values()
        if isinstance(v, type) and issubclass(v, BaseStrategy) and v is not BaseStrategy
    ]
    if not classes:
        raise ValueError("No BaseStrategy subclass found in strategy code")
    return classes[-1]


async def _fetch_bars(symbol: str, resolution: str, start_ms: int, end_ms: int):
    """Fetch bars from TimescaleDB (warm) or generate synthetic data for demo."""
    # In production: query TimescaleDB
    # For local dev: generate synthetic OHLCV data
    from coindcx_algo.sdk.models import Bar
    import random
    random.seed(42)
    bars = []
    resolution_ms = {"1m": 60000, "5m": 300000, "15m": 900000,
                     "1h": 3600000, "4h": 14400000, "1d": 86400000}.get(resolution, 3600000)
    ts = start_ms
    price = 50000.0
    while ts < end_ms:
        change = random.gauss(0, 200)
        open_p = price
        close_p = max(price + change, 100)
        high_p = max(open_p, close_p) + abs(random.gauss(0, 100))
        low_p = min(open_p, close_p) - abs(random.gauss(0, 100))
        volume = random.uniform(10, 200)
        bars.append(Bar(
            symbol=symbol,
            open=Decimal(str(round(open_p, 2))),
            high=Decimal(str(round(high_p, 2))),
            low=Decimal(str(round(low_p, 2))),
            close=Decimal(str(round(close_p, 2))),
            volume=Decimal(str(round(volume, 4))),
            timestamp_ms=ts,
            resolution=resolution,
        ))
        price = close_p
        ts += resolution_ms
    return bars


def _save_result(job_id: str, data: dict) -> None:
    """Save result to local filesystem (in production: S3)."""
    import os, json
    os.makedirs("/tmp/backtest_results", exist_ok=True)
    with open(f"/tmp/backtest_results/{job_id}.json", "w") as f:
        json.dump(data, f, default=str)


def _update_job_status(job_id: str, status: str, error: str = None) -> None:
    logger.info(f"Job {job_id} status → {status}" + (f" ({error})" if error else ""))


def _update_job_completed(job_id: str, metrics: dict, duration: float) -> None:
    logger.info(f"Job {job_id} completed in {duration:.1f}s: {metrics}")
