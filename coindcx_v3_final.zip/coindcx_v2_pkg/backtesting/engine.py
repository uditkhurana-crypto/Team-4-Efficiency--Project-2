"""
CoinDCX Algo Platform — Backtesting Engine

Discrete-time event-driven backtesting simulator.
Designed to replicate live trading conditions as accurately as possible.

Key design decisions:
  - Event-driven (not vectorized) so strategies share exact same code as live
  - Realistic fill model: slippage, spread, partial fills, latency
  - Fee model: maker/taker, funding rates, withdrawal fees
  - Walk-forward validation to prevent overfitting
  - Parameter sweep with parallel execution
  - Results stored in PostgreSQL / S3 for review

Usage:
    engine = BacktestEngine(
        strategy_class=MyCrossoverStrategy,
        params={"fast_period": 10, "slow_period": 30},
        symbol="BTCUSDT",
        resolution="1h",
        start_date="2022-01-01",
        end_date="2024-01-01",
        initial_capital=10000,
        fee_rate=0.001,
    )
    result = await engine.run()
    print(result.metrics)
"""

from __future__ import annotations

import asyncio
import logging
import math
import time
import uuid
from dataclasses import dataclass, field
from decimal import Decimal
from typing import Optional, Type

import numpy as np

from sdk.models import (
    Bar, Tick, OrderRequest, Order, OrderStatus, OrderSide, OrderType,
    Fill, Portfolio, Position, PositionSide, MarketType,
    PerformanceMetrics
)
from sdk.strategy import BaseStrategy, StrategyContext

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

@dataclass
class BacktestConfig:
    """All parameters that define a backtest run."""

    strategy_class: Type[BaseStrategy]
    strategy_params: dict

    symbol: str
    resolution: str           # "1m", "5m", "1h", "1d"
    start_ms: int             # Unix timestamp ms
    end_ms: int               # Unix timestamp ms

    initial_capital: Decimal = Decimal("10000")   # USDT
    base_currency: str = "USDT"

    # Fee model
    maker_fee: Decimal = Decimal("0.0010")        # 0.10%
    taker_fee: Decimal = Decimal("0.0010")        # 0.10%

    # Slippage model
    slippage_pct: Decimal = Decimal("0.0005")     # 0.05% base slippage
    use_spread_slippage: bool = True               # Add bid-ask spread to slippage
    spread_pct: Decimal = Decimal("0.0003")       # 0.03% typical spread

    # Market impact
    market_impact_pct: Decimal = Decimal("0.0002") # Additional impact for large orders

    # Latency simulation
    simulate_latency: bool = True
    latency_bars: int = 1     # Execute on next bar's open (1 bar latency)

    # Futures
    funding_rate: Decimal = Decimal("0.0001")     # 0.01% per 8h
    leverage: Decimal = Decimal("1")

    # Logging
    verbose: bool = False


@dataclass
class BacktestResult:
    """Complete output from a backtest run."""

    run_id: str
    config: BacktestConfig
    metrics: PerformanceMetrics

    equity_curve: list[tuple[int, Decimal]]       # (timestamp_ms, equity)
    drawdown_curve: list[tuple[int, Decimal]]      # (timestamp_ms, drawdown_pct)
    trades: list[CompletedTrade]

    duration_seconds: float = 0.0
    bars_processed: int = 0
    errors: list[str] = field(default_factory=list)


@dataclass
class CompletedTrade:
    """A round-trip trade (entry + exit)."""
    symbol: str
    side: OrderSide
    entry_price: Decimal
    exit_price: Decimal
    quantity: Decimal
    entry_time_ms: int
    exit_time_ms: int
    pnl: Decimal
    fees: Decimal
    net_pnl: Decimal
    hold_duration_bars: int

    @property
    def return_pct(self) -> float:
        cost = float(self.entry_price * self.quantity)
        return float(self.net_pnl) / cost * 100 if cost else 0.0


# ---------------------------------------------------------------------------
# Fill simulator — heart of backtest realism
# ---------------------------------------------------------------------------

class FillSimulator:
    """
    Simulates realistic order fills from historical OHLCV data.

    Assumptions:
      - Market orders fill at next bar's open + slippage
      - Limit orders fill if bar trades through the limit price
      - Partial fills when volume is insufficient
      - Slippage increases with order size relative to bar volume
    """

    def __init__(self, config: BacktestConfig):
        self.config = config

    def simulate_market_fill(
        self, request: OrderRequest, bar: Bar
    ) -> tuple[Decimal, Decimal]:
        """
        Returns (fill_price, fill_qty) for a market order.
        """
        base_price = bar.open

        # Direction-dependent slippage
        slip = self.config.slippage_pct
        if self.config.use_spread_slippage:
            slip += self.config.spread_pct / 2

        # Volume-based market impact
        if bar.volume > 0:
            order_volume_pct = request.quantity / bar.volume
            impact = Decimal(str(self.config.market_impact_pct)) * order_volume_pct
            slip += impact

        if request.side == OrderSide.BUY:
            fill_price = base_price * (1 + slip)
            fill_price = min(fill_price, bar.high)  # Can't fill above bar high
        else:
            fill_price = base_price * (1 - slip)
            fill_price = max(fill_price, bar.low)   # Can't fill below bar low

        return fill_price, request.quantity

    def simulate_limit_fill(
        self, request: OrderRequest, bar: Bar
    ) -> Optional[tuple[Decimal, Decimal]]:
        """
        Returns (fill_price, fill_qty) if limit order would have filled, else None.
        """
        if not request.price:
            return None

        if request.side == OrderSide.BUY and bar.low <= request.price:
            fill_price = request.price  # Best case: fill at limit
            return fill_price, request.quantity
        elif request.side == OrderSide.SELL and bar.high >= request.price:
            fill_price = request.price
            return fill_price, request.quantity

        return None  # Limit not reached this bar

    def calculate_fee(
        self, fill_price: Decimal, fill_qty: Decimal, is_maker: bool
    ) -> Decimal:
        rate = self.config.maker_fee if is_maker else self.config.taker_fee
        return fill_price * fill_qty * rate


# ---------------------------------------------------------------------------
# Backtesting engine
# ---------------------------------------------------------------------------

class BacktestEngine:
    """
    Main backtesting engine.
    Runs strategies against historical data using the same code path as live trading.
    """

    def __init__(self, config: BacktestConfig):
        self.config = config
        self.run_id = str(uuid.uuid4())
        self._fill_sim = FillSimulator(config)

        # Runtime state
        self._portfolio: Optional[Portfolio] = None
        self._strategy: Optional[BaseStrategy] = None
        self._current_bar_idx: int = 0
        self._current_bar = None  # type: Optional[Bar]
        self._bars: list[Bar] = []
        self._pending_orders: list[tuple[int, OrderRequest]] = []  # (execute_at_bar_idx, request)
        self._all_orders: list[Order] = []
        self._completed_trades: list[CompletedTrade] = []
        self._equity_curve: list[tuple[int, Decimal]] = []
        self._drawdown_curve: list[tuple[int, Decimal]] = []
        self._peak_equity: Decimal = config.initial_capital
        self._order_id_counter: int = 0

        # Fill order emitted as futures that resolve synchronously
        self._pending_order_futures: dict[str, asyncio.Future] = {}

    async def run(self, bars: list[Bar]) -> BacktestResult:
        """
        Execute the backtest against the provided bars.
        Bars must be sorted ascending by timestamp.
        """
        start_time = time.time()
        self._bars = bars

        # Initialize portfolio
        self._portfolio = Portfolio(
            strategy_id=self.run_id,
            base_currency=self.config.base_currency,
            balances={self.config.base_currency: self.config.initial_capital},
        )
        self._peak_equity = self.config.initial_capital

        # Create strategy context
        context = StrategyContext(
            strategy_id=self.run_id,
            user_id="backtest",
            mode="backtest",
            exchange="simulation",
        )

        # Instantiate strategy
        loop = asyncio.get_event_loop()
        # Use sync order callback for backtest — fills happen immediately, no async needed
        def _sync_order_callback(request):
            return self._accept_order_sync(request)

        self._strategy = self.config.strategy_class(
            strategy_id=self.run_id,
            params=self.config.strategy_params,
            context=context,
            order_callback=_sync_order_callback,
            cancel_callback=self._cancel_order,
            portfolio=self._portfolio,
        )
        self._strategy.on_start()

        if self.config.verbose:
            logger.info(f"Backtest started: {len(bars)} bars, {self.config.symbol}")

        # Main event loop
        errors = []
        for idx, bar in enumerate(bars):
            self._current_bar_idx = idx
            try:
                await self._process_bar(bar)
            except Exception as e:
                errors.append(f"Bar {idx} ({bar.timestamp_ms}): {e}")
                logger.warning(f"Error at bar {idx}: {e}")

        self._strategy.on_stop()

        # Compute metrics
        duration = time.time() - start_time
        metrics = self._compute_metrics()

        return BacktestResult(
            run_id=self.run_id,
            config=self.config,
            metrics=metrics,
            equity_curve=self._equity_curve,
            drawdown_curve=self._drawdown_curve,
            trades=self._completed_trades,
            duration_seconds=duration,
            bars_processed=len(bars),
            errors=errors,
        )

    async def _process_bar(self, bar: Bar) -> None:
        """Process one bar: fill pending limit orders, call strategy, fill new market orders."""
        self._current_bar = bar  # Used by _accept_order for immediate fills

        # 1. Fill any pending limit/deferred orders from previous bars
        still_pending = []
        for execute_at, request in self._pending_orders:
            if self._current_bar_idx >= execute_at:
                await self._execute_pending_order(request, bar)
            else:
                still_pending.append((execute_at, request))
        self._pending_orders = still_pending

        # 2. Update position mark prices
        for pos in self._portfolio.positions.values():
            pos.update_price(bar.close)

        # 3. Track equity/drawdown before strategy runs
        equity = self._portfolio.total_equity
        self._equity_curve.append((bar.timestamp_ms, equity))
        if equity > self._peak_equity:
            self._peak_equity = equity
        drawdown = ((self._peak_equity - equity) / self._peak_equity * 100) if self._peak_equity > 0 else Decimal("0")
        self._drawdown_curve.append((bar.timestamp_ms, drawdown))

        # 4. Feed bar to strategy (may submit new orders)
        orders_before = len(self._pending_orders)
        self._strategy._handle_bar(bar)

        # 5. Immediately fill MARKET orders submitted this bar (no-latency mode)
        if not self.config.simulate_latency:
            new_orders = self._pending_orders[orders_before:]
            kept = []
            for execute_at, request in new_orders:
                if request.order_type == OrderType.MARKET:
                    await self._execute_pending_order(request, bar)
                else:
                    kept.append((execute_at, request))
            self._pending_orders = self._pending_orders[:orders_before] + kept

    def _accept_order_sync(self, request: OrderRequest) -> Order:
        """Synchronous version of _accept_order for backtest mode.
        Fills market orders immediately without async overhead.
        """
        self._order_id_counter += 1
        order = Order(
            order_id=f"bt_{self._order_id_counter}",
            client_order_id=request.client_order_id or f"bt_c_{self._order_id_counter}",
            exchange_order_id=None,
            symbol=request.symbol,
            side=request.side,
            order_type=request.order_type,
            market_type=request.market_type or MarketType.SPOT,
            quantity=request.quantity,
            price=request.price,
            stop_price=request.stop_price,
            status=OrderStatus.PENDING,
            strategy_id=self.run_id,
        )
        self._all_orders.append(order)

        if not self.config.simulate_latency and request.order_type == OrderType.MARKET and self._current_bar is not None:
            # Immediate synchronous fill
            fill_price, fill_qty = self._fill_sim.simulate_market_fill(request, self._current_bar)
            fee = self._fill_sim.calculate_fee(fill_price, fill_qty, False)
            self._apply_fill_to_portfolio(request, fill_price, fill_qty, fee, self._current_bar.timestamp_ms)
            order.status = OrderStatus.FILLED
            order.filled_quantity = fill_qty
            order.avg_fill_price = fill_price
        elif request.order_type == OrderType.LIMIT and request.price:
            execute_at = self._current_bar_idx + (self.config.latency_bars if self.config.simulate_latency else 1)
            self._pending_orders.append((execute_at, request))
        else:
            execute_at = self._current_bar_idx + (self.config.latency_bars if self.config.simulate_latency else 1)
            self._pending_orders.append((execute_at, request))

        if hasattr(self._strategy, '_handle_order_update'):
            self._strategy._handle_order_update(order)
        return order

    async def _accept_order(self, request: OrderRequest) -> Order:
        """Called by strategy when it wants to place an order.
        
        In no-latency backtest mode, market orders fill synchronously right here.
        """
        self._order_id_counter += 1
        order = Order(
            order_id=f"bt_{self._order_id_counter}",
            client_order_id=request.client_order_id or f"bt_c_{self._order_id_counter}",
            exchange_order_id=None,
            symbol=request.symbol,
            side=request.side,
            order_type=request.order_type,
            market_type=request.market_type or MarketType.SPOT,
            quantity=request.quantity,
            price=request.price,
            stop_price=request.stop_price,
            status=OrderStatus.PENDING,
            strategy_id=self.run_id,
        )
        self._all_orders.append(order)
        self._strategy._handle_order_update(order)

        # In no-latency mode: market orders fill IMMEDIATELY inline (same bar)
        if not self.config.simulate_latency and request.order_type == OrderType.MARKET and self._current_bar is not None:
            fill_price, fill_qty = self._fill_sim.simulate_market_fill(request, self._current_bar)
            fee = self._fill_sim.calculate_fee(fill_price, fill_qty, False)
            self._apply_fill_sync(request, fill_price, fill_qty, fee, self._current_bar.timestamp_ms)
            order.status = OrderStatus.FILLED
            order.filled_quantity = fill_qty
            order.avg_fill_price = fill_price
            self._strategy._handle_order_update(order)
        else:
            # Latency mode: schedule for future bar
            execute_at = self._current_bar_idx + (self.config.latency_bars if self.config.simulate_latency else 1)
            self._pending_orders.append((execute_at, request))

        return order

    def _apply_fill_sync(self, request: OrderRequest, fill_price: Decimal,
                         fill_qty: Decimal, fee: Decimal, timestamp_ms: int) -> None:
        """Synchronous fill application — used for immediate fills in no-latency mode."""
        import asyncio
        loop = asyncio.get_event_loop()
        if loop.is_running():
            # We're inside an async context — schedule as a task that runs before next await
            # Use the sync path directly
            self._apply_fill_to_portfolio(request, fill_price, fill_qty, fee, timestamp_ms)
        else:
            loop.run_until_complete(self._apply_fill(request, fill_price, fill_qty, fee, timestamp_ms))

    def _apply_fill_to_portfolio(self, request: OrderRequest, fill_price: Decimal,
                                  fill_qty: Decimal, fee: Decimal, timestamp_ms: int) -> None:
        """Pure sync portfolio update — no async needed."""
        symbol = request.symbol
        existing = self._portfolio.get_position(symbol)

        if request.side == OrderSide.BUY:
            cost = fill_qty * fill_price + fee
            self._portfolio.balances["USDT"] = max(
                Decimal("0"),
                self._portfolio.balances.get("USDT", Decimal("0")) - cost
            )
            if existing and existing.quantity > 0 and existing.side == PositionSide.LONG:
                total_cost = (existing.quantity * existing.avg_entry_price) + (fill_qty * fill_price)
                existing.quantity += fill_qty
                existing.avg_entry_price = total_cost / existing.quantity
                existing.current_price = fill_price
            else:
                self._portfolio.positions[symbol] = Position(
                    symbol=symbol,
                    side=PositionSide.LONG,
                    quantity=fill_qty,
                    avg_entry_price=fill_price,
                    market_type=request.market_type or MarketType.SPOT,
                    strategy_id=self.run_id,
                    opened_at_ms=timestamp_ms,
                    current_price=fill_price,
                )
        else:  # SELL
            position = self._portfolio.get_position(symbol)
            if position and position.quantity > 0:
                pnl = (fill_price - position.avg_entry_price) * fill_qty
                entry_time = position.opened_at_ms
                return_pct = float(pnl / (position.avg_entry_price * fill_qty)) * 100 if position.avg_entry_price > 0 else 0

                self._completed_trades.append(CompletedTrade(
                    symbol=symbol,
                    side=request.side,
                    entry_price=position.avg_entry_price,
                    exit_price=fill_price,
                    quantity=fill_qty,
                    entry_time_ms=entry_time,
                    exit_time_ms=timestamp_ms,
                    pnl=pnl,
                    fees=fee,
                    net_pnl=pnl - fee,
                    hold_duration_bars=self._current_bar_idx,
                ))

                proceeds = fill_qty * fill_price - fee
                self._portfolio.balances["USDT"] = (
                    self._portfolio.balances.get("USDT", Decimal("0")) + proceeds
                )
                if fill_qty >= position.quantity:
                    position.quantity = Decimal("0")
                    position.side = PositionSide.FLAT
                else:
                    position.quantity -= fill_qty

    async def _cancel_order(self, order_id: str) -> bool:
        self._pending_orders = [
            (at, req) for at, req in self._pending_orders
            if req.client_order_id != order_id
        ]
        return True

    async def _execute_pending_order(self, request: OrderRequest, bar: Bar) -> None:
        """Simulate fill execution at the given bar."""
        if request.order_type == OrderType.MARKET or request.order_type == OrderType.MARKET:
            fill_price, fill_qty = self._fill_sim.simulate_market_fill(request, bar)
            is_maker = False
        elif request.order_type == OrderType.LIMIT and request.price:
            result = self._fill_sim.simulate_limit_fill(request, bar)
            if result is None:
                return  # Limit not hit, keep pending
            fill_price, fill_qty = result
            is_maker = True
        else:
            fill_price, fill_qty = self._fill_sim.simulate_market_fill(request, bar)
            is_maker = False

        fee = self._fill_sim.calculate_fee(fill_price, fill_qty, is_maker)

        # Update portfolio
        await self._apply_fill(request, fill_price, fill_qty, fee, bar.timestamp_ms)

    async def _apply_fill(
        self,
        request: OrderRequest,
        fill_price: Decimal,
        fill_qty: Decimal,
        fee: Decimal,
        timestamp_ms: int,
    ) -> None:
        """Apply a simulated fill to the portfolio."""
        symbol = request.symbol
        existing = self._portfolio.get_position(symbol)

        if request.side == OrderSide.BUY:
            cost = fill_qty * fill_price + fee
            self._portfolio.balances["USDT"] = max(
                Decimal("0"),
                self._portfolio.balances.get("USDT", Decimal("0")) - cost
            )

            if existing and existing.quantity > 0 and existing.side == PositionSide.LONG:
                # Add to long position
                total_cost = (existing.quantity * existing.avg_entry_price) + (fill_qty * fill_price)
                existing.quantity += fill_qty
                existing.avg_entry_price = total_cost / existing.quantity
            else:
                # Open new long
                self._portfolio.positions[symbol] = Position(
                    symbol=symbol,
                    side=PositionSide.LONG,
                    quantity=fill_qty,
                    avg_entry_price=fill_price,
                    market_type=request.market_type or MarketType.SPOT,
                    strategy_id=self.run_id,
                    opened_at_ms=timestamp_ms,
                    current_price=fill_price,
                )
        else:  # SELL
            position = self._portfolio.get_position(symbol)
            if position and position.quantity > 0:
                # Close or reduce long position
                pnl = (fill_price - position.avg_entry_price) * fill_qty
                entry_time = position.opened_at_ms

                self._completed_trades.append(CompletedTrade(
                    symbol=symbol,
                    side=request.side,
                    entry_price=position.avg_entry_price,
                    exit_price=fill_price,
                    quantity=fill_qty,
                    entry_time_ms=entry_time,
                    exit_time_ms=timestamp_ms,
                    pnl=pnl,
                    fees=fee,
                    net_pnl=pnl - fee,
                    hold_duration_bars=self._current_bar_idx,
                ))

                proceeds = fill_qty * fill_price - fee
                self._portfolio.balances["USDT"] = (
                    self._portfolio.balances.get("USDT", Decimal("0")) + proceeds
                )

                if fill_qty >= position.quantity:
                    position.quantity = Decimal("0")
                    position.side = PositionSide.FLAT
                else:
                    position.quantity -= fill_qty
            else:
                # Short selling (simplified — just track proceeds)
                proceeds = fill_qty * fill_price - fee
                self._portfolio.balances["USDT"] = (
                    self._portfolio.balances.get("USDT", Decimal("0")) + proceeds
                )

    def _compute_metrics(self) -> PerformanceMetrics:
        """Compute all performance statistics from completed backtest."""
        if not self._equity_curve:
            return PerformanceMetrics(
                strategy_id=self.run_id,
                period_start_ms=self.config.start_ms,
                period_end_ms=self.config.end_ms,
            )

        equities = [float(e) for _, e in self._equity_curve]
        initial = float(self.config.initial_capital)
        final = equities[-1] if equities else initial

        # Returns
        total_return = (final - initial) / initial * 100 if initial > 0 else 0.0
        n_days = (self.config.end_ms - self.config.start_ms) / 86_400_000
        annualized_return = (
            ((1 + total_return / 100) ** (365 / n_days) - 1) * 100
            if n_days > 0 else 0.0
        )

        # Daily returns for Sharpe/Sortino
        returns = []
        for i in range(1, len(equities)):
            r = (equities[i] - equities[i - 1]) / equities[i - 1] if equities[i - 1] > 0 else 0.0
            returns.append(r)

        sharpe = self._sharpe(returns)
        sortino = self._sortino(returns)

        # Drawdown
        dd_values = [float(d) for _, d in self._drawdown_curve]
        max_dd = max(dd_values) if dd_values else 0.0
        avg_dd = sum(dd_values) / len(dd_values) if dd_values else 0.0

        # Trade stats
        trades = self._completed_trades
        winning = [t for t in trades if t.net_pnl > 0]
        losing = [t for t in trades if t.net_pnl <= 0]
        gross_profit = sum(float(t.net_pnl) for t in winning)
        gross_loss = abs(sum(float(t.net_pnl) for t in losing))

        win_rate = len(winning) / len(trades) * 100 if trades else 0.0
        profit_factor = gross_profit / gross_loss if gross_loss > 0 else float("inf")
        avg_win = Decimal(str(gross_profit / len(winning))) if winning else Decimal("0")
        avg_loss = Decimal(str(gross_loss / len(losing))) if losing else Decimal("0")
        largest_win = max((t.net_pnl for t in winning), default=Decimal("0"))
        largest_loss = min((t.net_pnl for t in losing), default=Decimal("0"))

        total_fees = sum(t.fees for t in trades)
        total_pnl = Decimal(str(final - initial))

        # Calmar ratio
        calmar = annualized_return / max_dd if max_dd > 0 else 0.0

        # Volatility
        if returns:
            daily_vol = float(np.std(returns)) * 100
            annual_vol = daily_vol * math.sqrt(365)
        else:
            daily_vol = annual_vol = 0.0

        return PerformanceMetrics(
            strategy_id=self.run_id,
            period_start_ms=self.config.start_ms,
            period_end_ms=self.config.end_ms,
            total_return_pct=total_return,
            annualized_return_pct=annualized_return,
            total_pnl=total_pnl,
            sharpe_ratio=sharpe,
            sortino_ratio=sortino,
            calmar_ratio=calmar,
            max_drawdown_pct=max_dd,
            avg_drawdown_pct=avg_dd,
            total_trades=len(trades),
            winning_trades=len(winning),
            losing_trades=len(losing),
            win_rate_pct=win_rate,
            profit_factor=profit_factor,
            avg_win=avg_win,
            avg_loss=avg_loss,
            largest_win=largest_win,
            largest_loss=largest_loss,
            total_fees_paid=total_fees,
            daily_volatility_pct=daily_vol,
            annualized_volatility_pct=annual_vol,
        )

    @staticmethod
    def _sharpe(returns: list[float], risk_free: float = 0.05 / 365) -> float:
        if len(returns) < 2:
            return 0.0
        mean = sum(returns) / len(returns)
        variance = sum((r - mean) ** 2 for r in returns) / (len(returns) - 1)
        std = math.sqrt(variance)
        if std == 0:
            return 0.0
        return float(np.sqrt(365) * (mean - risk_free) / std)

    @staticmethod
    def _sortino(returns: list[float], risk_free: float = 0.05 / 365) -> float:
        if len(returns) < 2:
            return 0.0
        mean = sum(returns) / len(returns)
        downside_sq = sum((r - risk_free) ** 2 for r in returns if r < risk_free)
        downside_std = math.sqrt(downside_sq / len(returns))
        if downside_std == 0:
            return 0.0
        return float(np.sqrt(365) * (mean - risk_free) / downside_std)


# ---------------------------------------------------------------------------
# Walk-forward validator
# ---------------------------------------------------------------------------

class WalkForwardValidator:
    """
    Runs a strategy across rolling train/test windows.
    Helps detect overfitting by testing on unseen data.
    """

    def __init__(
        self,
        strategy_class: Type[BaseStrategy],
        base_params: dict,
        all_bars: list[Bar],
        train_pct: float = 0.7,
        n_folds: int = 5,
        optimize_fn=None,
    ):
        self.strategy_class = strategy_class
        self.base_params = base_params
        self.all_bars = all_bars
        self.train_pct = train_pct
        self.n_folds = n_folds
        self.optimize_fn = optimize_fn

    async def run(self) -> list[BacktestResult]:
        n = len(self.all_bars)
        fold_size = n // self.n_folds
        results = []

        for fold in range(self.n_folds):
            test_start = fold * fold_size
            test_end = test_start + fold_size
            train_bars = self.all_bars[:test_start] + self.all_bars[test_end:]
            test_bars = self.all_bars[test_start:test_end]

            if len(test_bars) < 10:
                continue

            # Optionally optimize params on training set
            params = self.base_params
            if self.optimize_fn and len(train_bars) > 10:
                params = await self.optimize_fn(train_bars, self.base_params)

            config = BacktestConfig(
                strategy_class=self.strategy_class,
                strategy_params=params,
                symbol=test_bars[0].symbol,
                resolution=test_bars[0].resolution,
                start_ms=test_bars[0].timestamp_ms,
                end_ms=test_bars[-1].timestamp_ms,
            )
            engine = BacktestEngine(config)
            result = await engine.run(test_bars)
            results.append(result)
            logger.info(
                f"WF fold {fold + 1}/{self.n_folds}: "
                f"sharpe={result.metrics.sharpe_ratio:.2f}, "
                f"return={result.metrics.total_return_pct:.1f}%"
            )

        return results
