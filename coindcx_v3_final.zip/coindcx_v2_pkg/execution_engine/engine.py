"""
CoinDCX Algo Platform — Execution Engine v3
=============================================
Fixes:
  1. Real CoinDCX live order placement (HMAC corrected)
  2. client_order_id = "cdxalgo-{strategy_id}-{uuid}" for attribution
  3. Order status polling → surfaces rejection reason
  4. Real wallet balance from /exchange/v1/users/balances in live mode
  5. Live P&L from actual fill prices tracked per strategy
  6. get_strategy_pnl() — attribution per strategy
"""
from __future__ import annotations
import hashlib, hmac, json, os, time, uuid, urllib.request, urllib.error
from dataclasses import dataclass, field
from enum import Enum
from typing import Optional

# INR fallback prices (updated realistic values)
PAPER_PRICES_INR: dict[str, float] = {
    "BTC": 8_650_000, "ETH": 280_000, "BNB": 52_000, "SOL": 17_500,
    "ADA": 38.5,   "MATIC": 58.2,  "DOT": 580,   "AVAX": 3_100,
    "LINK": 1_100, "UNI": 900,     "LTC": 7_200, "XRP": 48.0,
    "DOGE": 11.2,  "SHIB": 0.00082,"ATOM": 780,  "NEAR": 390,
    "FTM": 38.2,   "ALGO": 14.8,   "VET": 2.8,   "THETA": 145,
    "FIL": 340,    "AAVE": 7_800,  "COMP": 3_800,"SNX": 240,
    "GRT": 16.2,   "BAT": 18.4,    "ENJ": 24.2,  "MANA": 28.0,
    "SAND": 38.2,  "AXS": 480,     "OP": 240,    "ARB": 128,
    "SUI": 140,    "INJ": 2_400,   "WLD": 380,   "PYTH": 32.4,
    "JUP": 72.4,   "TIA": 520,     "SEI": 40.2,
}

# CoinDCX symbol map  short → CoinDCX market string
CDX_MARKET: dict[str, str] = {
    "BTC":"BTCINR","ETH":"ETHINR","BNB":"BNBINR","SOL":"SOLINR",
    "ADA":"ADAINR","MATIC":"MATICINR","DOT":"DOTINR","AVAX":"AVAXINR",
    "LINK":"LINKINR","UNI":"UNIINR","LTC":"LTCINR","XRP":"XRPINR",
    "DOGE":"DOGEINR","SHIB":"SHIBINR","ATOM":"ATOMINR","NEAR":"NEARINR",
    "FTM":"FTMINR","ALGO":"ALGOINR","VET":"VETINR","INJ":"INJINR",
    "OP":"OPINR","ARB":"ARBINR","SUI":"SUIINR","WLD":"WLDINR",
    "PYTH":"PYTHINR","JUP":"JUPINR","TIA":"TIAINR","SEI":"SEIINR",
    "AAVE":"AAVEINR","COMP":"COMPINR",
}


class ExecutionMode(str, Enum):
    PAPER = "paper"
    SAFE  = "safe"
    LIVE  = "live"


@dataclass
class TradeResult:
    trade_id:        str
    symbol:          str
    side:            str
    quantity:        float
    fill_price:      float
    fill_time_ms:    int
    fee:             float
    net_pnl:         float
    mode:            str
    order_id:        Optional[str] = None
    client_order_id: Optional[str] = None
    strategy_id:     Optional[str] = None
    strategy_name:   Optional[str] = None
    error:           Optional[str] = None
    success:         bool = True
    order_status:    Optional[str] = None   # "filled" / "rejected" / "open" etc.
    reject_reason:   Optional[str] = None   # exact reason from CoinDCX

    @property
    def notional(self) -> float:
        return self.quantity * self.fill_price


@dataclass
class RiskCheckResult:
    passed: bool
    reason: str = ""


# ── Live price cache ────────────────────────────────────────────────────────
class _LivePriceCache:
    """Fetches real prices from CoinDCX public ticker. TTL = 10s."""
    TTL = 10

    def __init__(self):
        self._data: dict[str, float] = {}
        self._change: dict[str, float] = {}
        self._fetched = 0.0
        self._market_to_sym = {v: k for k, v in CDX_MARKET.items()}

    def _refresh(self):
        if time.time() - self._fetched < self.TTL:
            return
        try:
            req = urllib.request.Request(
                "https://api.coindcx.com/exchange/ticker",
                headers={"Accept": "application/json"},
            )
            with urllib.request.urlopen(req, timeout=8) as r:
                tickers = json.loads(r.read())
            for t in tickers:
                m  = t.get("market", "")
                lp = float(t.get("last_price", 0) or 0)
                ch = float(t.get("change_24_hour", 0) or 0)
                if lp > 0 and m in self._market_to_sym:
                    sym = self._market_to_sym[m]
                    self._data[sym]   = lp
                    self._change[sym] = ch
            self._fetched = time.time()
        except Exception:
            pass

    def price(self, sym: str) -> float:
        self._refresh()
        s = sym.replace("/INR","").replace("INR","").replace("USDT","").upper()
        if s in self._data:
            return self._data[s]
        # USDT pair fallback
        m = s + "USDT"
        for t in []:  # placeholder if needed
            pass
        return PAPER_PRICES_INR.get(s, 1000.0)

    def all(self) -> dict[str, dict]:
        self._refresh()
        result = {}
        for sym in PAPER_PRICES_INR:
            result[sym] = {
                "price":     round(self._data.get(sym, PAPER_PRICES_INR[sym]), 8),
                "change_24h": round(self._change.get(sym, 0.0), 4),
            }
        return result


_price_cache = _LivePriceCache()


# ── Risk Guard ──────────────────────────────────────────────────────────────
class RiskGuard:
    def __init__(self, max_pos_pct=5.0, max_daily=50, sl_pct=2.0):
        self.max_pos_pct   = max_pos_pct
        self.max_daily     = max_daily
        self.sl_pct        = sl_pct
        self._daily        = 0
        self._day_ts       = time.time()
        self._kill         = False

    def _reset(self):
        if time.time() - self._day_ts > 86400:
            self._daily = 0; self._day_ts = time.time()

    def check(self, sym, qty, price, capital) -> RiskCheckResult:
        self._reset()
        if self._kill:
            return RiskCheckResult(False, "Kill switch engaged — all trading halted")
        if self._daily >= self.max_daily:
            return RiskCheckResult(False, f"Daily limit {self.max_daily} trades reached")
        notional = qty * price
        if capital > 0 and notional / capital * 100 > self.max_pos_pct:
            return RiskCheckResult(False,
                f"Position {notional/capital*100:.1f}% > max {self.max_pos_pct}%")
        return RiskCheckResult(True)

    def record(self):
        self._reset(); self._daily += 1

    def engage_kill_switch(self):  self._kill = True
    def release_kill_switch(self): self._kill = False

    def to_dict(self):
        self._reset()
        return {"kill_switch_active": self._kill, "daily_trade_count": self._daily,
                "max_daily_trades": self.max_daily, "max_position_pct": self.max_pos_pct,
                "stop_loss_pct": self.sl_pct}


# ── Paper Wallet ─────────────────────────────────────────────────────────────
class PaperWallet:
    FEE = 0.001

    def __init__(self, initial=1_000_000.0):
        self.initial       = initial
        self.balance_inr   = initial
        self.positions: dict[str, dict] = {}
        self.trade_log: list[dict] = []
        self.pnl_realized  = 0.0

    def reset(self, initial=1_000_000.0):
        self.__init__(initial)

    def fill_buy(self, sym, qty, price, strategy_id=None, strategy_name=None):
        notional = qty * price; fee = notional * self.FEE
        if self.balance_inr < notional + fee:
            return TradeResult(trade_id=_uid(), symbol=sym, side="BUY", quantity=qty,
                fill_price=price, fill_time_ms=_ts(), fee=fee, net_pnl=0, mode="paper",
                success=False, error="Insufficient INR balance",
                strategy_id=strategy_id, strategy_name=strategy_name)
        self.balance_inr -= (notional + fee)
        p = self.positions.get(sym)
        if p:
            tot_qty  = p["qty"] + qty
            p["avg_price"] = (p["avg_price"] * p["qty"] + price * qty) / tot_qty
            p["qty"]  = tot_qty
        else:
            self.positions[sym] = {"qty": qty, "avg_price": price,
                                   "strategy_id": strategy_id, "strategy_name": strategy_name}
        r = TradeResult(trade_id=_uid(), symbol=sym, side="BUY", quantity=qty,
            fill_price=price, fill_time_ms=_ts(), fee=round(fee,4),
            net_pnl=round(-fee,4), mode="paper",
            strategy_id=strategy_id, strategy_name=strategy_name)
        self._log(r); return r

    def fill_sell(self, sym, qty, price, strategy_id=None, strategy_name=None):
        p = self.positions.get(sym)
        if not p or p["qty"] < qty - 1e-9:
            return TradeResult(trade_id=_uid(), symbol=sym, side="SELL", quantity=qty,
                fill_price=price, fill_time_ms=_ts(), fee=0, net_pnl=0, mode="paper",
                success=False, error="Insufficient position",
                strategy_id=strategy_id, strategy_name=strategy_name)
        notional = qty * price; fee = notional * self.FEE
        pnl = notional - p["avg_price"] * qty - fee
        self.balance_inr   += notional - fee
        self.pnl_realized  += pnl
        p["qty"] -= qty
        if p["qty"] < 1e-9: del self.positions[sym]
        r = TradeResult(trade_id=_uid(), symbol=sym, side="SELL", quantity=qty,
            fill_price=price, fill_time_ms=_ts(), fee=round(fee,4),
            net_pnl=round(pnl,4), mode="paper",
            strategy_id=strategy_id, strategy_name=strategy_name)
        self._log(r); return r

    def close_position(self, sym, price):
        p = self.positions.get(sym)
        if not p:
            return TradeResult(trade_id=_uid(), symbol=sym, side="SELL", quantity=0,
                fill_price=price, fill_time_ms=_ts(), fee=0, net_pnl=0, mode="paper",
                success=False, error="No position")
        return self.fill_sell(sym, p["qty"], price, p.get("strategy_id"), p.get("strategy_name"))

    def portfolio_value(self):
        return self.balance_inr + sum(
            p["qty"] * _price_cache.price(s) for s, p in self.positions.items()
        )

    def unrealized_pnl(self):
        return sum(
            (_price_cache.price(s) - p["avg_price"]) * p["qty"]
            for s, p in self.positions.items()
        )

    def to_dict(self):
        positions = {}
        for sym, p in self.positions.items():
            cur = _price_cache.price(sym)
            upnl = (cur - p["avg_price"]) * p["qty"]
            positions[sym] = {
                "qty": round(p["qty"],8), "avg_price": round(p["avg_price"],2),
                "current_price": round(cur,2),
                "unrealized_pnl": round(upnl,2),
                "unrealized_pnl_pct": round(upnl/(p["avg_price"]*p["qty"])*100,4) if p["avg_price"]*p["qty"] else 0,
                "side": "LONG",
                "strategy_id": p.get("strategy_id"),
                "strategy_name": p.get("strategy_name"),
            }
        pv = self.portfolio_value()
        return {
            "balance_inr": round(self.balance_inr,2),
            "initial_balance": self.initial,
            "pnl_realized": round(self.pnl_realized,2),
            "pnl_unrealized": round(self.unrealized_pnl(),2),
            "total_pnl": round(self.pnl_realized + self.unrealized_pnl(),2),
            "portfolio_value": round(pv,2),
            "return_pct": round((pv - self.initial)/self.initial*100,4),
            "positions": positions,
            "trade_count": len(self.trade_log),
        }

    def _log(self, r: TradeResult):
        self.trade_log.append({
            "trade_id": r.trade_id, "symbol": r.symbol, "side": r.side,
            "quantity": r.quantity, "fill_price": r.fill_price,
            "fee": r.fee, "net_pnl": r.net_pnl, "timestamp_ms": r.fill_time_ms,
            "mode": r.mode, "strategy_id": r.strategy_id, "strategy_name": r.strategy_name,
        })


# ── CoinDCX Live Adapter ─────────────────────────────────────────────────────
class CoinDCXLiveAdapter:
    BASE = "https://api.coindcx.com"
    POLL_TRIES    = 8
    POLL_INTERVAL = 1.5

    def __init__(self):
        self.api_key    = os.environ.get("COINDCX_API_KEY", "").strip()
        self.api_secret = os.environ.get("COINDCX_SECRET_KEY", "").strip()

    @property
    def ready(self): return bool(self.api_key and self.api_secret)

    def _make_sig(self, body: dict) -> tuple[str, dict]:
        """Add timestamp to body, return (signature, updated_body)."""
        body["timestamp"] = int(round(time.time() * 1000))
        payload = json.dumps(body, separators=(",", ":"))
        sig = hmac.new(
            self.api_secret.encode("utf-8"),
            payload.encode("utf-8"),
            hashlib.sha256,
        ).hexdigest()
        return sig, body

    def _post(self, endpoint: str, body: dict) -> dict:
        if not self.ready:
            raise RuntimeError(
                "API keys missing. Set COINDCX_API_KEY + COINDCX_SECRET_KEY env vars."
            )
        sig, body = self._make_sig(body)
        headers = {
            "Content-Type":    "application/json",
            "X-AUTH-APIKEY":   self.api_key,
            "X-AUTH-SIGNATURE": sig,
        }
        req = urllib.request.Request(
            self.BASE + endpoint,
            data=json.dumps(body).encode(),
            headers=headers, method="POST",
        )
        try:
            with urllib.request.urlopen(req, timeout=15) as r:
                return json.loads(r.read())
        except urllib.error.HTTPError as e:
            raw = e.read().decode("utf-8", errors="replace")
            try:
                j = json.loads(raw)
                msg = j.get("message") or j.get("error") or raw
            except Exception:
                msg = raw
            raise RuntimeError(f"CoinDCX {e.code}: {msg}")

    # Public ticker (no auth)
    def fetch_ticker(self) -> dict[str, dict]:
        return _price_cache.all()

    # Authenticated
    def get_balances(self) -> list[dict]:
        return self._post("/exchange/v1/users/balances", {})

    def place_order(self, market: str, side: str, qty: float,
                    strategy_id=None, strategy_name=None,
                    order_type="market_order", price=None) -> dict:
        uid       = str(uuid.uuid4())[:8]
        client_id = f"cdxalgo-{(strategy_id or 'manual')[:12]}-{uid}"
        body = {
            "side": side.lower(), "order_type": order_type,
            "market": market.upper(), "total_quantity": qty,
            "client_order_id": client_id,
        }
        if order_type == "limit_order" and price:
            body["price_per_unit"] = str(price)
        resp = self._post("/exchange/v1/orders/create", body)
        resp["_client_order_id"] = client_id
        resp["_strategy_id"]     = strategy_id
        resp["_strategy_name"]   = strategy_name
        return resp

    def get_order_status(self, order_id: str) -> dict:
        resp = self._post("/exchange/v1/orders/status", {"id": order_id})
        orders = resp if isinstance(resp, list) else [resp]
        o = orders[0] if orders else {}
        return {
            "order_id":        str(o.get("id", order_id)),
            "client_order_id": str(o.get("client_order_id", "")),
            "status":          str(o.get("status", "unknown")),
            "side":            str(o.get("side", "")),
            "symbol":          str(o.get("market", "")),
            "quantity":        float(o.get("total_quantity") or 0),
            "filled_qty":      float(o.get("quantity_filled") or o.get("filled_quantity") or 0),
            "avg_fill_price":  float(o.get("avg_price") or o.get("price_per_unit") or 0),
            "fee":             float(o.get("fee_amount") or 0),
            "reject_reason":   str(o.get("reason") or ""),
            "human_status":    _human_status(str(o.get("status","unknown")), str(o.get("reason",""))),
            "raw":             o,
        }

    def poll_order(self, order_id: str) -> dict:
        """Poll until terminal status or max tries."""
        TERMINAL = {"filled","cancelled","rejected","partially_cancelled"}
        for attempt in range(self.POLL_TRIES):
            s = self.get_order_status(order_id)
            if s["status"] in TERMINAL:
                print(f"[Order] {order_id} → {s['status']} (attempt {attempt+1})")
                return s
            time.sleep(self.POLL_INTERVAL)
        return self.get_order_status(order_id)  # return latest even if not terminal


def _human_status(status: str, reason: str = "") -> str:
    MAP = {
        "init":               "Order Created (queued)",
        "open":               "Order Active on Exchange",
        "partially_filled":   "Partially Filled",
        "filled":             "Filled ✓",
        "partially_cancelled":"Partial Fill — Cancelled",
        "cancelled":          "Cancelled",
    }
    if status == "rejected":
        return f"Rejected: {reason}" if reason else "Rejected"
    return MAP.get(status, status)


# ── Live Wallet (tracks positions + P&L from real fills) ────────────────────
class LiveWallet:
    """Tracks our own live positions + P&L alongside the real CoinDCX account."""

    def __init__(self, adapter: CoinDCXLiveAdapter):
        self._a          = adapter
        self.positions: dict[str, dict] = {}
        self.trade_log: list[dict] = []
        self.pnl_realized = 0.0

    def record(self, sym, side, qty, fill_price, fee, order_id, client_id,
               strategy_id=None, strategy_name=None):
        if side == "BUY":
            p = self.positions.get(sym, {"qty":0,"avg_price":0,"cost":0})
            new_qty  = p["qty"] + qty
            new_cost = p["cost"] + qty * fill_price
            self.positions[sym] = {
                "qty": new_qty, "avg_price": new_cost/new_qty if new_qty else fill_price,
                "cost": new_cost, "strategy_id": strategy_id, "strategy_name": strategy_name
            }
        else:
            p = self.positions.get(sym, {})
            avg = p.get("avg_price", fill_price)
            self.pnl_realized += (fill_price - avg) * qty - fee
            p["qty"] = max(0, p.get("qty", 0) - qty)
            p["cost"] = max(0, p.get("cost", 0) - avg * qty)
            if p["qty"] < 1e-9:
                self.positions.pop(sym, None)
            else:
                self.positions[sym] = p

        self.trade_log.append({
            "trade_id": _uid(), "order_id": order_id, "client_order_id": client_id,
            "symbol": sym, "side": side, "quantity": qty, "fill_price": fill_price,
            "fee": fee, "timestamp_ms": _ts(), "mode": "live",
            "strategy_id": strategy_id, "strategy_name": strategy_name,
        })

    def get_full(self) -> dict:
        try:
            balances = self._a.get_balances()
        except Exception as e:
            return {"error": str(e), "balance_inr": 0, "positions": {},
                    "pnl_realized": 0, "pnl_unrealized": 0, "trade_count": 0}

        inr_balance = 0.0
        positions   = {}
        for b in balances:
            currency = b.get("currency_short_name","")
            total    = float(b.get("balance",0) or 0) + float(b.get("locked_balance",0) or 0)
            if total <= 0: continue
            if currency == "INR":
                inr_balance = total; continue
            price = _price_cache.price(currency)
            lp    = self.positions.get(currency, {})
            avg   = lp.get("avg_price", price)
            upnl  = (price - avg) * total if avg else 0
            positions[currency] = {
                "qty": round(total, 8), "current_price": round(price,2),
                "value_inr": round(total * price, 2),
                "avg_price": round(avg, 2),
                "unrealized_pnl": round(upnl, 2),
                "unrealized_pnl_pct": round(upnl/(avg*total)*100,4) if avg*total else 0,
                "strategy_id": lp.get("strategy_id"),
                "strategy_name": lp.get("strategy_name"),
            }

        upnl_total = sum(p["unrealized_pnl"] for p in positions.values())
        portfolio  = inr_balance + sum(p["value_inr"] for p in positions.values())
        return {
            "balance_inr": round(inr_balance,2), "portfolio_value": round(portfolio,2),
            "pnl_realized": round(self.pnl_realized,2), "pnl_unrealized": round(upnl_total,2),
            "total_pnl": round(self.pnl_realized + upnl_total, 2),
            "positions": positions, "trade_count": len(self.trade_log),
            "recent_trades": self.trade_log[-30:],
        }


# ── Execution Engine ──────────────────────────────────────────────────────────
class ExecutionEngine:
    def __init__(self, mode="paper", initial_capital=1_000_000.0,
                 max_position_pct=5.0, max_daily_trades=50, stop_loss_pct=2.0):
        self.mode        = ExecutionMode(mode)
        self.wallet      = PaperWallet(initial_capital)
        self.risk        = RiskGuard(max_position_pct, max_daily_trades, stop_loss_pct)
        self._adapter    = CoinDCXLiveAdapter()
        self._live_wallet= LiveWallet(self._adapter)

    def set_mode(self, mode: str):
        self.mode = ExecutionMode(mode)

    # ── Trading ──────────────────────────────────────────────────────────────

    def place_market_buy(self, symbol, quantity, capital=None,
                          strategy_id=None, strategy_name=None) -> TradeResult:
        price = _price_cache.price(symbol)
        cap   = capital or self.wallet.portfolio_value()
        rc    = self.risk.check(symbol, quantity, price, cap)
        if not rc.passed:
            return _risk_fail(symbol, "BUY", quantity, price, self.mode.value, rc.reason,
                              strategy_id, strategy_name)
        if self.mode in (ExecutionMode.PAPER, ExecutionMode.SAFE):
            r = self.wallet.fill_buy(symbol, quantity, price, strategy_id, strategy_name)
            self.risk.record(); return r
        return self._live_trade("buy", symbol, quantity, strategy_id, strategy_name)

    def place_market_sell(self, symbol, quantity, capital=None,
                           strategy_id=None, strategy_name=None) -> TradeResult:
        price = _price_cache.price(symbol)
        cap   = capital or self.wallet.portfolio_value()
        rc    = self.risk.check(symbol, quantity, price, cap)
        if not rc.passed:
            return _risk_fail(symbol, "SELL", quantity, price, self.mode.value, rc.reason,
                              strategy_id, strategy_name)
        if self.mode in (ExecutionMode.PAPER, ExecutionMode.SAFE):
            r = self.wallet.fill_sell(symbol, quantity, price, strategy_id, strategy_name)
            self.risk.record(); return r
        return self._live_trade("sell", symbol, quantity, strategy_id, strategy_name)

    def close_position(self, symbol) -> TradeResult:
        if self.mode in (ExecutionMode.PAPER, ExecutionMode.SAFE):
            return self.wallet.close_position(symbol, _price_cache.price(symbol))
        pos = self._live_wallet.positions.get(symbol)
        if not pos:
            return TradeResult(trade_id=_uid(), symbol=symbol, side="SELL", quantity=0,
                fill_price=_price_cache.price(symbol), fill_time_ms=_ts(),
                fee=0, net_pnl=0, mode="live", success=False, error="No live position")
        return self._live_trade("sell", symbol, pos["qty"],
                                 pos.get("strategy_id"), pos.get("strategy_name"))

    def _live_trade(self, side, symbol, qty, strategy_id, strategy_name) -> TradeResult:
        market = CDX_MARKET.get(symbol.upper(), symbol.upper() + "INR")
        try:
            resp = self._adapter.place_order(
                market=market, side=side, qty=qty,
                strategy_id=strategy_id, strategy_name=strategy_name,
            )
        except Exception as e:
            return TradeResult(
                trade_id=_uid(), symbol=symbol, side=side.upper(), quantity=qty,
                fill_price=_price_cache.price(symbol), fill_time_ms=_ts(),
                fee=0, net_pnl=0, mode="live", success=False,
                error=str(e), order_status="error",
                strategy_id=strategy_id, strategy_name=strategy_name,
            )

        order_id  = str(resp.get("id",""))
        client_id = resp.get("_client_order_id","")
        print(f"[Live] Placed {side.upper()} {qty} {market} → {order_id} ({resp.get('status','')})")

        # Poll for fill
        if order_id:
            final = self._adapter.poll_order(order_id)
            ok    = final["status"] in ("filled","partially_filled")
            fp    = final["avg_fill_price"] or _price_cache.price(symbol)
            fq    = final["filled_qty"] or qty
            fee   = final["fee"]
            if ok:
                self._live_wallet.record(symbol, side.upper(), fq, fp, fee,
                                          order_id, client_id, strategy_id, strategy_name)
                self.risk.record()
            return TradeResult(
                trade_id=_uid(), order_id=order_id, client_order_id=client_id,
                symbol=symbol, side=side.upper(), quantity=fq, fill_price=fp,
                fill_time_ms=_ts(), fee=round(fee,4), net_pnl=0, mode="live",
                success=ok, error=final["reject_reason"] if not ok else None,
                order_status=final["status"], reject_reason=final["reject_reason"],
                strategy_id=strategy_id, strategy_name=strategy_name,
            )
        # Order placement returned no id (rare)
        return TradeResult(
            trade_id=_uid(), symbol=symbol, side=side.upper(), quantity=qty,
            fill_price=_price_cache.price(symbol), fill_time_ms=_ts(),
            fee=0, net_pnl=0, mode="live", success=False,
            error=resp.get("message","No order ID returned"), order_status="unknown",
            strategy_id=strategy_id, strategy_name=strategy_name,
        )

    # ── Wallet / State ───────────────────────────────────────────────────────

    def get_wallet_state(self) -> dict:
        if self.mode == ExecutionMode.LIVE and self._adapter.ready:
            w = self._live_wallet.get_full()
            w["mode"] = "live"; return w
        w = self.wallet.to_dict()
        w["mode"] = self.mode.value
        w["recent_trades"] = list(reversed(self.wallet.trade_log[-30:]))
        return w

    def get_trade_log(self, limit=50) -> list[dict]:
        if self.mode == ExecutionMode.LIVE:
            return self._live_wallet.trade_log[-limit:]
        return list(reversed(self.wallet.trade_log[-limit:]))

    def get_strategy_pnl(self, strategy_id: str) -> dict:
        """Attribution: realized P&L, fees and trades for a given strategy."""
        log = (self._live_wallet.trade_log if self.mode == ExecutionMode.LIVE
               else self.wallet.trade_log)
        trades = [t for t in log if t.get("strategy_id") == strategy_id]
        return {
            "strategy_id":  strategy_id,
            "total_trades": len(trades),
            "buy_count":    sum(1 for t in trades if t["side"]=="BUY"),
            "sell_count":   sum(1 for t in trades if t["side"]=="SELL"),
            "realized_pnl": round(sum(t.get("net_pnl",0) for t in trades), 2),
            "total_fees":   round(sum(t.get("fee",0) for t in trades), 4),
            "trades":       trades[-20:],
        }

    def get_order_status(self, order_id: str) -> dict:
        if not self._adapter.ready:
            return {"error": "Live adapter not configured"}
        return self._adapter.get_order_status(order_id)

    def get_live_prices(self) -> dict:
        return _price_cache.all()

    def get_price(self, symbol: str) -> float:
        return _price_cache.price(symbol)

    # ── Risk ──────────────────────────────────────────────────────────────────

    def engage_kill_switch(self):  self.risk.engage_kill_switch()
    def release_kill_switch(self): self.risk.release_kill_switch()

    def get_risk_config(self) -> dict:
        return self.risk.to_dict()

    def set_risk_config(self, **kw):
        if "max_position_pct" in kw: self.risk.max_pos_pct = float(kw["max_position_pct"])
        if "max_daily_trades" in kw: self.risk.max_daily   = int(kw["max_daily_trades"])
        if "stop_loss_pct"    in kw: self.risk.sl_pct      = float(kw["stop_loss_pct"])


# ── Helpers ───────────────────────────────────────────────────────────────────
def _uid(): return str(uuid.uuid4())[:8]
def _ts():  return int(time.time() * 1000)

def _risk_fail(sym, side, qty, price, mode, reason, sid, sname):
    return TradeResult(trade_id=_uid(), symbol=sym, side=side, quantity=qty,
        fill_price=price, fill_time_ms=_ts(), fee=0, net_pnl=0, mode=mode,
        success=False, error=f"Risk: {reason}", strategy_id=sid, strategy_name=sname)


# Module-level helpers used by api_server
def get_live_price(symbol: str) -> float:
    return _price_cache.price(symbol)

def get_all_live_prices() -> dict:
    return _price_cache.all()
