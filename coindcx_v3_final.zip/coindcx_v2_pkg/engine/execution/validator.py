"""
CoinDCX Algo Platform — Strategy Code Validator

Runs BEFORE a strategy is deployed (paper or live).
Uses AST analysis — never executes user code during validation.

Checks:
  1. Syntax validity (Python AST parse)
  2. Required on_bar() method present
  3. No forbidden imports (os.system, subprocess, socket.connect to unknown hosts)
  4. No infinite loops without yield/sleep
  5. No file system writes
  6. No __import__ or exec/eval usage
  7. Resource usage estimates (complexity score)
  8. Parameter schema validation
"""

from __future__ import annotations

import ast
import re
from dataclasses import dataclass, field
from typing import Optional


FORBIDDEN_IMPORTS = {
    "subprocess", "os.system", "pty", "pexpect",
    "ctypes", "cffi", "socket",
    "multiprocessing", "threading",
    "importlib", "builtins",
}

FORBIDDEN_CALLS = {
    "exec", "eval", "__import__", "compile",
    "open", "os.remove", "os.unlink", "shutil",
    "requests", "urllib.request",
}

ALLOWED_IMPORTS = {
    "math", "decimal", "datetime", "time", "collections",
    "itertools", "functools", "typing", "dataclasses",
    "numpy", "pandas", "scipy",
    "coindcx_algo",
}


@dataclass
class ValidationIssue:
    severity: str   # "error" | "warning" | "info"
    code: str
    message: str
    line: Optional[int] = None


@dataclass
class ValidationResult:
    is_valid: bool
    issues: list[ValidationIssue] = field(default_factory=list)
    strategy_class_name: Optional[str] = None
    detected_symbols: list[str] = field(default_factory=list)
    detected_resolution: Optional[str] = None
    complexity_score: int = 0   # 0-100, higher = more resource intensive

    @property
    def errors(self):
        return [i for i in self.issues if i.severity == "error"]

    @property
    def warnings(self):
        return [i for i in self.issues if i.severity == "warning"]


class StrategyValidator:
    """AST-based static analysis for user strategy code."""

    def validate(self, code: str, params: dict = None) -> ValidationResult:
        result = ValidationResult(is_valid=True)

        # 1. Syntax check
        try:
            tree = ast.parse(code)
        except SyntaxError as e:
            result.is_valid = False
            result.issues.append(ValidationIssue(
                severity="error",
                code="SYNTAX_ERROR",
                message=f"Syntax error at line {e.lineno}: {e.msg}",
                line=e.lineno,
            ))
            return result

        # 2. Import analysis
        self._check_imports(tree, result)

        # 3. Find BaseStrategy subclass
        self._find_strategy_class(tree, result)

        # 4. Check for forbidden function calls
        self._check_forbidden_calls(tree, result)

        # 5. Check for dangerous patterns
        self._check_dangerous_patterns(code, result)

        # 6. Complexity estimation
        result.complexity_score = self._estimate_complexity(tree)

        # 7. Final validity
        result.is_valid = len(result.errors) == 0
        return result

    def _check_imports(self, tree: ast.AST, result: ValidationResult) -> None:
        for node in ast.walk(tree):
            if isinstance(node, (ast.Import, ast.ImportFrom)):
                if isinstance(node, ast.Import):
                    names = [alias.name for alias in node.names]
                else:
                    names = [node.module] if node.module else []

                for name in names:
                    if name and any(name.startswith(f) for f in FORBIDDEN_IMPORTS):
                        result.issues.append(ValidationIssue(
                            severity="error",
                            code="FORBIDDEN_IMPORT",
                            message=f"Import of '{name}' is not allowed in strategies",
                            line=node.lineno,
                        ))
                    elif name and not any(name.startswith(a) for a in ALLOWED_IMPORTS):
                        result.issues.append(ValidationIssue(
                            severity="warning",
                            code="UNKNOWN_IMPORT",
                            message=f"Import '{name}' may not be available in the sandbox",
                            line=node.lineno,
                        ))

    def _find_strategy_class(self, tree: ast.AST, result: ValidationResult) -> None:
        strategy_classes = []
        for node in ast.walk(tree):
            if isinstance(node, ast.ClassDef):
                bases = [getattr(b, 'id', getattr(b, 'attr', '')) for b in node.bases]
                if 'BaseStrategy' in bases:
                    strategy_classes.append(node)
                    # Check for on_bar method
                    methods = {n.name for n in ast.walk(node) if isinstance(n, ast.FunctionDef)}
                    if 'on_bar' not in methods:
                        result.issues.append(ValidationIssue(
                            severity="error",
                            code="MISSING_ON_BAR",
                            message=f"Class '{node.name}' must implement on_bar(self, bar) method",
                            line=node.lineno,
                        ))
                    # Extract SYMBOL/SYMBOLS attributes
                    for child in ast.walk(node):
                        if isinstance(child, ast.Assign):
                            for target in child.targets:
                                if isinstance(target, ast.Name):
                                    if target.id == 'SYMBOL' and isinstance(child.value, ast.Constant):
                                        result.detected_symbols = [child.value.value]
                                    elif target.id == 'RESOLUTION' and isinstance(child.value, ast.Constant):
                                        result.detected_resolution = child.value.value

        if not strategy_classes:
            result.issues.append(ValidationIssue(
                severity="error",
                code="NO_STRATEGY_CLASS",
                message="No class inheriting from BaseStrategy found",
            ))
        elif len(strategy_classes) == 1:
            result.strategy_class_name = strategy_classes[0].name
        else:
            result.strategy_class_name = strategy_classes[-1].name
            result.issues.append(ValidationIssue(
                severity="warning",
                code="MULTIPLE_CLASSES",
                message=f"Multiple BaseStrategy subclasses found; using '{result.strategy_class_name}'",
            ))

    def _check_forbidden_calls(self, tree: ast.AST, result: ValidationResult) -> None:
        for node in ast.walk(tree):
            if isinstance(node, ast.Call):
                func_name = ""
                if isinstance(node.func, ast.Name):
                    func_name = node.func.id
                elif isinstance(node.func, ast.Attribute):
                    func_name = node.func.attr

                if func_name in FORBIDDEN_CALLS:
                    result.issues.append(ValidationIssue(
                        severity="error",
                        code="FORBIDDEN_CALL",
                        message=f"Call to '{func_name}' is not allowed in strategies",
                        line=node.lineno,
                    ))

    def _check_dangerous_patterns(self, code: str, result: ValidationResult) -> None:
        patterns = [
            (r'while\s+True\s*:', "INFINITE_LOOP",
             "Infinite loop detected — use on_bar() instead of while True"),
            (r'__[a-z]+__\s*=', "DUNDER_ASSIGN",
             "Assignment to dunder attributes is not allowed"),
            (r'globals\(\)|locals\(\)', "INTROSPECTION",
             "globals()/locals() calls are not allowed"),
        ]
        for pattern, code_id, message in patterns:
            if re.search(pattern, code):
                result.issues.append(ValidationIssue(
                    severity="warning",
                    code=code_id,
                    message=message,
                ))

    def _estimate_complexity(self, tree: ast.AST) -> int:
        score = 0
        for node in ast.walk(tree):
            if isinstance(node, (ast.For, ast.While, ast.comprehension)):
                score += 10
            elif isinstance(node, (ast.If, ast.IfExp)):
                score += 2
            elif isinstance(node, ast.Call):
                score += 1
        return min(score, 100)
