"""
CoinDCX Algo Platform — Strategy Sandbox Runner

This is the entrypoint for each strategy container pod.
It:
  1. Loads strategy config from environment / mounted config file
  2. Authenticates with the platform control plane
  3. Connects to market data Redis pub/sub
  4. Instantiates the user's strategy class
  5. Runs the event loop indefinitely
  6. Reports health, metrics, and order events back to platform

Security model:
  - Runs as non-root (sandbox user)
  - No direct DB access — all platform calls go through REST API
  - Network egress restricted to: exchange APIs, platform API, Redis
  - CPU and memory limits enforced by Kubernetes cgroup
  - Strategy code is loaded from a mounted read-only volume
  - Any uncaught exception stops the runner (pod restarts via K8s)

Communication:
  - Market data IN:  Redis pub/sub channels (tick.{symbol}, bar.{symbol}.{resolution})
  - Order events OUT: Platform API POST /internal/order-events
  - Health OUT:      HTTP /health endpoint on port 8080
  - Metrics OUT:     Prometheus /metrics on port 8080
"""

from __future__ import annotations

import asyncio
import importlib.util
import json
import logging
import os
import signal
import sys
import time
from decimal import Decimal
from pathlib import Path
from typing import Optional

import aiohttp
import redis.asyncio as aioredis

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s [%(name)s] %(message)s",
    stream=sys.stdout,
)
logger = logging.getLogger("sandbox.runner")


# ---------------------------------------------------------------------------
# Config from environment
# ---------------------------------------------------------------------------

class SandboxConfig:
    strategy_id: str = os.environ["STRATEGY_ID"]
    user_id: str = os.environ["USER_ID"]
    deployment_id: str = os.environ["DEPLOYMENT_ID"]
    mode: str = os.environ.get("MODE", "paper")             # live | paper | backtest
    exchange: str = os.environ.get("EXCHANGE", "coindcx")

    # Redis for market data
    redis_url: str = os.environ.get("REDIS_URL", "redis://localhost:6379")

    # Platform API for order submission and state reporting
    platform_api_url: str = os.environ.get("PLATFORM_API_URL", "http://api-service:8000")
    platform_token: str = os.environ["PLATFORM_INTERNAL_TOKEN"]

    # Exchange credentials (decrypted by platform, injected as env vars)
    exchange_api_key: str = os.environ.get("EXCHANGE_API_KEY", "")
    exchange_api_secret: str = os.environ.get("EXCHANGE_API_SECRET", "")

    # Strategy params injected as JSON string
    strategy_params: dict = json.loads(os.environ.get("STRATEGY_PARAMS", "{}"))

    # Strategy code path (mounted read-only volume)
    strategy_file: str = os.environ.get("STRATEGY_FILE", "/strategy/user_strategy.py")

    # Resource limits (soft limits — cgroup enforces hard limits)
    max_memory_mb: int = int(os.environ.get("MAX_MEMORY_MB", "512"))
    max_bars_buffer: int = int(os.environ.get("MAX_BARS_BUFFER", "500"))


config = SandboxConfig()


# ---------------------------------------------------------------------------
# Dynamic strategy loader
# ---------------------------------------------------------------------------

def load_strategy_class(file_path: str):
    """
    Dynamically load a user's strategy class from a Python file.
    The file must define exactly one class that inherits from BaseStrategy.
    """
    path = Path(file_path)
    if not path.exists():
        raise FileNotFoundError(f"Strategy file not found: {file_path}")

    spec = importlib.util.spec_from_file_location("user_strategy", path)
    module = importlib.util.module_from_spec(spec)

    try:
        spec.loader.exec_module(module)
    except Exception as e:
        raise RuntimeError(f"Strategy code failed to load: {e}") from e

    # Find the strategy class
    from coindcx_algo.sdk.strategy import BaseStrategy
    strategy_classes = [
        obj for name, obj in vars(module).items()
        if isinstance(obj, type)
        and issubclass(obj, BaseStrategy)
        and obj is not BaseStrategy
    ]

    if not strategy_classes:
        raise ValueError("No class inheriting BaseStrategy found in strategy file")
    if len(strategy_classes) > 1:
        # Take the last defined class (most likely the main one)
        logger.warning(
            f"Multiple BaseStrategy subclasses found: {[c.__name__ for c in strategy_classes]}. "
            f"Using {strategy_classes[-1].__name__}"
        )

    return strategy_classes[-1]


# ---------------------------------------------------------------------------
# Platform API client
# ---------------------------------------------------------------------------

class PlatformClient:
    """Communicates with the platform control plane API."""

    def __init__(self, base_url: str, token: str, session: aiohttp.ClientSession):
        self._base = base_url
        self._headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
            "X-Deployment-ID": config.deployment_id,
        }
        self._session = session

    async def report_order(self, order_data: dict) -> None:
        """Report order state change to the platform OMS."""
        try:
            async with self._session.post(
                f"{self._base}/internal/order-events",
                json=order_data,
                headers=self._headers,
                timeout=aiohttp.ClientTimeout(total=5),
            ) as resp:
                if resp.status >= 400:
                    logger.warning(f"Order report failed: {resp.status}")
        except Exception as e:
            logger.error(f"Failed to report order: {e}")

    async def report_heartbeat(self, metrics: dict) -> None:
        """Send heartbeat with runtime metrics to the platform."""
        try:
            async with self._session.post(
                f"{self._base}/internal/strategy-heartbeat",
                json={
                    "strategy_id": config.strategy_id,
                    "deployment_id": config.deployment_id,
                    "timestamp_ms": int(time.time() * 1000),
                    **metrics,
                },
                headers=self._headers,
                timeout=aiohttp.ClientTimeout(total=3),
            ) as resp:
                pass
        except Exception as e:
            logger.debug(f"Heartbeat failed (non-critical): {e}")

    async def get_initial_portfolio(self) -> dict:
        """Fetch initial portfolio state from the platform."""
        try:
            async with self._session.get(
                f"{self._base}/internal/portfolio/{config.strategy_id}",
                headers=self._headers,
            ) as resp:
                return await resp.json()
        except Exception as e:
            logger.warning(f"Could not fetch initial portfolio: {e}")
            return {}

    async def get_risk_config(self) -> dict:
        """Fetch risk configuration for this strategy."""
        try:
            async with self._session.get(
                f"{self._base}/internal/risk-config/{config.strategy_id}",
                headers=self._headers,
            ) as resp:
                return await resp.json()
        except Exception as e:
            logger.warning(f"Could not fetch risk config: {e}")
            return {}


# ---------------------------------------------------------------------------
# Market data subscriber
# ---------------------------------------------------------------------------

class MarketDataSubscriber:
    """
    Subscribes to Redis pub/sub channels for market data.
    Decouples the exchange WebSocket from strategy execution.

    Channel naming convention:
      tick.{symbol}              — individual trade events
      bar.{symbol}.{resolution}  — completed OHLCV bars
      orderbook.{symbol}         — order book snapshots
      funding.{symbol}           — funding rate updates (futures)
    """

    def __init__(self, redis_client: aioredis.Redis):
        self._redis = redis_client
        self._pubsub: Optional[aioredis.client.PubSub] = None
        self._handlers: dict[str, list] = {}

    def on_bar(self, symbol: str, resolution: str, callback) -> None:
        channel = f"bar.{symbol}.{resolution}"
        self._handlers.setdefault(channel, []).append(callback)

    def on_tick(self, symbol: str, callback) -> None:
        channel = f"tick.{symbol}"
        self._handlers.setdefault(channel, []).append(callback)

    def on_funding(self, symbol: str, callback) -> None:
        channel = f"funding.{symbol}"
        self._handlers.setdefault(channel, []).append(callback)

    async def start(self) -> None:
        """Subscribe to all registered channels and start dispatching."""
        self._pubsub = self._redis.pubsub()
        channels = list(self._handlers.keys())
        if not channels:
            logger.warning("No market data channels subscribed")
            return

        await self._pubsub.subscribe(*channels)
        logger.info(f"Subscribed to market data channels: {channels}")
        asyncio.ensure_future(self._dispatch_loop())

    async def _dispatch_loop(self) -> None:
        """Continuously read messages and dispatch to handlers."""
        async for message in self._pubsub.listen():
            if message["type"] != "message":
                continue
            channel = message["channel"].decode()
            try:
                data = json.loads(message["data"])
                for handler in self._handlers.get(channel, []):
                    await self._safe_call(handler, data, channel)
            except json.JSONDecodeError as e:
                logger.warning(f"Invalid JSON on channel {channel}: {e}")
            except Exception as e:
                logger.error(f"Dispatch error on {channel}: {e}")

    async def _safe_call(self, handler, data: dict, channel: str) -> None:
        try:
            if asyncio.iscoroutinefunction(handler):
                await handler(data)
            else:
                handler(data)
        except Exception as e:
            logger.error(f"Handler error for {channel}: {e}", exc_info=True)

    async def stop(self) -> None:
        if self._pubsub:
            await self._pubsub.unsubscribe()
            await self._pubsub.close()


# ---------------------------------------------------------------------------
# Main runner
# ---------------------------------------------------------------------------

class StrategyRunner:
    """
    Orchestrates the full lifecycle of a running strategy instance.
    One runner per Kubernetes pod.
    """

    def __init__(self):
        self._running = False
        self._session: Optional[aiohttp.ClientSession] = None
        self._redis: Optional[aioredis.Redis] = None
        self._platform: Optional[PlatformClient] = None
        self._market_data: Optional[MarketDataSubscriber] = None
        self._strategy = None
        self._oms = None
        self._bars_received = 0
        self._orders_placed = 0
        self._start_time = 0.0

    async def start(self) -> None:
        logger.info(
            f"Starting strategy runner: "
            f"strategy_id={config.strategy_id}, "
            f"mode={config.mode}, "
            f"exchange={config.exchange}"
        )
        self._start_time = time.time()

        # Setup HTTP session
        self._session = aiohttp.ClientSession(
            timeout=aiohttp.ClientTimeout(total=30),
            connector=aiohttp.TCPConnector(limit=20),
        )

        # Setup Redis
        self._redis = await aioredis.from_url(
            config.redis_url,
            encoding="utf-8",
            decode_responses=False,
            socket_keepalive=True,
        )
        await self._redis.ping()
        logger.info("Redis connected")

        # Setup platform client
        self._platform = PlatformClient(
            config.platform_api_url,
            config.platform_token,
            self._session,
        )

        # Fetch initial state
        portfolio_data = await self._platform.get_initial_portfolio()
        risk_config_data = await self._platform.get_risk_config()

        # Build portfolio
        from coindcx_algo.sdk.models import Portfolio
        portfolio = Portfolio(
            strategy_id=config.strategy_id,
            base_currency="USDT",
            balances={"USDT": Decimal(str(portfolio_data.get("usdt_balance", "10000")))},
        )

        # Build exchange adapter
        adapter = self._build_exchange_adapter()

        # Build risk components
        from coindcx_algo.risk.engine import StrategyRiskConfig, StrategyRiskState
        risk_config = StrategyRiskConfig(
            strategy_id=config.strategy_id,
            **{k: v for k, v in risk_config_data.items() if k != "strategy_id"},
        )
        risk_state = StrategyRiskState(
            strategy_id=config.strategy_id,
            session_start_equity=portfolio.total_equity,
            session_high_equity=portfolio.total_equity,
            daily_start_equity=portfolio.total_equity,
        )

        # Build OMS
        from coindcx_algo.engine.oms.order_manager import OrderManagementSystem
        self._oms = OrderManagementSystem(
            strategy_id=config.strategy_id,
            user_id=config.user_id,
            exchange_adapter=adapter,
            portfolio=portfolio,
            risk_config=risk_config,
            risk_state=risk_state,
            on_order_event=self._on_order_event,
            dry_run=(config.mode == "paper"),
        )

        # Load strategy class
        strategy_class = load_strategy_class(config.strategy_file)
        logger.info(f"Loaded strategy class: {strategy_class.__name__}")

        # Build strategy context
        from coindcx_algo.sdk.strategy import StrategyContext
        context = StrategyContext(
            strategy_id=config.strategy_id,
            user_id=config.user_id,
            mode=config.mode,
            exchange=config.exchange,
        )

        # Instantiate strategy
        self._strategy = strategy_class(
            strategy_id=config.strategy_id,
            params=config.strategy_params,
            context=context,
            order_callback=self._oms.submit_order,
            cancel_callback=self._oms.cancel_order,
            portfolio=portfolio,
        )

        # Setup market data subscriptions
        self._market_data = MarketDataSubscriber(self._redis)
        self._setup_subscriptions()

        # Call strategy on_start
        self._strategy.on_start()
        logger.info("Strategy on_start() completed")

        # Start market data
        await self._market_data.start()

        # Subscribe to exchange order updates (live mode only)
        if config.mode == "live":
            await adapter.subscribe_order_updates(
                lambda order: asyncio.ensure_future(self._oms.handle_order_update(order))
            )

        self._running = True
        logger.info("Strategy runner is live")

        # Start heartbeat loop
        asyncio.ensure_future(self._heartbeat_loop())

        # Block until shutdown signal
        await self._wait_for_shutdown()

    def _setup_subscriptions(self) -> None:
        """Wire up market data channels to strategy handlers."""
        symbols = getattr(self._strategy, "SYMBOLS", None) or [self._strategy.SYMBOL]
        resolution = getattr(self._strategy, "RESOLUTION", "1h")

        for symbol in symbols:
            self._market_data.on_bar(
                symbol, resolution,
                lambda data, s=symbol: self._dispatch_bar(data, s)
            )
            self._market_data.on_tick(
                symbol,
                lambda data, s=symbol: self._dispatch_tick(data, s)
            )
            self._market_data.on_funding(
                symbol,
                lambda data, s=symbol: self._dispatch_funding(data, s)
            )

    def _dispatch_bar(self, data: dict, symbol: str) -> None:
        try:
            from coindcx_algo.sdk.models import Bar
            bar = Bar(
                symbol=symbol,
                open=Decimal(str(data["open"])),
                high=Decimal(str(data["high"])),
                low=Decimal(str(data["low"])),
                close=Decimal(str(data["close"])),
                volume=Decimal(str(data["volume"])),
                timestamp_ms=int(data["timestamp_ms"]),
                resolution=data.get("resolution", "1h"),
            )
            self._strategy._handle_bar(bar)
            self._bars_received += 1
        except Exception as e:
            logger.error(f"Bar dispatch error: {e}", exc_info=True)

    def _dispatch_tick(self, data: dict, symbol: str) -> None:
        try:
            from coindcx_algo.sdk.models import Tick, OrderSide
            tick = Tick(
                symbol=symbol,
                price=Decimal(str(data["price"])),
                quantity=Decimal(str(data["quantity"])),
                side=OrderSide(data.get("side", "buy")),
                timestamp_ms=int(data["timestamp_ms"]),
            )
            self._strategy._handle_tick(tick)
        except Exception as e:
            logger.error(f"Tick dispatch error: {e}", exc_info=True)

    def _dispatch_funding(self, data: dict, symbol: str) -> None:
        try:
            from coindcx_algo.sdk.models import FundingRate
            funding = FundingRate(
                symbol=symbol,
                rate=Decimal(str(data["rate"])),
                next_funding_ms=int(data["next_funding_ms"]),
                timestamp_ms=int(data["timestamp_ms"]),
            )
            self._strategy.on_funding(funding)
        except Exception as e:
            logger.error(f"Funding dispatch error: {e}", exc_info=True)

    def _on_order_event(self, order) -> None:
        """Called by OMS when any order event occurs — report to platform."""
        asyncio.ensure_future(self._platform.report_order({
            "strategy_id": config.strategy_id,
            "deployment_id": config.deployment_id,
            "order_id": order.order_id,
            "exchange_order_id": order.exchange_order_id,
            "symbol": order.symbol,
            "side": order.side.value,
            "status": order.status.value,
            "quantity": str(order.quantity),
            "filled_quantity": str(order.filled_quantity),
            "avg_fill_price": str(order.avg_fill_price) if order.avg_fill_price else None,
            "fees_paid": str(order.fees_paid),
            "timestamp_ms": int(time.time() * 1000),
        }))
        if order.status.value == "filled":
            self._orders_placed += 1

    async def _heartbeat_loop(self) -> None:
        """Send heartbeat every 30 seconds with current runner metrics."""
        while self._running:
            uptime = time.time() - self._start_time
            await self._platform.report_heartbeat({
                "status": "running",
                "uptime_s": int(uptime),
                "bars_received": self._bars_received,
                "orders_placed": self._orders_placed,
                "equity": str(self._strategy.equity()) if self._strategy else "0",
                "drawdown_pct": str(self._strategy.drawdown()) if self._strategy else "0",
                "mode": config.mode,
            })
            await asyncio.sleep(30)

    async def _wait_for_shutdown(self) -> None:
        """Wait for SIGTERM or SIGINT, then gracefully shut down."""
        shutdown_event = asyncio.Event()

        def _handle_signal():
            logger.info("Shutdown signal received")
            shutdown_event.set()

        loop = asyncio.get_event_loop()
        for sig in (signal.SIGTERM, signal.SIGINT):
            loop.add_signal_handler(sig, _handle_signal)

        await shutdown_event.wait()
        await self._shutdown()

    async def _shutdown(self) -> None:
        logger.info("Graceful shutdown initiated")
        self._running = False

        # Call strategy on_stop
        if self._strategy:
            try:
                self._strategy.on_stop()
            except Exception as e:
                logger.error(f"on_stop() error: {e}")

        # Cancel all open orders (optional — depends on user config)
        if self._oms:
            cancelled = await self._oms.cancel_all()
            logger.info(f"Cancelled {cancelled} open orders on shutdown")

        # Clean up connections
        if self._market_data:
            await self._market_data.stop()
        if self._redis:
            await self._redis.close()
        if self._session:
            await self._session.close()

        logger.info("Strategy runner shutdown complete")

    def _build_exchange_adapter(self):
        from coindcx_algo.exchange.adapters import CoinDCXAdapter, BinanceAdapter
        if config.exchange == "binance":
            return BinanceAdapter(
                api_key=config.exchange_api_key,
                api_secret=config.exchange_api_secret,
                sandbox=(config.mode != "live"),
            )
        return CoinDCXAdapter(
            api_key=config.exchange_api_key,
            api_secret=config.exchange_api_secret,
            sandbox=(config.mode != "live"),
        )


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

async def main():
    runner = StrategyRunner()
    try:
        await runner.start()
    except FileNotFoundError as e:
        logger.critical(f"Strategy file error: {e}")
        sys.exit(1)
    except RuntimeError as e:
        logger.critical(f"Strategy runtime error: {e}")
        sys.exit(1)
    except Exception as e:
        logger.critical(f"Unexpected runner error: {e}", exc_info=True)
        sys.exit(1)


if __name__ == "__main__":
    asyncio.run(main())
