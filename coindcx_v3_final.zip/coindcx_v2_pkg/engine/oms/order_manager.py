"""
CoinDCX Algo Platform — Order Management System (OMS)

The OMS is the single source of truth for all orders on the platform.
No order reaches the exchange without going through the OMS.
No order is considered filled without the OMS acknowledging it.

Responsibilities:
  - Accept order requests from strategy runners
  - Run pre-trade risk checks
  - Generate idempotent order IDs
  - Forward orders to exchange adapters
  - Track order state through its full lifecycle
  - Handle partial fills
  - Reconcile against exchange state on startup
  - Emit order events to Kafka for audit and analytics
  - Update portfolio positions on fills

Order state machine:
  PENDING → OPEN → PARTIALLY_FILLED → FILLED
                ↘ CANCELLED
                ↘ REJECTED
                ↘ EXPIRED
"""

from __future__ import annotations

import asyncio
import logging
import uuid
from decimal import Decimal
from typing import Optional, Callable
from datetime import datetime, timezone

from sdk.models import (
    Order, OrderRequest, OrderStatus, Fill,
    Portfolio, Position, PositionSide, MarketType
)
from exchange.adapters import ExchangeAdapter
from risk.engine import RiskEngine, StrategyRiskConfig, StrategyRiskState, get_risk_engine

logger = logging.getLogger(__name__)


class OrderManagementSystem:
    """
    Central OMS for a strategy runner instance.

    One OMS instance per running strategy.
    The engine creates it, injects the exchange adapter, and passes it to the strategy.
    """

    def __init__(
        self,
        strategy_id: str,
        user_id: str,
        exchange_adapter: ExchangeAdapter,
        portfolio: Portfolio,
        risk_config: StrategyRiskConfig,
        risk_state: StrategyRiskState,
        on_order_event: Optional[Callable[[Order], None]] = None,
        on_fill_event: Optional[Callable[[Order, Fill], None]] = None,
        dry_run: bool = False,   # paper trading mode
    ):
        self.strategy_id = strategy_id
        self.user_id = user_id
        self._adapter = exchange_adapter
        self.portfolio = portfolio
        self._risk_config = risk_config
        self._risk_state = risk_state
        self._on_order_event = on_order_event
        self._on_fill_event = on_fill_event
        self.dry_run = dry_run

        self._risk_engine: RiskEngine = get_risk_engine()
        self._orders: dict[str, Order] = {}           # order_id → Order
        self._pending_fills: dict[str, list[Fill]] = {}  # order_id → fills

        # Deduplication: prevents double-submit on retry
        self._submitted_idempotency_keys: set[str] = set()
        self._lock = asyncio.Lock()

    # ------------------------------------------------------------------
    # Primary interface — called by strategy runner
    # ------------------------------------------------------------------

    async def submit_order(self, request: OrderRequest) -> Order:
        """
        Accept an order from a strategy, run risk checks, and submit to exchange.
        Returns the Order object immediately (may still be PENDING until exchange ACKs).
        """
        async with self._lock:
            # 1. Idempotency check
            ikey = request.idempotency_key or str(uuid.uuid4())
            if ikey in self._submitted_idempotency_keys:
                logger.warning(f"Duplicate order submission blocked: {ikey}")
                # Return the existing order if we can find it
                for order in self._orders.values():
                    if order.client_order_id == ikey:
                        return order
                raise ValueError(f"Duplicate order key {ikey} with no matching order")
            request.idempotency_key = ikey

            # 2. Generate client order ID
            if not request.client_order_id:
                request.client_order_id = f"{self.strategy_id[:8]}-{uuid.uuid4().hex[:12]}"

            # 3. Get current price for risk checks
            try:
                ticker = await self._adapter.get_ticker(request.symbol)
                current_price = ticker.price
            except Exception as e:
                logger.error(f"Failed to get ticker for risk check: {e}")
                raise

            # 4. Run risk engine
            risk_result = self._risk_engine.check_order(
                request=request,
                portfolio=self.portfolio,
                config=self._risk_config,
                state=self._risk_state,
                current_price=current_price,
                open_order_count=self._count_open_orders(),
            )

            if not risk_result.approved:
                logger.warning(
                    f"Order REJECTED [{risk_result.violation}]: {risk_result.reason} "
                    f"(strategy={self.strategy_id}, symbol={request.symbol})"
                )
                # Create a rejected order record for audit
                rejected_order = self._create_rejected_order(request, risk_result.reason)
                await self._emit_order_event(rejected_order)
                return rejected_order

            # 5. Create pending order record
            order = Order(
                order_id=str(uuid.uuid4()),
                client_order_id=request.client_order_id,
                exchange_order_id=None,
                symbol=request.symbol,
                side=request.side,
                order_type=request.order_type,
                market_type=request.market_type or MarketType.SPOT,
                quantity=request.quantity,
                price=request.price,
                stop_price=request.stop_price,
                status=OrderStatus.PENDING,
                strategy_id=self.strategy_id,
                user_id=self.user_id,
            )
            self._orders[order.order_id] = order
            self._submitted_idempotency_keys.add(ikey)

            # 6. Submit to exchange (or paper engine)
            try:
                if self.dry_run:
                    submitted = await self._paper_submit(request, order)
                else:
                    submitted = await self._adapter.place_order(request)

                # Update our record with exchange acknowledgment
                order.exchange_order_id = submitted.exchange_order_id
                order.status = submitted.status
                self._orders[order.order_id] = order

                await self._emit_order_event(order)
                logger.info(
                    f"Order submitted: {order.side.value} {order.quantity} "
                    f"{order.symbol} [{order.status.value}] "
                    f"(oid={order.order_id[:8]}, strategy={self.strategy_id})"
                )
                return order

            except Exception as e:
                order.status = OrderStatus.REJECTED
                await self._emit_order_event(order)
                logger.error(f"Order submission failed: {e} (oid={order.order_id})")
                raise

    async def cancel_order(self, order_id: str) -> bool:
        """Cancel an open order. Returns True if successfully cancelled."""
        order = self._orders.get(order_id)
        if not order:
            logger.warning(f"Cancel requested for unknown order {order_id}")
            return False

        if not order.is_active:
            logger.warning(f"Cannot cancel order {order_id} in status {order.status}")
            return False

        try:
            success = await self._adapter.cancel_order(order_id, order.symbol)
            if success:
                order.status = OrderStatus.CANCELLED
                self._orders[order_id] = order
                await self._emit_order_event(order)
            return success
        except Exception as e:
            logger.error(f"Cancel failed for {order_id}: {e}")
            return False

    async def cancel_all(self, symbol: Optional[str] = None) -> int:
        """Cancel all open orders. Returns count cancelled."""
        cancelled = 0
        tasks = []
        for order in list(self._orders.values()):
            if order.is_active and (symbol is None or order.symbol == symbol):
                tasks.append(self.cancel_order(order.order_id))
        results = await asyncio.gather(*tasks, return_exceptions=True)
        cancelled = sum(1 for r in results if r is True)
        return cancelled

    # ------------------------------------------------------------------
    # Fill processing — called by exchange feed handler
    # ------------------------------------------------------------------

    async def process_fill(
        self,
        order_id: str,
        fill_price: Decimal,
        fill_qty: Decimal,
        fee: Decimal,
        fee_currency: str,
        is_maker: bool,
        fill_id: Optional[str] = None,
    ) -> None:
        """
        Process a fill event from the exchange.
        Updates order state, portfolio positions, and emits events.
        """
        order = self._orders.get(order_id)
        if not order:
            logger.warning(f"Fill received for unknown order {order_id}")
            return

        fill = Fill(
            fill_id=fill_id or str(uuid.uuid4()),
            order_id=order_id,
            symbol=order.symbol,
            side=order.side,
            price=fill_price,
            quantity=fill_qty,
            fee=fee,
            fee_currency=fee_currency,
            timestamp_ms=int(datetime.now(timezone.utc).timestamp() * 1000),
            is_maker=is_maker,
        )

        # Update order state
        old_filled = order.filled_quantity
        order.filled_quantity += fill_qty
        order.fees_paid += fee

        # Update average fill price
        if old_filled == 0:
            order.avg_fill_price = fill_price
        else:
            total_value = (old_filled * (order.avg_fill_price or fill_price)) + (fill_qty * fill_price)
            order.avg_fill_price = total_value / order.filled_quantity

        # Update order status
        if order.filled_quantity >= order.quantity:
            order.status = OrderStatus.FILLED
            order.filled_at_ms = fill.timestamp_ms
        else:
            order.status = OrderStatus.PARTIALLY_FILLED

        self._orders[order_id] = order

        # Update portfolio position
        await self._update_position(order, fill)

        # Update risk state (daily PnL tracking)
        if order.status == OrderStatus.FILLED:
            # This is simplified — real PnL calc requires paired entry/exit tracking
            self._risk_state.daily_realized_pnl += (fill_price - Decimal("0")) * fill_qty

        await self._emit_order_event(order)
        if self._on_fill_event:
            self._on_fill_event(order, fill)

        logger.info(
            f"Fill processed: {fill_qty} {order.symbol} @ {fill_price} "
            f"(order={order_id[:8]}, status={order.status.value})"
        )

    # ------------------------------------------------------------------
    # Order update from exchange (WebSocket feed)
    # ------------------------------------------------------------------

    async def handle_order_update(self, exchange_order: Order) -> None:
        """
        Called when the exchange sends an order status update.
        Reconciles our internal state with exchange state.
        """
        # Find our order by exchange order ID
        our_order = None
        for order in self._orders.values():
            if order.exchange_order_id == exchange_order.exchange_order_id:
                our_order = order
                break

        if not our_order:
            logger.debug(f"Order update for untracked order {exchange_order.exchange_order_id}")
            return

        # Reconcile status
        our_order.status = exchange_order.status
        our_order.filled_quantity = exchange_order.filled_quantity
        our_order.avg_fill_price = exchange_order.avg_fill_price
        our_order.fees_paid = exchange_order.fees_paid

        self._orders[our_order.order_id] = our_order
        await self._emit_order_event(our_order)

    # ------------------------------------------------------------------
    # Portfolio position management
    # ------------------------------------------------------------------

    async def _update_position(self, order: Order, fill: Fill) -> None:
        """Update portfolio position based on fill."""
        symbol = order.symbol
        existing = self.portfolio.get_position(symbol)
        qty = fill.quantity
        price = fill.price

        from sdk.models import Position
        import time

        if existing is None or existing.quantity == 0:
            # Opening new position
            side = PositionSide.LONG if order.side.value == "buy" else PositionSide.SHORT
            self.portfolio.positions[symbol] = Position(
                symbol=symbol,
                side=side,
                quantity=qty,
                avg_entry_price=price,
                market_type=order.market_type,
                strategy_id=self.strategy_id,
                opened_at_ms=fill.timestamp_ms,
                current_price=price,
            )
        else:
            is_same_direction = (
                (existing.side == PositionSide.LONG and order.side.value == "buy") or
                (existing.side == PositionSide.SHORT and order.side.value == "sell")
            )
            if is_same_direction:
                # Adding to existing position — recalculate avg entry
                total_cost = (existing.quantity * existing.avg_entry_price) + (qty * price)
                new_qty = existing.quantity + qty
                existing.avg_entry_price = total_cost / new_qty
                existing.quantity = new_qty
            else:
                # Reducing / closing position
                if qty >= existing.quantity:
                    # Position fully closed
                    realized_pnl = (
                        (price - existing.avg_entry_price) * existing.quantity
                        if existing.side == PositionSide.LONG
                        else (existing.avg_entry_price - price) * existing.quantity
                    )
                    existing.realized_pnl += realized_pnl
                    existing.quantity = Decimal("0")
                    existing.side = PositionSide.FLAT
                else:
                    # Partial close
                    realized_pnl = (
                        (price - existing.avg_entry_price) * qty
                        if existing.side == PositionSide.LONG
                        else (existing.avg_entry_price - price) * qty
                    )
                    existing.realized_pnl += realized_pnl
                    existing.quantity -= qty
            self.portfolio.positions[symbol] = existing

        # Update balance (simplified)
        if order.side.value == "buy":
            cost = qty * price + fill.fee
            usdt_bal = self.portfolio.balances.get("USDT", Decimal("0"))
            self.portfolio.balances["USDT"] = max(Decimal("0"), usdt_bal - cost)
        else:
            proceeds = qty * price - fill.fee
            self.portfolio.balances["USDT"] = (
                self.portfolio.balances.get("USDT", Decimal("0")) + proceeds
            )

    # ------------------------------------------------------------------
    # Paper trading simulation
    # ------------------------------------------------------------------

    async def _paper_submit(self, request: OrderRequest, order: Order) -> Order:
        """
        Simulate order execution for paper trading.
        Uses current order book to determine realistic fill price.
        """
        await asyncio.sleep(0.05)  # Simulate 50ms network latency

        ticker = await self._adapter.get_ticker(request.symbol)
        fill_price = ticker.price

        # Apply simulated slippage (0.05% market impact)
        slippage_factor = Decimal("1.0005") if request.side.value == "buy" else Decimal("0.9995")
        fill_price = fill_price * slippage_factor

        # Simulate exchange acknowledgment
        order.exchange_order_id = f"paper_{uuid.uuid4().hex[:12]}"
        order.status = OrderStatus.OPEN

        # Schedule immediate fill for market orders
        if request.order_type.value == "market":
            asyncio.ensure_future(self._simulate_fill(order, fill_price))

        return order

    async def _simulate_fill(self, order: Order, fill_price: Decimal) -> None:
        await asyncio.sleep(0.01)  # 10ms fill time simulation
        fee = order.quantity * fill_price * Decimal("0.001")  # 0.1% fee
        await self.process_fill(
            order_id=order.order_id,
            fill_price=fill_price,
            fill_qty=order.quantity,
            fee=fee,
            fee_currency="USDT",
            is_maker=False,
        )

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _count_open_orders(self) -> int:
        return sum(1 for o in self._orders.values() if o.is_active)

    def _create_rejected_order(self, request: OrderRequest, reason: str) -> Order:
        import time
        return Order(
            order_id=str(uuid.uuid4()),
            client_order_id=request.client_order_id or str(uuid.uuid4()),
            exchange_order_id=None,
            symbol=request.symbol,
            side=request.side,
            order_type=request.order_type,
            market_type=request.market_type or MarketType.SPOT,
            quantity=request.quantity,
            price=request.price,
            stop_price=request.stop_price,
            status=OrderStatus.REJECTED,
            strategy_id=self.strategy_id,
            user_id=self.user_id,
        )

    async def _emit_order_event(self, order: Order) -> None:
        if self._on_order_event:
            self._on_order_event(order)

    # ------------------------------------------------------------------
    # Queries
    # ------------------------------------------------------------------

    def get_order(self, order_id: str) -> Optional[Order]:
        return self._orders.get(order_id)

    def get_open_orders(self, symbol: Optional[str] = None) -> list[Order]:
        return [
            o for o in self._orders.values()
            if o.is_active and (symbol is None or o.symbol == symbol)
        ]

    def get_all_orders(self) -> list[Order]:
        return list(self._orders.values())

    def get_fills_for_order(self, order_id: str) -> list[Fill]:
        return self._pending_fills.get(order_id, [])
