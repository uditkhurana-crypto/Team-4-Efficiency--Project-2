"""
CoinDCX Algo Platform — Copy Trading Fan-Out Engine

This is the most performance-critical non-exchange component on the platform.
When a master strategy places an order, it must fan out to potentially
thousands of subscriber accounts within 100ms total.

Architecture:
  1. Master strategy OMS emits order event to Kafka topic: copy.order.events
  2. Fan-out service consumes the event
  3. Looks up all active subscribers from Redis cache
  4. Scales each order proportionally to subscriber's capital allocation
  5. Applies subscriber-specific risk checks
  6. Dispatches scaled orders via subscriber OMS instances in parallel
  7. Tracks fan-out completion and reports latency metrics

Scaling design:
  - Subscriber list cached in Redis (refreshed every 60s from PostgreSQL)
  - Fan-out is fully async — all subscriber orders dispatched concurrently
  - Per-subscriber OMS instances are pre-warmed (not created on-demand)
  - Exchange connections are pooled and pre-authenticated
  - Target: 1,000 subscribers fan-out in < 100ms p95

Copy modes:
  - PROPORTIONAL: Scale order qty by (subscriber_capital / master_capital)
  - FIXED_LOT:    Each subscriber copies a fixed quantity regardless
  - FIXED_NOTIONAL: Each subscriber copies a fixed USD amount
"""

from __future__ import annotations

import asyncio
import json
import logging
import time
from dataclasses import dataclass, field
from decimal import Decimal
from enum import Enum
from typing import Optional

logger = logging.getLogger("copy_trading.fanout")


class CopyMode(str, Enum):
    PROPORTIONAL = "proportional"
    FIXED_LOT = "fixed_lot"
    FIXED_NOTIONAL = "fixed_notional"


@dataclass
class Subscription:
    """A single active copy-trading subscription."""
    subscription_id: str
    subscriber_user_id: str
    master_strategy_id: str
    copy_mode: CopyMode
    allocated_capital_usdt: Decimal
    master_capital_reference_usdt: Decimal  # Master's capital at subscription time
    fixed_lot_qty: Optional[Decimal] = None
    fixed_notional_usdt: Optional[Decimal] = None
    max_drawdown_pct: Decimal = Decimal("20")   # Auto-stop if subscriber DD > this
    is_active: bool = True
    exchange: str = "coindcx"
    exchange_api_key_id: str = ""


@dataclass
class FanOutResult:
    """Result of a single copy-trade fan-out event."""
    master_order_id: str
    master_strategy_id: str
    total_subscribers: int
    successful_copies: int
    failed_copies: int
    skipped_copies: int   # Risk checks failed, insufficient balance, etc.
    latency_ms: float
    subscriber_results: list[dict] = field(default_factory=list)


class SubscriberCache:
    """
    In-memory cache of active subscriptions per master strategy.
    Backed by Redis, refreshed from PostgreSQL every 60 seconds.
    """

    def __init__(self, redis):
        self._redis = redis
        self._local_cache: dict[str, list[Subscription]] = {}
        self._cache_ttl: dict[str, float] = {}
        self._ttl = 60.0

    async def get_subscribers(self, master_strategy_id: str) -> list[Subscription]:
        now = time.time()
        if (
            master_strategy_id in self._local_cache
            and self._cache_ttl.get(master_strategy_id, 0) > now
        ):
            return self._local_cache[master_strategy_id]

        # Try Redis
        raw = await self._redis.get(f"copy_subs:{master_strategy_id}")
        if raw:
            subs_data = json.loads(raw)
            subs = [self._parse_subscription(s) for s in subs_data]
            self._local_cache[master_strategy_id] = subs
            self._cache_ttl[master_strategy_id] = now + self._ttl
            return subs

        # Fallback: empty (would trigger DB refresh in production)
        logger.warning(f"No subscribers cached for strategy {master_strategy_id}")
        return []

    def _parse_subscription(self, data: dict) -> Subscription:
        return Subscription(
            subscription_id=data["subscription_id"],
            subscriber_user_id=data["subscriber_user_id"],
            master_strategy_id=data["master_strategy_id"],
            copy_mode=CopyMode(data.get("copy_mode", "proportional")),
            allocated_capital_usdt=Decimal(str(data["allocated_capital_usdt"])),
            master_capital_reference_usdt=Decimal(str(data.get("master_capital_reference_usdt", "10000"))),
            fixed_lot_qty=Decimal(str(data["fixed_lot_qty"])) if data.get("fixed_lot_qty") else None,
            fixed_notional_usdt=Decimal(str(data["fixed_notional_usdt"])) if data.get("fixed_notional_usdt") else None,
            max_drawdown_pct=Decimal(str(data.get("max_drawdown_pct", "20"))),
            is_active=data.get("is_active", True),
            exchange=data.get("exchange", "coindcx"),
            exchange_api_key_id=data.get("exchange_api_key_id", ""),
        )

    async def invalidate(self, master_strategy_id: str) -> None:
        """Called when a subscriber joins or leaves."""
        self._local_cache.pop(master_strategy_id, None)
        await self._redis.delete(f"copy_subs:{master_strategy_id}")


class OrderScaler:
    """Scales master order quantities to subscriber allocations."""

    @staticmethod
    def scale_quantity(
        master_qty: Decimal,
        master_price: Decimal,
        subscription: Subscription,
    ) -> Optional[Decimal]:
        """
        Returns the scaled quantity for a subscriber order.
        Returns None if the scaled quantity is too small to place.
        """
        MIN_ORDER_NOTIONAL = Decimal("10")  # $10 minimum

        if subscription.copy_mode == CopyMode.PROPORTIONAL:
            if subscription.master_capital_reference_usdt == 0:
                return None
            ratio = subscription.allocated_capital_usdt / subscription.master_capital_reference_usdt
            scaled = master_qty * ratio
            if scaled * master_price < MIN_ORDER_NOTIONAL:
                return None
            return scaled.quantize(Decimal("0.00000001"))

        elif subscription.copy_mode == CopyMode.FIXED_LOT:
            if not subscription.fixed_lot_qty:
                return None
            if subscription.fixed_lot_qty * master_price < MIN_ORDER_NOTIONAL:
                return None
            return subscription.fixed_lot_qty

        elif subscription.copy_mode == CopyMode.FIXED_NOTIONAL:
            if not subscription.fixed_notional_usdt or master_price == 0:
                return None
            qty = subscription.fixed_notional_usdt / master_price
            if qty * master_price < MIN_ORDER_NOTIONAL:
                return None
            return qty.quantize(Decimal("0.00000001"))

        return None


class CopyTradeFanOutEngine:
    """
    Consumes master order events from Kafka and fans out to subscribers.
    Designed for horizontal scaling — multiple instances can run in parallel,
    partitioned by master_strategy_id.
    """

    def __init__(self, redis, platform_client, kafka_producer=None):
        self._redis = redis
        self._platform = platform_client
        self._kafka = kafka_producer
        self._subscriber_cache = SubscriberCache(redis)
        self._scaler = OrderScaler()

        # Pre-warmed OMS instances per subscriber (keyed by subscription_id)
        # In production, these are lazy-loaded and pooled
        self._oms_pool: dict[str, object] = {}

        # Metrics
        self._total_fanouts = 0
        self._total_copies = 0
        self._total_failures = 0

    async def process_master_order(
        self,
        master_order: dict,
        master_capital_usdt: Decimal,
        current_price: Decimal,
    ) -> FanOutResult:
        """
        Main entry point. Called when a master strategy's order is filled.
        Fans out to all active subscribers.
        """
        start_ms = time.time() * 1000
        master_strategy_id = master_order["strategy_id"]
        master_order_id = master_order["order_id"]

        logger.info(
            f"Copy trade fan-out: strategy={master_strategy_id}, "
            f"order={master_order_id[:8]}, "
            f"side={master_order['side']}, qty={master_order['quantity']}"
        )

        # Get subscribers from cache
        subscribers = await self._subscriber_cache.get_subscribers(master_strategy_id)
        active_subs = [s for s in subscribers if s.is_active]

        if not active_subs:
            return FanOutResult(
                master_order_id=master_order_id,
                master_strategy_id=master_strategy_id,
                total_subscribers=0,
                successful_copies=0,
                failed_copies=0,
                skipped_copies=0,
                latency_ms=0.0,
            )

        logger.info(f"Fanning out to {len(active_subs)} subscribers")

        # Scale and dispatch all subscriber orders concurrently
        tasks = [
            self._copy_to_subscriber(sub, master_order, current_price)
            for sub in active_subs
        ]

        results = await asyncio.gather(*tasks, return_exceptions=True)

        # Aggregate results
        successful = sum(1 for r in results if isinstance(r, dict) and r.get("success"))
        failed = sum(1 for r in results if isinstance(r, Exception))
        skipped = sum(
            1 for r in results
            if isinstance(r, dict) and not r.get("success") and r.get("reason") != "error"
        )

        latency_ms = (time.time() * 1000) - start_ms
        self._total_fanouts += 1
        self._total_copies += successful

        result = FanOutResult(
            master_order_id=master_order_id,
            master_strategy_id=master_strategy_id,
            total_subscribers=len(active_subs),
            successful_copies=successful,
            failed_copies=failed,
            skipped_copies=skipped,
            latency_ms=latency_ms,
            subscriber_results=[r for r in results if isinstance(r, dict)],
        )

        logger.info(
            f"Fan-out complete: {successful}/{len(active_subs)} succeeded "
            f"in {latency_ms:.1f}ms"
        )

        # Alert if latency is high
        if latency_ms > 200:
            logger.warning(f"Fan-out latency HIGH: {latency_ms:.1f}ms for {len(active_subs)} subscribers")

        # Publish fan-out metrics to Kafka
        if self._kafka:
            await self._publish_metrics(result)

        return result

    async def _copy_to_subscriber(
        self,
        subscription: Subscription,
        master_order: dict,
        current_price: Decimal,
    ) -> dict:
        """Copy a single order to a single subscriber. Runs concurrently."""
        sub_id = subscription.subscription_id

        try:
            # Scale the order quantity
            master_qty = Decimal(str(master_order["quantity"]))
            scaled_qty = self._scaler.scale_quantity(master_qty, current_price, subscription)

            if scaled_qty is None:
                return {
                    "subscription_id": sub_id,
                    "success": False,
                    "reason": "quantity_too_small",
                    "scaled_qty": None,
                }

            # Submit the scaled order via platform API
            # In production, this calls the subscriber's OMS directly
            # via a pre-authenticated internal API call
            order_payload = {
                "user_id": subscription.subscriber_user_id,
                "symbol": master_order["symbol"],
                "side": master_order["side"],
                "order_type": "market",  # Copy trades always use market orders
                "quantity": str(scaled_qty),
                "copy_source": {
                    "master_strategy_id": subscription.master_strategy_id,
                    "master_order_id": master_order["order_id"],
                    "subscription_id": sub_id,
                },
            }

            # Timeout per subscriber: 50ms
            # If one subscriber's exchange is slow, we don't block others
            async with asyncio.timeout(0.05):
                await self._platform.place_copy_order(order_payload)

            return {
                "subscription_id": sub_id,
                "success": True,
                "scaled_qty": str(scaled_qty),
                "latency_ms": None,  # Set by caller timing
            }

        except asyncio.TimeoutError:
            logger.warning(f"Copy order timeout for subscription {sub_id}")
            self._total_failures += 1
            return {
                "subscription_id": sub_id,
                "success": False,
                "reason": "timeout",
            }
        except Exception as e:
            logger.error(f"Copy order error for {sub_id}: {e}")
            self._total_failures += 1
            return {
                "subscription_id": sub_id,
                "success": False,
                "reason": "error",
                "error": str(e),
            }

    async def _publish_metrics(self, result: FanOutResult) -> None:
        """Publish fan-out metrics to Kafka for monitoring."""
        try:
            await self._kafka.send(
                "copy_trade.metrics",
                value=json.dumps({
                    "master_order_id": result.master_order_id,
                    "master_strategy_id": result.master_strategy_id,
                    "total_subscribers": result.total_subscribers,
                    "successful_copies": result.successful_copies,
                    "failed_copies": result.failed_copies,
                    "skipped_copies": result.skipped_copies,
                    "latency_ms": result.latency_ms,
                    "timestamp_ms": int(time.time() * 1000),
                }).encode(),
            )
        except Exception as e:
            logger.debug(f"Metrics publish failed (non-critical): {e}")

    def get_metrics(self) -> dict:
        return {
            "total_fanouts": self._total_fanouts,
            "total_copies": self._total_copies,
            "total_failures": self._total_failures,
            "success_rate_pct": (
                self._total_copies / max(self._total_copies + self._total_failures, 1) * 100
            ),
        }
