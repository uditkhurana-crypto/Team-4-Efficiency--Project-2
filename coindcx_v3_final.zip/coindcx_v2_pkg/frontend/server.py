#!/usr/bin/env python3
"""
CoinDCX Algo Platform — Frontend Server (V2)
Serves the upgraded single-page application on port 3000.
Pure Python stdlib — no npm, no Node.

Usage:
    python3 server.py
    # → http://localhost:3000
"""
import http.server
import os
import sys
import threading
import time
import webbrowser

PORT = 3000
HOST = "localhost"
FRONTEND_DIR = os.path.dirname(os.path.abspath(__file__))


class FrontendHandler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=FRONTEND_DIR, **kwargs)

    def log_message(self, fmt, *args):
        # Only log non-asset requests
        if not any(self.path.endswith(ext) for ext in ['.ico', '.png', '.jpg']):
            print(f"  [Frontend] {self.path}")

    def do_GET(self):
        # SPA — all routes serve index.html
        if self.path == "/" or not "." in self.path.split("/")[-1]:
            self.path = "/index.html"
        super().do_GET()

    def end_headers(self):
        # CORS headers for API calls
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Cache-Control", "no-cache")
        super().end_headers()


if __name__ == "__main__":
    server = http.server.HTTPServer((HOST, PORT), FrontendHandler)

    print(f"""
  ╔══════════════════════════════════════════════════╗
  ║   CoinDCX Algo Platform — Frontend Server V2     ║
  ╚══════════════════════════════════════════════════╝

  Frontend:  http://{HOST}:{PORT}
  Backend:   http://localhost:8000
  WebSocket: ws://localhost:8001

  Press Ctrl+C to stop
""")

    # Open browser after 0.5s delay
    def open_browser():
        time.sleep(0.5)
        try:
            webbrowser.open(f"http://{HOST}:{PORT}")
            print(f"  [Browser] Opened http://{HOST}:{PORT}")
        except Exception:
            pass

    threading.Thread(target=open_browser, daemon=True).start()

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n  [Frontend] Stopping...")
        server.shutdown()
