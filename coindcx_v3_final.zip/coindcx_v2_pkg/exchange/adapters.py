"""
CoinDCX Algo Platform — Exchange Adapter Layer

Unified interface over multiple exchanges.
Strategies and the OMS never call exchange APIs directly —
they always go through an ExchangeAdapter.

Architecture:
    ExchangeAdapter (abstract)
      ├── CoinDCXAdapter
      └── BinanceAdapter

Each adapter handles:
  - Authentication
  - Order placement / cancellation
  - Balance + position queries
  - WebSocket subscriptions for ticks, bars, order updates
  - Reconnect logic
  - Rate limit awareness
"""

from __future__ import annotations

import asyncio
import hashlib
import hmac
import json
import logging
import time
import urllib.parse
from abc import ABC, abstractmethod
from decimal import Decimal
from typing import AsyncGenerator, Optional, Callable

import aiohttp

from sdk.models import (
    Bar, Tick, OrderBook, OrderBookLevel, FundingRate,
    Order, OrderRequest, OrderSide, OrderStatus, OrderType,
    Fill, MarketType, TimeInForce
)

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Unified exchange interface
# ---------------------------------------------------------------------------

class ExchangeAdapter(ABC):
    """
    Abstract base for all exchange adapters.

    Implementations must be fully async and handle:
    - Automatic reconnection for WebSocket feeds
    - Rate limit back-off (429 responses)
    - Order idempotency via client_order_id
    - Error normalization into ExchangeError
    """

    def __init__(self, api_key: str, api_secret: str, sandbox: bool = False):
        self.api_key = api_key
        self.api_secret = api_secret
        self.sandbox = sandbox
        self._session: Optional[aiohttp.ClientSession] = None
        self._ws_connections: dict[str, aiohttp.ClientWebSocketResponse] = {}
        self._subscriptions: dict[str, list[Callable]] = {}

    async def __aenter__(self):
        self._session = aiohttp.ClientSession()
        return self

    async def __aexit__(self, *args):
        if self._session:
            await self._session.close()

    # ------------------------------------------------------------------
    # REST — must implement
    # ------------------------------------------------------------------

    @abstractmethod
    async def place_order(self, request: OrderRequest) -> Order:
        raise NotImplementedError

    @abstractmethod
    async def cancel_order(self, order_id: str, symbol: str) -> bool:
        raise NotImplementedError

    @abstractmethod
    async def get_order(self, order_id: str, symbol: str) -> Order:
        raise NotImplementedError

    @abstractmethod
    async def get_open_orders(self, symbol: Optional[str] = None) -> list[Order]:
        raise NotImplementedError

    @abstractmethod
    async def get_balances(self) -> dict[str, Decimal]:
        """Returns {currency: free_balance}."""
        raise NotImplementedError

    @abstractmethod
    async def get_ticker(self, symbol: str) -> Tick:
        raise NotImplementedError

    @abstractmethod
    async def get_orderbook(self, symbol: str, depth: int = 20) -> OrderBook:
        raise NotImplementedError

    @abstractmethod
    async def get_bars(
        self,
        symbol: str,
        resolution: str,
        start_ms: int,
        end_ms: int,
        limit: int = 1000,
    ) -> list[Bar]:
        raise NotImplementedError

    # ------------------------------------------------------------------
    # WebSocket streams — must implement
    # ------------------------------------------------------------------

    @abstractmethod
    async def subscribe_ticks(
        self, symbol: str, callback: Callable[[Tick], None]
    ) -> None:
        raise NotImplementedError

    @abstractmethod
    async def subscribe_bars(
        self, symbol: str, resolution: str, callback: Callable[[Bar], None]
    ) -> None:
        raise NotImplementedError

    @abstractmethod
    async def subscribe_orderbook(
        self, symbol: str, callback: Callable[[OrderBook], None]
    ) -> None:
        raise NotImplementedError

    @abstractmethod
    async def subscribe_order_updates(
        self, callback: Callable[[Order], None]
    ) -> None:
        """User-level private stream for order fill / status updates."""
        raise NotImplementedError

    @abstractmethod
    async def unsubscribe_all(self) -> None:
        raise NotImplementedError

    # ------------------------------------------------------------------
    # Shared helpers
    # ------------------------------------------------------------------

    async def _get(self, url: str, params: dict = None, signed: bool = False) -> dict:
        headers = {"Content-Type": "application/json"}
        if signed:
            params = params or {}
            params["timestamp"] = str(int(time.time() * 1000))
            params["signature"] = self._sign(urllib.parse.urlencode(params))
            headers["X-AUTH-APIKEY"] = self.api_key
        async with self._session.get(url, params=params, headers=headers) as resp:
            resp.raise_for_status()
            return await resp.json()

    async def _post(self, url: str, body: dict, signed: bool = True) -> dict:
        headers = {"Content-Type": "application/json"}
        if signed:
            body["timestamp"] = int(time.time() * 1000)
            payload = json.dumps(body, separators=(",", ":"))
            headers["X-AUTH-APIKEY"] = self.api_key
            headers["X-AUTH-SIGNATURE"] = self._sign(payload)
        async with self._session.post(url, json=body, headers=headers) as resp:
            resp.raise_for_status()
            return await resp.json()

    def _sign(self, payload: str) -> str:
        return hmac.new(
            self.api_secret.encode(), payload.encode(), hashlib.sha256
        ).hexdigest()

    @staticmethod
    def _parse_resolution_to_ms(resolution: str) -> int:
        mapping = {
            "1m": 60_000, "3m": 180_000, "5m": 300_000,
            "15m": 900_000, "30m": 1_800_000,
            "1h": 3_600_000, "4h": 14_400_000,
            "1d": 86_400_000, "1w": 604_800_000,
        }
        return mapping.get(resolution, 60_000)


# ---------------------------------------------------------------------------
# CoinDCX Adapter
# ---------------------------------------------------------------------------

class CoinDCXAdapter(ExchangeAdapter):
    """
    CoinDCX Open API adapter.
    Docs: https://docs.coindcx.com/
    """

    BASE_URL = "https://api.coindcx.com"
    WS_URL = "wss://stream.coindcx.com"

    SANDBOX_BASE_URL = "https://api.coindcx.com"   # CoinDCX has paper mode flag
    SANDBOX_WS_URL = "wss://stream.coindcx.com"

    # CoinDCX resolution strings
    RESOLUTION_MAP = {
        "1m": "1m", "3m": "3m", "5m": "5m",
        "15m": "15m", "30m": "30m",
        "1h": "1h", "4h": "4h",
        "1d": "1d", "1w": "1w",
    }

    def _base(self) -> str:
        return self.SANDBOX_BASE_URL if self.sandbox else self.BASE_URL

    def _ws(self) -> str:
        return self.SANDBOX_WS_URL if self.sandbox else self.WS_URL

    # ------------------------------------------------------------------
    # REST implementations
    # ------------------------------------------------------------------

    async def place_order(self, request: OrderRequest) -> Order:
        body = {
            "side": request.side.value,
            "order_type": self._map_order_type(request.order_type),
            "market": request.symbol,
            "total_quantity": str(request.quantity),
            "client_order_id": request.client_order_id or request.idempotency_key,
        }
        if request.price:
            body["price_per_unit"] = str(request.price)
        if request.stop_price:
            body["stop_price"] = str(request.stop_price)

        data = await self._post(f"{self._base()}/exchange/v1/orders/create", body)
        return self._parse_order(data["orders"][0])

    async def cancel_order(self, order_id: str, symbol: str) -> bool:
        try:
            await self._post(
                f"{self._base()}/exchange/v1/orders/cancel",
                {"id": order_id},
            )
            return True
        except Exception as e:
            logger.error(f"Failed to cancel order {order_id}: {e}")
            return False

    async def get_order(self, order_id: str, symbol: str) -> Order:
        data = await self._post(
            f"{self._base()}/exchange/v1/orders/status",
            {"id": order_id},
        )
        return self._parse_order(data)

    async def get_open_orders(self, symbol: Optional[str] = None) -> list[Order]:
        body = {}
        if symbol:
            body["market"] = symbol
        data = await self._post(f"{self._base()}/exchange/v1/orders/active_orders", body)
        return [self._parse_order(o) for o in data.get("orders", [])]

    async def get_balances(self) -> dict[str, Decimal]:
        data = await self._post(f"{self._base()}/exchange/v1/users/balances", {})
        return {
            item["currency"]: Decimal(str(item.get("balance", "0")))
            for item in data
        }

    async def get_ticker(self, symbol: str) -> Tick:
        data = await self._get(
            f"{self._base()}/market_data/ticker",
            params={"symbol": symbol},
        )
        ticker = data[0] if isinstance(data, list) else data
        return Tick(
            symbol=symbol,
            price=Decimal(str(ticker["last_price"])),
            quantity=Decimal(str(ticker.get("volume", "0"))),
            side=OrderSide.BUY,  # Ticker doesn't specify side
            timestamp_ms=int(time.time() * 1000),
        )

    async def get_orderbook(self, symbol: str, depth: int = 20) -> OrderBook:
        data = await self._get(
            f"{self._base()}/market_data/orderbook",
            params={"pair": symbol},
        )
        bids = [
            OrderBookLevel(Decimal(str(b[0])), Decimal(str(b[1])))
            for b in data.get("bids", [])[:depth]
        ]
        asks = [
            OrderBookLevel(Decimal(str(a[0])), Decimal(str(a[1])))
            for a in data.get("asks", [])[:depth]
        ]
        return OrderBook(
            symbol=symbol,
            bids=bids,
            asks=asks,
            timestamp_ms=int(time.time() * 1000),
        )

    async def get_bars(
        self,
        symbol: str,
        resolution: str,
        start_ms: int,
        end_ms: int,
        limit: int = 1000,
    ) -> list[Bar]:
        data = await self._get(
            f"{self._base()}/market_data/candles",
            params={
                "pair": symbol,
                "resolution": self.RESOLUTION_MAP.get(resolution, "1m"),
                "startTime": start_ms // 1000,
                "endTime": end_ms // 1000,
                "limit": limit,
            },
        )
        return [
            Bar(
                symbol=symbol,
                open=Decimal(str(c["open"])),
                high=Decimal(str(c["high"])),
                low=Decimal(str(c["low"])),
                close=Decimal(str(c["close"])),
                volume=Decimal(str(c["volume"])),
                timestamp_ms=int(c["time"]) * 1000,
                resolution=resolution,
            )
            for c in data
        ]

    # ------------------------------------------------------------------
    # WebSocket subscriptions
    # ------------------------------------------------------------------

    async def subscribe_ticks(
        self, symbol: str, callback: Callable[[Tick], None]
    ) -> None:
        channel = f"trade.{symbol}"
        await self._ws_subscribe(channel, self._handle_tick_msg(symbol, callback))

    async def subscribe_bars(
        self, symbol: str, resolution: str, callback: Callable[[Bar], None]
    ) -> None:
        channel = f"candlestick.{resolution}.{symbol}"
        await self._ws_subscribe(channel, self._handle_bar_msg(symbol, resolution, callback))

    async def subscribe_orderbook(
        self, symbol: str, callback: Callable[[OrderBook], None]
    ) -> None:
        channel = f"depth.{symbol}"
        await self._ws_subscribe(channel, self._handle_orderbook_msg(symbol, callback))

    async def subscribe_order_updates(
        self, callback: Callable[[Order], None]
    ) -> None:
        await self._ws_subscribe("order-updates", self._handle_order_update_msg(callback))

    async def unsubscribe_all(self) -> None:
        for ws in self._ws_connections.values():
            await ws.close()
        self._ws_connections.clear()
        self._subscriptions.clear()

    # ------------------------------------------------------------------
    # WebSocket internals
    # ------------------------------------------------------------------

    async def _ws_subscribe(self, channel: str, handler: Callable) -> None:
        """Maintain a persistent WebSocket connection with auto-reconnect."""
        asyncio.ensure_future(self._ws_loop(channel, handler))

    async def _ws_loop(self, channel: str, handler: Callable) -> None:
        retry_delay = 1.0
        while True:
            try:
                async with self._session.ws_connect(
                    f"{self._ws()}/socket.io/",
                    heartbeat=30,
                ) as ws:
                    retry_delay = 1.0
                    await ws.send_str(json.dumps({
                        "channelName": channel,
                        "event": "join",
                    }))
                    self._ws_connections[channel] = ws
                    async for msg in ws:
                        if msg.type == aiohttp.WSMsgType.TEXT:
                            data = json.loads(msg.data)
                            await handler(data)
                        elif msg.type in (aiohttp.WSMsgType.ERROR, aiohttp.WSMsgType.CLOSE):
                            break
            except Exception as e:
                logger.warning(f"WS {channel} disconnected: {e}. Reconnecting in {retry_delay}s")
                await asyncio.sleep(retry_delay)
                retry_delay = min(retry_delay * 2, 30.0)

    def _handle_tick_msg(self, symbol: str, callback: Callable) -> Callable:
        async def handler(data: dict) -> None:
            try:
                tick = Tick(
                    symbol=symbol,
                    price=Decimal(str(data["p"])),
                    quantity=Decimal(str(data["q"])),
                    side=OrderSide.BUY if data.get("m") else OrderSide.SELL,
                    timestamp_ms=int(data["T"]),
                )
                callback(tick)
            except (KeyError, ValueError) as e:
                logger.debug(f"Tick parse error: {e}")
        return handler

    def _handle_bar_msg(self, symbol: str, resolution: str, callback: Callable) -> Callable:
        async def handler(data: dict) -> None:
            try:
                k = data.get("k", data)
                bar = Bar(
                    symbol=symbol,
                    open=Decimal(str(k["o"])),
                    high=Decimal(str(k["h"])),
                    low=Decimal(str(k["l"])),
                    close=Decimal(str(k["c"])),
                    volume=Decimal(str(k["v"])),
                    timestamp_ms=int(k["t"]),
                    resolution=resolution,
                )
                if k.get("x", True):   # Only emit closed bars
                    callback(bar)
            except (KeyError, ValueError) as e:
                logger.debug(f"Bar parse error: {e}")
        return handler

    def _handle_orderbook_msg(self, symbol: str, callback: Callable) -> Callable:
        async def handler(data: dict) -> None:
            try:
                bids = [OrderBookLevel(Decimal(str(b[0])), Decimal(str(b[1]))) for b in data.get("b", [])]
                asks = [OrderBookLevel(Decimal(str(a[0])), Decimal(str(a[1]))) for a in data.get("a", [])]
                callback(OrderBook(symbol=symbol, bids=bids, asks=asks, timestamp_ms=int(time.time() * 1000)))
            except Exception as e:
                logger.debug(f"Orderbook parse error: {e}")
        return handler

    def _handle_order_update_msg(self, callback: Callable) -> Callable:
        async def handler(data: dict) -> None:
            try:
                order = self._parse_order(data)
                callback(order)
            except Exception as e:
                logger.debug(f"Order update parse error: {e}")
        return handler

    # ------------------------------------------------------------------
    # Data parsers
    # ------------------------------------------------------------------

    def _parse_order(self, data: dict) -> Order:
        status_map = {
            "open": OrderStatus.OPEN,
            "filled": OrderStatus.FILLED,
            "partially_filled": OrderStatus.PARTIALLY_FILLED,
            "cancelled": OrderStatus.CANCELLED,
            "rejected": OrderStatus.REJECTED,
        }
        return Order(
            order_id=str(data.get("id", "")),
            client_order_id=str(data.get("client_order_id", "")),
            exchange_order_id=str(data.get("id", "")),
            symbol=data.get("market", ""),
            side=OrderSide(data.get("side", "buy")),
            order_type=OrderType.MARKET,
            market_type=MarketType.SPOT,
            quantity=Decimal(str(data.get("total_quantity", "0"))),
            price=Decimal(str(data["price_per_unit"])) if data.get("price_per_unit") else None,
            stop_price=Decimal(str(data["stop_price"])) if data.get("stop_price") else None,
            status=status_map.get(data.get("status", "open"), OrderStatus.PENDING),
            filled_quantity=Decimal(str(data.get("filled_quantity", "0"))),
            avg_fill_price=Decimal(str(data["avg_price"])) if data.get("avg_price") else None,
            fees_paid=Decimal(str(data.get("fee_amount", "0"))),
            created_at_ms=int(data.get("created_at", time.time() * 1000)),
            updated_at_ms=int(data.get("updated_at", time.time() * 1000)),
        )

    @staticmethod
    def _map_order_type(order_type: OrderType) -> str:
        mapping = {
            OrderType.MARKET: "market_order",
            OrderType.LIMIT: "limit_order",
            OrderType.STOP_LIMIT: "stop_limit_order",
            OrderType.STOP_MARKET: "stop_market_order",
        }
        return mapping.get(order_type, "market_order")


# ---------------------------------------------------------------------------
# Binance Adapter (Spot + Futures)
# ---------------------------------------------------------------------------

class BinanceAdapter(ExchangeAdapter):
    """
    Binance adapter — supports spot and USD-M futures.
    Uses CCXT-style normalization for cross-exchange compatibility.
    """

    SPOT_BASE = "https://api.binance.com"
    FUTURES_BASE = "https://fapi.binance.com"
    SPOT_WS = "wss://stream.binance.com:9443/ws"
    FUTURES_WS = "wss://fstream.binance.com/ws"

    TESTNET_SPOT_BASE = "https://testnet.binance.vision"
    TESTNET_FUTURES_BASE = "https://testnet.binancefuture.com"

    def __init__(
        self,
        api_key: str,
        api_secret: str,
        sandbox: bool = False,
        market_type: MarketType = MarketType.SPOT,
    ):
        super().__init__(api_key, api_secret, sandbox)
        self.market_type = market_type

    def _base(self) -> str:
        if self.sandbox:
            return self.TESTNET_FUTURES_BASE if self.market_type == MarketType.FUTURES else self.TESTNET_SPOT_BASE
        return self.FUTURES_BASE if self.market_type == MarketType.FUTURES else self.SPOT_BASE

    def _ws_base(self) -> str:
        return self.FUTURES_WS if self.market_type == MarketType.FUTURES else self.SPOT_WS

    async def place_order(self, request: OrderRequest) -> Order:
        params = {
            "symbol": request.symbol.replace("/", ""),
            "side": request.side.value.upper(),
            "type": self._map_order_type(request.order_type),
            "quantity": str(request.quantity),
            "newClientOrderId": request.client_order_id or request.idempotency_key,
            "newOrderRespType": "FULL",
        }
        if request.price:
            params["price"] = str(request.price)
        if request.stop_price:
            params["stopPrice"] = str(request.stop_price)
        if request.time_in_force != TimeInForce.GTC:
            params["timeInForce"] = request.time_in_force.value.upper()
        else:
            if request.order_type == OrderType.LIMIT:
                params["timeInForce"] = "GTC"

        if self.market_type == MarketType.FUTURES:
            params["reduceOnly"] = str(request.reduce_only).lower()

        data = await self._post(f"{self._base()}/api/v3/order", params)
        return self._parse_binance_order(data)

    async def cancel_order(self, order_id: str, symbol: str) -> bool:
        try:
            await self._delete(
                f"{self._base()}/api/v3/order",
                params={"symbol": symbol, "orderId": order_id},
            )
            return True
        except Exception as e:
            logger.error(f"Cancel failed for {order_id}: {e}")
            return False

    async def get_order(self, order_id: str, symbol: str) -> Order:
        data = await self._get(
            f"{self._base()}/api/v3/order",
            params={"symbol": symbol, "orderId": order_id},
            signed=True,
        )
        return self._parse_binance_order(data)

    async def get_open_orders(self, symbol: Optional[str] = None) -> list[Order]:
        params = {}
        if symbol:
            params["symbol"] = symbol
        data = await self._get(f"{self._base()}/api/v3/openOrders", params=params, signed=True)
        return [self._parse_binance_order(o) for o in data]

    async def get_balances(self) -> dict[str, Decimal]:
        if self.market_type == MarketType.FUTURES:
            data = await self._get(f"{self._base()}/fapi/v2/balance", signed=True)
            return {item["asset"]: Decimal(str(item["availableBalance"])) for item in data}
        data = await self._get(f"{self._base()}/api/v3/account", signed=True)
        return {
            b["asset"]: Decimal(str(b["free"]))
            for b in data["balances"]
            if Decimal(str(b["free"])) > 0
        }

    async def get_ticker(self, symbol: str) -> Tick:
        data = await self._get(
            f"{self._base()}/api/v3/ticker/price",
            params={"symbol": symbol},
        )
        return Tick(
            symbol=symbol,
            price=Decimal(str(data["price"])),
            quantity=Decimal("0"),
            side=OrderSide.BUY,
            timestamp_ms=int(time.time() * 1000),
            exchange="binance",
        )

    async def get_orderbook(self, symbol: str, depth: int = 20) -> OrderBook:
        data = await self._get(
            f"{self._base()}/api/v3/depth",
            params={"symbol": symbol, "limit": depth},
        )
        bids = [OrderBookLevel(Decimal(str(b[0])), Decimal(str(b[1]))) for b in data["bids"]]
        asks = [OrderBookLevel(Decimal(str(a[0])), Decimal(str(a[1]))) for a in data["asks"]]
        return OrderBook(symbol=symbol, bids=bids, asks=asks, timestamp_ms=int(time.time() * 1000))

    async def get_bars(
        self,
        symbol: str,
        resolution: str,
        start_ms: int,
        end_ms: int,
        limit: int = 1000,
    ) -> list[Bar]:
        endpoint = "/fapi/v1/klines" if self.market_type == MarketType.FUTURES else "/api/v3/klines"
        data = await self._get(
            f"{self._base()}{endpoint}",
            params={
                "symbol": symbol,
                "interval": resolution,
                "startTime": start_ms,
                "endTime": end_ms,
                "limit": min(limit, 1000),
            },
        )
        return [
            Bar(
                symbol=symbol,
                open=Decimal(str(c[1])),
                high=Decimal(str(c[2])),
                low=Decimal(str(c[3])),
                close=Decimal(str(c[4])),
                volume=Decimal(str(c[5])),
                timestamp_ms=int(c[0]),
                resolution=resolution,
                num_trades=int(c[8]),
                taker_buy_volume=Decimal(str(c[9])),
            )
            for c in data
        ]

    async def subscribe_ticks(self, symbol: str, callback: Callable[[Tick], None]) -> None:
        stream = f"{symbol.lower()}@aggTrade"
        asyncio.ensure_future(self._binance_ws_loop(stream, self._binance_tick_handler(symbol, callback)))

    async def subscribe_bars(self, symbol: str, resolution: str, callback: Callable[[Bar], None]) -> None:
        stream = f"{symbol.lower()}@kline_{resolution}"
        asyncio.ensure_future(self._binance_ws_loop(stream, self._binance_bar_handler(symbol, resolution, callback)))

    async def subscribe_orderbook(self, symbol: str, callback: Callable[[OrderBook], None]) -> None:
        stream = f"{symbol.lower()}@depth20@100ms"
        asyncio.ensure_future(self._binance_ws_loop(stream, self._binance_ob_handler(symbol, callback)))

    async def subscribe_order_updates(self, callback: Callable[[Order], None]) -> None:
        listen_key = await self._get_listen_key()
        url = f"{self._ws_base()}/{listen_key}"
        asyncio.ensure_future(self._binance_ws_loop_direct(url, self._binance_order_handler(callback)))

    async def unsubscribe_all(self) -> None:
        for ws in self._ws_connections.values():
            await ws.close()
        self._ws_connections.clear()

    async def _get_listen_key(self) -> str:
        data = await self._post(f"{self._base()}/api/v3/userDataStream", {}, signed=False)
        return data["listenKey"]

    async def _binance_ws_loop(self, stream: str, handler: Callable) -> None:
        url = f"{self._ws_base()}/{stream}"
        await self._binance_ws_loop_direct(url, handler)

    async def _binance_ws_loop_direct(self, url: str, handler: Callable) -> None:
        retry_delay = 1.0
        while True:
            try:
                async with self._session.ws_connect(url, heartbeat=20) as ws:
                    retry_delay = 1.0
                    async for msg in ws:
                        if msg.type == aiohttp.WSMsgType.TEXT:
                            await handler(json.loads(msg.data))
                        elif msg.type in (aiohttp.WSMsgType.CLOSE, aiohttp.WSMsgType.ERROR):
                            break
            except Exception as e:
                logger.warning(f"Binance WS error: {e}. Retry in {retry_delay}s")
                await asyncio.sleep(retry_delay)
                retry_delay = min(retry_delay * 2, 60.0)

    def _binance_tick_handler(self, symbol: str, callback: Callable) -> Callable:
        async def handler(data: dict) -> None:
            callback(Tick(
                symbol=symbol,
                price=Decimal(str(data["p"])),
                quantity=Decimal(str(data["q"])),
                side=OrderSide.SELL if data.get("m") else OrderSide.BUY,
                timestamp_ms=int(data["T"]),
                exchange="binance",
            ))
        return handler

    def _binance_bar_handler(self, symbol: str, resolution: str, callback: Callable) -> Callable:
        async def handler(data: dict) -> None:
            k = data.get("k", {})
            if k.get("x"):   # Only closed candles
                callback(Bar(
                    symbol=symbol,
                    open=Decimal(str(k["o"])),
                    high=Decimal(str(k["h"])),
                    low=Decimal(str(k["l"])),
                    close=Decimal(str(k["c"])),
                    volume=Decimal(str(k["v"])),
                    timestamp_ms=int(k["t"]),
                    resolution=resolution,
                    num_trades=int(k.get("n", 0)),
                ))
        return handler

    def _binance_ob_handler(self, symbol: str, callback: Callable) -> Callable:
        async def handler(data: dict) -> None:
            bids = [OrderBookLevel(Decimal(str(b[0])), Decimal(str(b[1]))) for b in data.get("bids", [])]
            asks = [OrderBookLevel(Decimal(str(a[0])), Decimal(str(a[1]))) for a in data.get("asks", [])]
            callback(OrderBook(symbol=symbol, bids=bids, asks=asks, timestamp_ms=int(time.time() * 1000)))
        return handler

    def _binance_order_handler(self, callback: Callable) -> Callable:
        async def handler(data: dict) -> None:
            if data.get("e") == "executionReport":
                callback(self._parse_binance_order(data))
        return handler

    async def _delete(self, url: str, params: dict) -> dict:
        params["timestamp"] = int(time.time() * 1000)
        params["signature"] = self._sign(urllib.parse.urlencode(params))
        headers = {
            "X-MBX-APIKEY": self.api_key,
            "Content-Type": "application/json",
        }
        async with self._session.delete(url, params=params, headers=headers) as resp:
            resp.raise_for_status()
            return await resp.json()

    async def _post(self, url: str, body: dict, signed: bool = True) -> dict:
        headers = {"X-MBX-APIKEY": self.api_key, "Content-Type": "application/x-www-form-urlencoded"}
        if signed:
            body["timestamp"] = int(time.time() * 1000)
            body["signature"] = self._sign(urllib.parse.urlencode(body))
        async with self._session.post(url, data=body, headers=headers) as resp:
            resp.raise_for_status()
            return await resp.json()

    def _parse_binance_order(self, data: dict) -> Order:
        status_map = {
            "NEW": OrderStatus.OPEN,
            "PARTIALLY_FILLED": OrderStatus.PARTIALLY_FILLED,
            "FILLED": OrderStatus.FILLED,
            "CANCELED": OrderStatus.CANCELLED,
            "REJECTED": OrderStatus.REJECTED,
            "EXPIRED": OrderStatus.EXPIRED,
        }
        return Order(
            order_id=str(data.get("orderId", data.get("i", ""))),
            client_order_id=str(data.get("clientOrderId", data.get("c", ""))),
            exchange_order_id=str(data.get("orderId", "")),
            symbol=data.get("symbol", data.get("s", "")),
            side=OrderSide(data.get("side", data.get("S", "BUY")).lower()),
            order_type=OrderType.MARKET,
            market_type=self.market_type,
            quantity=Decimal(str(data.get("origQty", data.get("q", "0")))),
            price=Decimal(str(data["price"])) if data.get("price", "0") != "0" else None,
            stop_price=Decimal(str(data["stopPrice"])) if data.get("stopPrice", "0") != "0" else None,
            status=status_map.get(data.get("status", data.get("X", "NEW")), OrderStatus.PENDING),
            filled_quantity=Decimal(str(data.get("executedQty", data.get("z", "0")))),
            avg_fill_price=Decimal(str(data["avgPrice"])) if data.get("avgPrice", "0") != "0" else None,
            created_at_ms=int(data.get("time", data.get("T", time.time() * 1000))),
            updated_at_ms=int(data.get("updateTime", data.get("T", time.time() * 1000))),
        )

    @staticmethod
    def _map_order_type(order_type: OrderType) -> str:
        mapping = {
            OrderType.MARKET: "MARKET",
            OrderType.LIMIT: "LIMIT",
            OrderType.STOP_LIMIT: "STOP_LOSS_LIMIT",
            OrderType.STOP_MARKET: "STOP_LOSS",
            OrderType.TRAILING_STOP: "TRAILING_STOP_MARKET",
        }
        return mapping.get(order_type, "MARKET")
