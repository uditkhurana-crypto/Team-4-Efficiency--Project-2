# CoinDCX Algo Trading Platform

A production-ready algorithmic trading platform for CoinDCX with strategy management, backtesting, copy-trading, and a marketplace. Ships with a fully self-contained local dev runtime — no Redis, Kafka, or PostgreSQL required to get started.

---

## Quick Start (60 seconds)

```bash
# Clone / unzip the project
cd coindcx_algo

# Run full test suite (no dependencies needed — pure stdlib)
python3 scripts/deploy_local.py

# Run the interactive demo (strategy → backtest → deploy → marketplace)
python3 scripts/deploy_local.py --demo

# Start the API server only
python3 scripts/deploy_local.py --server
# → API running at http://localhost:18765
```

**Requirements:** Python 3.10+ only. Zero external packages for local dev.

---

## Project Structure

```
coindcx_algo/
│
├── sdk/                        # Strategy SDK (user-facing)
│   ├── models.py               # Bar, Order, Position, Portfolio dataclasses
│   ├── strategy.py             # BaseStrategy, BarBuffer, IndicatorLibrary
│   └── examples.py             # 5 reference strategies
│
├── backtesting/
│   ├── engine.py               # BacktestEngine, FillSimulator, WalkForwardValidator
│   └── celery_app.py           # Celery task definitions (production)
│
├── engine/
│   ├── execution/validator.py  # AST-based static strategy code validator
│   ├── oms/order_manager.py    # Order management system
│   └── sandbox/runner.py       # Isolated strategy execution runtime
│
├── risk/engine.py              # Pre-trade risk checks, kill switch, drawdown limits
├── exchange/adapters.py        # CoinDCX REST + WebSocket adapters
├── market_data/ingestion_worker.py  # Real-time market data pipeline
├── marketplace/copy_trading.py     # Copy-trading order scaling engine
├── analytics/metrics.py        # Sharpe, Sortino, drawdown, win-rate
│
├── coindcx_platform/           # Local dev runtime (no external deps)
│   ├── core.py                 # EventBus, SQLite StateStore, TaskQueue, Platform
│   ├── api_server.py           # Stdlib HTTP server — full REST API
│   └── market_sim.py           # GBM + mean-reversion market data simulator
│
├── api/main.py                 # FastAPI app (production)
├── tests/
│   ├── e2e_runner.py           # 64-test E2E suite across 18 use-cases
│   └── test_platform.py        # Unit tests
│
├── scripts/deploy_local.py     # CLI: run tests / demo / server
├── schema.sql                  # PostgreSQL schema
├── docker-compose.yml          # Full stack: API + Celery + Redis + Postgres
├── k8s-manifests.yaml          # Kubernetes deployment
└── requirements.txt            # Production dependencies
```

---

## Writing a Strategy

```python
from sdk.strategy import BaseStrategy
from sdk.models import Bar
from decimal import Decimal

class MyStrategy(BaseStrategy):
    SYMBOL = "BTCUSDT"
    RESOLUTION = "1h"

    def on_start(self):
        self.period = int(self.params.get("rsi_period", 14))
        self.qty = Decimal(str(self.params.get("quantity", "0.001")))

    def on_bar(self, bar: Bar):
        closes = self.bars.close
        if len(closes) < self.period + 1:
            return

        rsi = self.indicators.rsi(closes, self.period)
        if not rsi or len(rsi) < 1:
            return

        if rsi[-1] < 30 and not self.has_position(self.SYMBOL):
            self.buy(self.SYMBOL, self.qty)
        elif rsi[-1] > 70 and self.has_position(self.SYMBOL):
            self.close_position(self.SYMBOL)
```

### BaseStrategy API

| Method | Description |
|--------|-------------|
| `self.buy(symbol, qty)` | Submit market buy |
| `self.sell(symbol, qty)` | Submit market sell |
| `self.close_position(symbol)` | Close full position |
| `self.has_position(symbol)` | Check open position |
| `self.get_balance(currency)` | Get wallet balance |
| `self.bars` | BarBuffer with `.close`, `.open`, `.high`, `.low`, `.volume` |
| `self.indicators.ema(prices, period)` | EMA list |
| `self.indicators.rsi(prices, period)` | RSI list |
| `self.indicators.sma(prices, period)` | SMA list |
| `self.indicators.bollinger(prices, period, std)` | Bollinger Bands |
| `self.log.info(msg)` | Structured logging |
| `self.params` | Strategy parameters dict |
| `self.portfolio` | Portfolio with positions and balances |

### Validation Rules (enforced before any execution)

The static validator (`engine/execution/validator.py`) rejects code that:
- Uses forbidden imports: `subprocess`, `os.system`, `socket`, `ctypes`, `requests`, etc.
- Calls `exec()`, `eval()`, `open()`, `__import__()`
- Contains bare infinite loops
- Missing `on_bar()` method
- Has syntax errors

---

## REST API Reference

Base URL: `http://localhost:18765`

### Auth
| Method | Path | Description |
|--------|------|-------------|
| `POST` | `/api/v1/auth/register` | Register user |
| `POST` | `/api/v1/auth/login` | Login → JWT token |
| `GET`  | `/api/v1/auth/me` | Current user profile |

### Strategies
| Method | Path | Description |
|--------|------|-------------|
| `POST` | `/api/v1/strategies` | Create strategy |
| `GET`  | `/api/v1/strategies` | List user strategies |
| `GET`  | `/api/v1/strategies/{id}` | Get strategy |
| `PUT`  | `/api/v1/strategies/{id}/code` | Upload strategy code |
| `POST` | `/api/v1/strategies/validate` | Validate code (no execution) |

### Backtests
| Method | Path | Description |
|--------|------|-------------|
| `POST` | `/api/v1/strategies/{id}/backtests` | Submit backtest job |
| `GET`  | `/api/v1/backtests/{job_id}` | Poll job status + results |
| `GET`  | `/api/v1/strategies/{id}/backtests` | List all jobs for strategy |

### Deployments
| Method | Path | Description |
|--------|------|-------------|
| `POST` | `/api/v1/strategies/{id}/deployments` | Deploy (paper or live) |
| `GET`  | `/api/v1/deployments` | List deployments |
| `GET`  | `/api/v1/deployments/{id}` | Get deployment |
| `DELETE` | `/api/v1/deployments/{id}` | Stop deployment |

### Market Data
| Method | Path | Description |
|--------|------|-------------|
| `GET`  | `/api/v1/market/bars/{symbol}/{resolution}` | OHLCV bars |
| `GET`  | `/api/v1/market/ticker/{symbol}` | Current price + 24h stats |
| `GET`  | `/api/v1/market/orderbook/{symbol}` | Order book snapshot |

### Marketplace
| Method | Path | Description |
|--------|------|-------------|
| `POST` | `/api/v1/marketplace/listings` | Publish strategy |
| `GET`  | `/api/v1/marketplace/listings` | Browse listings |
| `POST` | `/api/v1/marketplace/listings/{id}/approve` | Admin: approve listing |
| `POST` | `/api/v1/marketplace/listings/{id}/subscribe` | Subscribe to copy-trade |

---

## Running a Backtest (API example)

```python
import urllib.request, json

BASE = "http://localhost:18765"

def api(method, path, body=None, token=None):
    data = json.dumps(body).encode() if body else None
    headers = {"Content-Type": "application/json"}
    if token: headers["Authorization"] = f"Bearer {token}"
    req = urllib.request.Request(f"{BASE}{path}", data=data, headers=headers, method=method)
    with urllib.request.urlopen(req) as r:
        return json.loads(r.read())

# 1. Register + login
api("POST", "/api/v1/auth/register", {"email": "you@example.com", "password": "secret"})
token = api("POST", "/api/v1/auth/login", {"email": "you@example.com", "password": "secret"})["token"]

# 2. Create strategy + upload code
sid = api("POST", "/api/v1/strategies", {"name": "EMA X", "symbol": "BTCUSDT"}, token)["strategy_id"]
api("PUT", f"/api/v1/strategies/{sid}/code", {"code": STRATEGY_CODE}, token)

# 3. Submit backtest
job = api("POST", f"/api/v1/strategies/{sid}/backtests", {
    "symbol": "BTCUSDT", "resolution": "1h",
    "start_ms": 1700000000000, "end_ms": 1710000000000,
    "initial_capital": 10000
}, token)

# 4. Poll until done
import time
while True:
    result = api("GET", f"/api/v1/backtests/{job['job_id']}", token=token)
    if result["status"] in ("completed", "failed"): break
    time.sleep(0.5)

print(result["metrics"])
# → {"total_return_pct": 4.2, "sharpe_ratio": 1.8, "max_drawdown_pct": 3.1, ...}
```

---

## BacktestEngine (Direct Python API)

```python
import asyncio
from backtesting.engine import BacktestEngine, BacktestConfig
from sdk.examples import MACrossoverStrategy
from decimal import Decimal

config = BacktestConfig(
    strategy_class=MACrossoverStrategy,
    strategy_params={"fast_period": 9, "slow_period": 21, "quantity": "0.001"},
    symbol="BTCUSDT",
    resolution="1h",
    start_ms=start_ms,
    end_ms=end_ms,
    initial_capital=Decimal("10000"),
    simulate_latency=False,       # True = next-bar fills
    slippage_pct=Decimal("0.001"),
    taker_fee=Decimal("0.001"),
)

result = asyncio.run(BacktestEngine(config).run(bars))

print(f"Return:  {result.metrics.total_return_pct:.2f}%")
print(f"Sharpe:  {result.metrics.sharpe_ratio:.3f}")
print(f"Trades:  {result.metrics.total_trades}")
print(f"Win %:   {result.metrics.win_rate_pct:.1f}%")
```

### Walk-Forward Validation

```python
from backtesting.engine import WalkForwardValidator

wf = WalkForwardValidator(
    strategy_class=MACrossoverStrategy,
    base_params={"fast_period": 9, "slow_period": 21, "quantity": "0.001"},
    all_bars=bars,
    train_pct=0.7,
    n_folds=5,
)
results = asyncio.run(wf.run())
for r in results:
    print(f"Fold return: {r.metrics.total_return_pct:.2f}%")
```

---

## Risk Engine

```python
from risk.engine import RiskEngine, RiskConfig, RiskContext
from sdk.models import OrderRequest, OrderSide, OrderType, MarketType
from decimal import Decimal

config = RiskConfig(
    max_order_size_usd=Decimal("5000"),
    max_position_size_pct=Decimal("0.20"),   # 20% of portfolio
    max_daily_drawdown_pct=Decimal("5.0"),
    max_open_positions=10,
    allowed_symbols=["BTCUSDT", "ETHUSDT"],
)
engine = RiskEngine(config)

ctx = RiskContext(portfolio_value=Decimal("10000"), current_drawdown_pct=Decimal("2.0"))
request = OrderRequest(symbol="BTCUSDT", side=OrderSide.BUY,
                       order_type=OrderType.MARKET, quantity=Decimal("0.05"))

decision = engine.evaluate(request, ctx)
if decision.approved:
    print("Order approved")
else:
    print(f"Rejected: {decision.reason}")   # e.g. "order_too_large"
```

---

## Production Deployment

### Docker Compose

```bash
docker-compose up -d
# Starts: api, celery-worker, celery-beat, redis, postgres, nginx
```

### Kubernetes

```bash
kubectl apply -f k8s-manifests.yaml
# Deploys: api (3 replicas), celery (5 replicas), redis, postgres with PVCs
```

### Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `DATABASE_URL` | sqlite:// | PostgreSQL URL in production |
| `REDIS_URL` | redis://localhost:6379 | Celery broker |
| `COINDCX_API_KEY` | — | CoinDCX API key |
| `COINDCX_SECRET` | — | CoinDCX API secret |
| `JWT_SECRET` | dev-secret | JWT signing secret |
| `SANDBOX_MODE` | true | Disable live order submission |
| `MAX_STRATEGY_COMPLEXITY` | 80 | AST complexity score limit |

---

## Architecture Overview

```
┌─────────────────────────────────────────────────────┐
│                   REST API (FastAPI)                 │
│              auth / strategies / backtests           │
│              deployments / marketplace               │
└──────────────────────┬──────────────────────────────┘
                       │
        ┌──────────────┼───────────────┐
        ▼              ▼               ▼
   ┌─────────┐   ┌──────────┐   ┌──────────────┐
   │  Risk   │   │ Strategy │   │  Backtest    │
   │ Engine  │   │Validator │   │  Engine      │
   │(pre-trade│  │ (AST)    │   │(FillSim +    │
   │ checks) │   └──────────┘   │ WalkForward) │
   └────┬────┘                  └──────┬───────┘
        │                             │
        ▼                             ▼
   ┌─────────┐                  ┌──────────┐
   │  OMS    │                  │  Celery  │
   │ (orders │                  │ Workers  │
   │ lifecycle│                 │ (async   │
   └────┬────┘                  │  jobs)   │
        │                       └──────────┘
        ▼
   ┌─────────────────────┐
   │   CoinDCX Exchange  │
   │  Adapter (REST/WS)  │
   └─────────────────────┘
```

**Data flow:** User uploads strategy code → Validator checks AST → Risk engine pre-approves order sizes → OMS manages lifecycle → Exchange adapter submits to CoinDCX → Analytics computes metrics → Marketplace enables copy-trading.

---

## Test Suite

```bash
# All 64 tests across 18 use-cases
python3 scripts/deploy_local.py

# Smoke test only (30s)
python3 scripts/deploy_local.py --smoke

# Start server, run tests externally
python3 scripts/deploy_local.py --server
# → http://localhost:18765
```

### Use-Cases Covered

| UC | Description | Tests |
|----|-------------|-------|
| 01 | User Registration & Login | 6 |
| 02 | Strategy CRUD | 4 |
| 03 | Code Validation | 5 |
| 04 | Backtest Submit & Poll | 7 |
| 05 | RSI Strategy Backtest | 2 |
| 06 | Paper Trading Deploy | 3 |
| 07 | Live Trading Deploy | 2 |
| 08 | Stop Deployment | 2 |
| 09 | Market Data APIs | 5 |
| 10 | Strategy Analytics | 2 |
| 11 | Marketplace Publish | 3 |
| 12 | Copy Trading | 4 |
| 13 | Audit Log | 3 |
| 14 | Multi-User Isolation | 4 |
| 15 | Platform Admin | 2 |
| 16 | Risk Engine | 4 |
| 17 | Backtest Engine Direct | 3 |
| 18 | Market Simulator | 3 |

---

## Included Example Strategies

| Strategy | Description | Indicators |
|----------|-------------|------------|
| `MACrossoverStrategy` | Classic EMA crossover | EMA fast/slow |
| `RSIMeanReversionStrategy` | Oversold/overbought mean reversion | RSI |
| `BollingerBandStrategy` | Band breakout + mean reversion | BB, SMA |
| `FundingRateArbitrage` | Spot + perp funding rate capture | Funding rate |
| `GridTradingStrategy` | Automated grid with fixed intervals | Price levels |

---

*Built for CoinDCX — production-ready, zero external dependencies for local dev.*
