-- CoinDCX Algo Platform — Complete Database Schema
-- PostgreSQL 15 + TimescaleDB extension
-- Apply with: psql -U postgres -d coindcx_algo -f schema.sql

BEGIN;

-- Enable required extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "timescaledb";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ═══════════════════════════════════════════════════════════
-- USERS AND AUTHENTICATION
-- ═══════════════════════════════════════════════════════════

CREATE TABLE users (
    user_id         UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    email           TEXT UNIQUE NOT NULL,
    display_name    TEXT NOT NULL,
    password_hash   TEXT,                        -- NULL if OAuth-only
    tier            TEXT NOT NULL DEFAULT 'free' CHECK (tier IN ('free', 'pro', 'institutional')),
    kyc_status      TEXT NOT NULL DEFAULT 'pending' CHECK (kyc_status IN ('pending', 'verified', 'rejected')),
    kyc_verified_at TIMESTAMPTZ,
    is_active       BOOLEAN NOT NULL DEFAULT true,
    is_admin        BOOLEAN NOT NULL DEFAULT false,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    last_login_at   TIMESTAMPTZ,
    metadata        JSONB NOT NULL DEFAULT '{}'
);

CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_tier ON users(tier) WHERE is_active = true;

-- ─────────────────────────────────────────────────
CREATE TABLE user_sessions (
    session_id      UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id         UUID NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
    refresh_token   TEXT UNIQUE NOT NULL,
    ip_address      INET,
    user_agent      TEXT,
    expires_at      TIMESTAMPTZ NOT NULL,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    revoked_at      TIMESTAMPTZ
);

CREATE INDEX idx_sessions_user_id ON user_sessions(user_id);
CREATE INDEX idx_sessions_token ON user_sessions(refresh_token) WHERE revoked_at IS NULL;

-- ─────────────────────────────────────────────────
CREATE TABLE oauth_accounts (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id     UUID NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
    provider    TEXT NOT NULL,    -- 'google', 'coindcx'
    provider_uid TEXT NOT NULL,
    email       TEXT,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (provider, provider_uid)
);

-- ═══════════════════════════════════════════════════════════
-- EXCHANGE API KEYS (encrypted at application layer)
-- ═══════════════════════════════════════════════════════════

CREATE TABLE exchange_api_keys (
    key_id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id         UUID NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
    exchange        TEXT NOT NULL,    -- 'coindcx', 'binance'
    label           TEXT NOT NULL,
    -- api_key and api_secret stored encrypted in Vault, referenced by key_id
    vault_path      TEXT NOT NULL,    -- Vault secret path
    permissions     TEXT[] NOT NULL DEFAULT ARRAY['read', 'trade'],
    ip_whitelist    INET[],
    is_active       BOOLEAN NOT NULL DEFAULT true,
    last_used_at    TIMESTAMPTZ,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_exchange_keys_user ON exchange_api_keys(user_id) WHERE is_active = true;

-- ═══════════════════════════════════════════════════════════
-- STRATEGIES
-- ═══════════════════════════════════════════════════════════

CREATE TABLE strategies (
    strategy_id     UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id         UUID NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
    name            TEXT NOT NULL,
    description     TEXT,
    language        TEXT NOT NULL DEFAULT 'python' CHECK (language IN ('python', 'javascript')),
    market_type     TEXT NOT NULL DEFAULT 'spot' CHECK (market_type IN ('spot', 'futures', 'options')),
    symbols         TEXT[] NOT NULL,
    resolution      TEXT NOT NULL DEFAULT '1h',
    tags            TEXT[] NOT NULL DEFAULT '{}',
    status          TEXT NOT NULL DEFAULT 'draft'
                    CHECK (status IN ('draft', 'backtested', 'paper', 'live', 'paused', 'archived')),
    current_version INTEGER NOT NULL DEFAULT 1,
    is_deleted      BOOLEAN NOT NULL DEFAULT false,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_strategies_user ON strategies(user_id) WHERE is_deleted = false;
CREATE INDEX idx_strategies_status ON strategies(status) WHERE is_deleted = false;
CREATE INDEX idx_strategies_tags ON strategies USING GIN(tags);

-- ─────────────────────────────────────────────────
CREATE TABLE strategy_versions (
    version_id      UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    strategy_id     UUID NOT NULL REFERENCES strategies(strategy_id) ON DELETE CASCADE,
    version_number  INTEGER NOT NULL,
    code            TEXT NOT NULL,
    params          JSONB NOT NULL DEFAULT '{}',
    commit_message  TEXT,
    code_hash       TEXT NOT NULL,    -- SHA256 of code for dedup
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_by      UUID REFERENCES users(user_id),
    UNIQUE (strategy_id, version_number)
);

CREATE INDEX idx_strategy_versions_strategy ON strategy_versions(strategy_id);

-- ─────────────────────────────────────────────────
CREATE TABLE risk_configs (
    config_id                   UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    strategy_id                 UUID NOT NULL REFERENCES strategies(strategy_id) ON DELETE CASCADE,
    max_position_size_usd       NUMERIC(18,8) NOT NULL DEFAULT 10000,
    max_position_pct_of_equity  NUMERIC(5,2) NOT NULL DEFAULT 50,
    max_open_orders             INTEGER NOT NULL DEFAULT 20,
    allowed_symbols             TEXT[],
    max_drawdown_pct            NUMERIC(5,2) NOT NULL DEFAULT 20,
    max_daily_loss_usd          NUMERIC(18,8) NOT NULL DEFAULT 500,
    max_daily_loss_pct          NUMERIC(5,2) NOT NULL DEFAULT 10,
    max_leverage                NUMERIC(5,2) NOT NULL DEFAULT 10,
    max_single_symbol_pct       NUMERIC(5,2) NOT NULL DEFAULT 30,
    min_order_size_usd          NUMERIC(18,8) NOT NULL DEFAULT 10,
    max_order_size_usd          NUMERIC(18,8) NOT NULL DEFAULT 5000,
    kill_switch_active          BOOLEAN NOT NULL DEFAULT false,
    auto_stop_on_drawdown       BOOLEAN NOT NULL DEFAULT true,
    auto_stop_on_daily_loss     BOOLEAN NOT NULL DEFAULT true,
    updated_at                  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (strategy_id)
);

-- ═══════════════════════════════════════════════════════════
-- DEPLOYMENTS (paper + live running instances)
-- ═══════════════════════════════════════════════════════════

CREATE TABLE deployments (
    deployment_id       UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    strategy_id         UUID NOT NULL REFERENCES strategies(strategy_id) ON DELETE CASCADE,
    strategy_version    INTEGER NOT NULL,
    user_id             UUID NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
    exchange_key_id     UUID REFERENCES exchange_api_keys(key_id),
    mode                TEXT NOT NULL CHECK (mode IN ('paper', 'live')),
    exchange            TEXT NOT NULL DEFAULT 'coindcx',
    initial_capital     NUMERIC(18,8) NOT NULL,
    status              TEXT NOT NULL DEFAULT 'starting'
                        CHECK (status IN ('starting', 'running', 'paused', 'stopped', 'error', 'killed')),
    kubernetes_pod_name TEXT,
    started_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    stopped_at          TIMESTAMPTZ,
    stop_reason         TEXT,
    last_heartbeat_at   TIMESTAMPTZ
);

CREATE INDEX idx_deployments_strategy ON deployments(strategy_id);
CREATE INDEX idx_deployments_user ON deployments(user_id);
CREATE INDEX idx_deployments_running ON deployments(status) WHERE status IN ('running', 'paused');

-- ═══════════════════════════════════════════════════════════
-- ORDERS (full order lifecycle)
-- ═══════════════════════════════════════════════════════════

CREATE TABLE orders (
    order_id            UUID PRIMARY KEY,
    client_order_id     TEXT NOT NULL,
    exchange_order_id   TEXT,
    deployment_id       UUID REFERENCES deployments(deployment_id),
    strategy_id         UUID NOT NULL REFERENCES strategies(strategy_id),
    user_id             UUID NOT NULL REFERENCES users(user_id),
    exchange            TEXT NOT NULL,
    symbol              TEXT NOT NULL,
    side                TEXT NOT NULL CHECK (side IN ('buy', 'sell')),
    order_type          TEXT NOT NULL,
    market_type         TEXT NOT NULL DEFAULT 'spot',
    quantity            NUMERIC(26,8) NOT NULL,
    price               NUMERIC(26,8),
    stop_price          NUMERIC(26,8),
    status              TEXT NOT NULL,
    filled_quantity     NUMERIC(26,8) NOT NULL DEFAULT 0,
    avg_fill_price      NUMERIC(26,8),
    fees_paid           NUMERIC(26,8) NOT NULL DEFAULT 0,
    fee_currency        TEXT NOT NULL DEFAULT 'USDT',
    idempotency_key     TEXT,
    tags                JSONB NOT NULL DEFAULT '{}',
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    filled_at           TIMESTAMPTZ
);

CREATE INDEX idx_orders_strategy ON orders(strategy_id);
CREATE INDEX idx_orders_user ON orders(user_id);
CREATE INDEX idx_orders_deployment ON orders(deployment_id);
CREATE INDEX idx_orders_symbol ON orders(symbol, created_at DESC);
CREATE INDEX idx_orders_status ON orders(status, created_at DESC);
CREATE UNIQUE INDEX idx_orders_idempotency ON orders(idempotency_key) WHERE idempotency_key IS NOT NULL;

-- ─────────────────────────────────────────────────
CREATE TABLE fills (
    fill_id         UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    order_id        UUID NOT NULL REFERENCES orders(order_id),
    strategy_id     UUID NOT NULL REFERENCES strategies(strategy_id),
    user_id         UUID NOT NULL REFERENCES users(user_id),
    symbol          TEXT NOT NULL,
    side            TEXT NOT NULL,
    price           NUMERIC(26,8) NOT NULL,
    quantity        NUMERIC(26,8) NOT NULL,
    fee             NUMERIC(26,8) NOT NULL,
    fee_currency    TEXT NOT NULL,
    is_maker        BOOLEAN NOT NULL DEFAULT false,
    exchange        TEXT NOT NULL,
    filled_at       TIMESTAMPTZ NOT NULL
);

CREATE INDEX idx_fills_order ON fills(order_id);
CREATE INDEX idx_fills_strategy ON fills(strategy_id, filled_at DESC);

-- ═══════════════════════════════════════════════════════════
-- BACKTESTS
-- ═══════════════════════════════════════════════════════════

CREATE TABLE backtest_jobs (
    job_id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    strategy_id         UUID NOT NULL REFERENCES strategies(strategy_id) ON DELETE CASCADE,
    strategy_version    INTEGER NOT NULL,
    user_id             UUID NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
    params_override     JSONB,
    start_date          DATE NOT NULL,
    end_date            DATE NOT NULL,
    initial_capital     NUMERIC(18,8) NOT NULL,
    maker_fee           NUMERIC(8,6) NOT NULL DEFAULT 0.001,
    taker_fee           NUMERIC(8,6) NOT NULL DEFAULT 0.001,
    slippage_pct        NUMERIC(8,6) NOT NULL DEFAULT 0.0005,
    status              TEXT NOT NULL DEFAULT 'queued'
                        CHECK (status IN ('queued', 'running', 'completed', 'failed', 'cancelled')),
    celery_task_id      TEXT,
    queued_at           TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    started_at          TIMESTAMPTZ,
    completed_at        TIMESTAMPTZ,
    duration_s          NUMERIC(10,2),
    bars_processed      INTEGER,
    -- Results stored in S3; summary metrics stored here for fast queries
    total_return_pct    NUMERIC(10,4),
    sharpe_ratio        NUMERIC(8,4),
    max_drawdown_pct    NUMERIC(8,4),
    win_rate_pct        NUMERIC(8,4),
    total_trades        INTEGER,
    s3_result_key       TEXT,    -- S3 key for full result JSON
    error_message       TEXT,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_backtest_jobs_strategy ON backtest_jobs(strategy_id, created_at DESC);
CREATE INDEX idx_backtest_jobs_user ON backtest_jobs(user_id, created_at DESC);
CREATE INDEX idx_backtest_jobs_status ON backtest_jobs(status) WHERE status IN ('queued', 'running');

-- ═══════════════════════════════════════════════════════════
-- MARKETPLACE
-- ═══════════════════════════════════════════════════════════

CREATE TABLE marketplace_listings (
    listing_id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    strategy_id             UUID NOT NULL REFERENCES strategies(strategy_id),
    publisher_user_id       UUID NOT NULL REFERENCES users(user_id),
    display_name            TEXT NOT NULL,
    short_description       TEXT NOT NULL,
    long_description        TEXT,
    subscription_fee_usd    NUMERIC(10,2) NOT NULL DEFAULT 0,
    performance_fee_pct     NUMERIC(5,2) NOT NULL DEFAULT 0,
    min_capital_usd         NUMERIC(18,8) NOT NULL DEFAULT 100,
    status                  TEXT NOT NULL DEFAULT 'pending_review'
                            CHECK (status IN ('pending_review', 'active', 'suspended', 'withdrawn')),
    is_public               BOOLEAN NOT NULL DEFAULT true,
    tags                    TEXT[] NOT NULL DEFAULT '{}',
    subscriber_count        INTEGER NOT NULL DEFAULT 0,
    total_aum_usdt          NUMERIC(26,8) NOT NULL DEFAULT 0,   -- Assets under management
    -- Verified performance (pulled from live deployment)
    verified_sharpe         NUMERIC(8,4),
    verified_return_pct     NUMERIC(10,4),
    verified_max_dd_pct     NUMERIC(8,4),
    verified_period_days    INTEGER,
    review_notes            TEXT,
    reviewed_at             TIMESTAMPTZ,
    published_at            TIMESTAMPTZ,
    created_at              TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at              TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_listings_status ON marketplace_listings(status, subscriber_count DESC);
CREATE INDEX idx_listings_publisher ON marketplace_listings(publisher_user_id);
CREATE INDEX idx_listings_tags ON marketplace_listings USING GIN(tags);
CREATE INDEX idx_listings_sharpe ON marketplace_listings(verified_sharpe DESC NULLS LAST)
    WHERE status = 'active';

-- ─────────────────────────────────────────────────
CREATE TABLE subscriptions (
    subscription_id             UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    listing_id                  UUID NOT NULL REFERENCES marketplace_listings(listing_id),
    subscriber_user_id          UUID NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
    master_strategy_id          UUID NOT NULL REFERENCES strategies(strategy_id),
    exchange_key_id             UUID REFERENCES exchange_api_keys(key_id),
    copy_mode                   TEXT NOT NULL DEFAULT 'proportional'
                                CHECK (copy_mode IN ('proportional', 'fixed_lot', 'fixed_notional')),
    allocated_capital_usdt      NUMERIC(18,8) NOT NULL,
    master_capital_reference    NUMERIC(18,8) NOT NULL,
    fixed_lot_qty               NUMERIC(26,8),
    fixed_notional_usdt         NUMERIC(18,8),
    max_drawdown_pct            NUMERIC(5,2) NOT NULL DEFAULT 20,
    is_active                   BOOLEAN NOT NULL DEFAULT true,
    subscribed_at               TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    unsubscribed_at             TIMESTAMPTZ,
    total_pnl                   NUMERIC(18,8) NOT NULL DEFAULT 0,
    UNIQUE (listing_id, subscriber_user_id)
);

CREATE INDEX idx_subscriptions_master ON subscriptions(master_strategy_id) WHERE is_active = true;
CREATE INDEX idx_subscriptions_subscriber ON subscriptions(subscriber_user_id);

-- ─────────────────────────────────────────────────
CREATE TABLE revenue_payouts (
    payout_id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    publisher_user_id   UUID NOT NULL REFERENCES users(user_id),
    listing_id          UUID NOT NULL REFERENCES marketplace_listings(listing_id),
    period_start        DATE NOT NULL,
    period_end          DATE NOT NULL,
    subscription_fees   NUMERIC(18,8) NOT NULL DEFAULT 0,
    performance_fees    NUMERIC(18,8) NOT NULL DEFAULT 0,
    platform_fee_pct    NUMERIC(5,2) NOT NULL DEFAULT 20,    -- Platform takes 20%
    platform_fee_amount NUMERIC(18,8) NOT NULL DEFAULT 0,
    net_payout          NUMERIC(18,8) NOT NULL DEFAULT 0,
    status              TEXT NOT NULL DEFAULT 'pending'
                        CHECK (status IN ('pending', 'processed', 'failed')),
    processed_at        TIMESTAMPTZ,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ═══════════════════════════════════════════════════════════
-- AUDIT LOG (append-only, never updated)
-- ═══════════════════════════════════════════════════════════

CREATE TABLE audit_log (
    log_id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id         UUID REFERENCES users(user_id),
    action          TEXT NOT NULL,        -- 'strategy.deploy', 'order.placed', etc.
    resource_type   TEXT NOT NULL,
    resource_id     UUID,
    details         JSONB NOT NULL DEFAULT '{}',
    ip_address      INET,
    user_agent      TEXT,
    occurred_at     TIMESTAMPTZ NOT NULL DEFAULT NOW()
) PARTITION BY RANGE (occurred_at);

-- Monthly partitions (create new ones as needed)
CREATE TABLE audit_log_2025_01 PARTITION OF audit_log
    FOR VALUES FROM ('2025-01-01') TO ('2025-02-01');
CREATE TABLE audit_log_2025_02 PARTITION OF audit_log
    FOR VALUES FROM ('2025-02-01') TO ('2025-03-01');
-- ... continue for each month

CREATE INDEX idx_audit_user ON audit_log(user_id, occurred_at DESC);
CREATE INDEX idx_audit_resource ON audit_log(resource_type, resource_id, occurred_at DESC);

-- ═══════════════════════════════════════════════════════════
-- TIMESCALEDB — TIME-SERIES TABLES
-- ═══════════════════════════════════════════════════════════

-- OHLCV bars — primary warm store for backtesting and charting
CREATE TABLE ohlcv_bars (
    time            TIMESTAMPTZ NOT NULL,
    symbol          TEXT NOT NULL,
    resolution      TEXT NOT NULL,   -- '1m', '5m', '1h', etc.
    exchange        TEXT NOT NULL DEFAULT 'coindcx',
    open            NUMERIC(26,8) NOT NULL,
    high            NUMERIC(26,8) NOT NULL,
    low             NUMERIC(26,8) NOT NULL,
    close           NUMERIC(26,8) NOT NULL,
    volume          NUMERIC(26,8) NOT NULL,
    num_trades      INTEGER NOT NULL DEFAULT 0,
    taker_buy_vol   NUMERIC(26,8),
    PRIMARY KEY (time, symbol, resolution, exchange)
);

SELECT create_hypertable('ohlcv_bars', 'time', chunk_time_interval => INTERVAL '7 days');
CREATE INDEX idx_ohlcv_symbol_res ON ohlcv_bars(symbol, resolution, time DESC);

-- Compression: compress chunks older than 7 days (saves ~90% storage)
ALTER TABLE ohlcv_bars SET (
    timescaledb.compress,
    timescaledb.compress_segmentby = 'symbol, resolution, exchange',
    timescaledb.compress_orderby = 'time DESC'
);
SELECT add_compression_policy('ohlcv_bars', INTERVAL '7 days');

-- Retention: keep 90 days in TimescaleDB, older goes to S3
SELECT add_retention_policy('ohlcv_bars', INTERVAL '90 days');

-- ─────────────────────────────────────────────────
-- Strategy equity curve (live/paper)
CREATE TABLE strategy_equity (
    time                TIMESTAMPTZ NOT NULL,
    strategy_id         UUID NOT NULL,
    deployment_id       UUID,
    equity              NUMERIC(26,8) NOT NULL,
    drawdown_pct        NUMERIC(8,4) NOT NULL,
    peak_equity         NUMERIC(26,8) NOT NULL,
    unrealized_pnl      NUMERIC(26,8) NOT NULL DEFAULT 0
);

SELECT create_hypertable('strategy_equity', 'time', chunk_time_interval => INTERVAL '1 day');
CREATE INDEX idx_equity_strategy ON strategy_equity(strategy_id, time DESC);
SELECT add_compression_policy('strategy_equity', INTERVAL '1 day');

-- ─────────────────────────────────────────────────
-- Funding rates (futures)
CREATE TABLE funding_rates (
    time            TIMESTAMPTZ NOT NULL,
    symbol          TEXT NOT NULL,
    exchange        TEXT NOT NULL,
    rate            NUMERIC(12,8) NOT NULL,
    mark_price      NUMERIC(26,8),
    open_interest   NUMERIC(26,8),
    PRIMARY KEY (time, symbol, exchange)
);

SELECT create_hypertable('funding_rates', 'time', chunk_time_interval => INTERVAL '30 days');
CREATE INDEX idx_funding_symbol ON funding_rates(symbol, time DESC);

-- ═══════════════════════════════════════════════════════════
-- TRIGGERS — auto-update updated_at
-- ═══════════════════════════════════════════════════════════

CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER users_updated_at BEFORE UPDATE ON users
    FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER strategies_updated_at BEFORE UPDATE ON strategies
    FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER listings_updated_at BEFORE UPDATE ON marketplace_listings
    FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- ═══════════════════════════════════════════════════════════
-- SEED DATA — platform configuration
-- ═══════════════════════════════════════════════════════════

-- Default tier limits (referenced by application config)
INSERT INTO users (user_id, email, display_name, tier, kyc_status, is_admin)
VALUES (
    '00000000-0000-0000-0000-000000000001',
    'admin@coindcx.com',
    'Platform Admin',
    'institutional',
    'verified',
    true
) ON CONFLICT DO NOTHING;

COMMIT;
