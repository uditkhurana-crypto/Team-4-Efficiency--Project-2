"""
CoinDCX Algo Platform — Core SDK Models
All data structures that strategies, the engine, and exchange adapters share.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from decimal import Decimal
from enum import Enum
from typing import Optional
import time


# ---------------------------------------------------------------------------
# Enumerations
# ---------------------------------------------------------------------------

class OrderSide(str, Enum):
    BUY = "buy"
    SELL = "sell"


class OrderType(str, Enum):
    MARKET = "market"
    LIMIT = "limit"
    STOP_LIMIT = "stop_limit"
    STOP_MARKET = "stop_market"
    TRAILING_STOP = "trailing_stop"
    TWAP = "twap"
    ICEBERG = "iceberg"


class OrderStatus(str, Enum):
    PENDING = "pending"        # Created in OMS, not yet sent
    OPEN = "open"              # Acknowledged by exchange
    PARTIALLY_FILLED = "partially_filled"
    FILLED = "filled"
    CANCELLED = "cancelled"
    REJECTED = "rejected"
    EXPIRED = "expired"


class MarketType(str, Enum):
    SPOT = "spot"
    FUTURES = "futures"
    OPTIONS = "options"


class PositionSide(str, Enum):
    LONG = "long"
    SHORT = "short"
    FLAT = "flat"


class TimeInForce(str, Enum):
    GTC = "gtc"    # Good Till Cancelled
    IOC = "ioc"    # Immediate Or Cancel
    FOK = "fok"    # Fill Or Kill
    GTD = "gtd"    # Good Till Date


# ---------------------------------------------------------------------------
# Market data
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class Tick:
    """Single market trade event — lowest granularity data."""
    symbol: str
    price: Decimal
    quantity: Decimal
    side: OrderSide
    timestamp_ms: int
    exchange: str = "coindcx"

    @property
    def timestamp(self) -> float:
        return self.timestamp_ms / 1000.0


@dataclass(frozen=True)
class Bar:
    """OHLCV candlestick for a given resolution."""
    symbol: str
    open: Decimal
    high: Decimal
    low: Decimal
    close: Decimal
    volume: Decimal
    timestamp_ms: int       # Bar open timestamp
    resolution: str         # "1m", "5m", "1h", "1d" etc.
    num_trades: int = 0
    taker_buy_volume: Decimal = Decimal("0")

    @property
    def is_bullish(self) -> bool:
        return self.close >= self.open

    @property
    def body_size(self) -> Decimal:
        return abs(self.close - self.open)

    @property
    def range(self) -> Decimal:
        return self.high - self.low


@dataclass(frozen=True)
class OrderBookLevel:
    price: Decimal
    quantity: Decimal


@dataclass
class OrderBook:
    symbol: str
    bids: list[OrderBookLevel]   # Sorted descending by price
    asks: list[OrderBookLevel]   # Sorted ascending by price
    timestamp_ms: int

    @property
    def best_bid(self) -> Optional[Decimal]:
        return self.bids[0].price if self.bids else None

    @property
    def best_ask(self) -> Optional[Decimal]:
        return self.asks[0].price if self.asks else None

    @property
    def spread(self) -> Optional[Decimal]:
        if self.best_bid and self.best_ask:
            return self.best_ask - self.best_bid
        return None

    @property
    def mid_price(self) -> Optional[Decimal]:
        if self.best_bid and self.best_ask:
            return (self.best_bid + self.best_ask) / 2
        return None


@dataclass(frozen=True)
class FundingRate:
    symbol: str
    rate: Decimal           # e.g. 0.0001 = 0.01%
    next_funding_ms: int    # Unix ms of next funding payment
    timestamp_ms: int


# ---------------------------------------------------------------------------
# Orders
# ---------------------------------------------------------------------------

@dataclass
class OrderRequest:
    """
    What a strategy submits to the engine.
    The engine validates, enriches, and forwards to OMS.
    """
    symbol: str
    side: OrderSide
    order_type: OrderType
    quantity: Decimal
    market_type: MarketType = MarketType.SPOT

    # Price fields (conditionally required)
    price: Optional[Decimal] = None         # Required for LIMIT
    stop_price: Optional[Decimal] = None    # Required for STOP_*
    trail_delta: Optional[Decimal] = None   # Required for TRAILING_STOP

    # Execution controls
    time_in_force: TimeInForce = TimeInForce.GTC
    reduce_only: bool = False               # Futures only — close position only
    post_only: bool = False                 # Maker only — cancel if taker

    # Iceberg order
    iceberg_qty: Optional[Decimal] = None   # Visible quantity

    # Client-side tracking
    client_order_id: Optional[str] = None
    strategy_id: Optional[str] = None
    idempotency_key: Optional[str] = None   # Prevents double-submission on retry

    # Metadata
    tags: dict[str, str] = field(default_factory=dict)


@dataclass
class Order:
    """
    Live order tracked by the OMS — full lifecycle record.
    """
    order_id: str
    client_order_id: str
    exchange_order_id: Optional[str]

    symbol: str
    side: OrderSide
    order_type: OrderType
    market_type: MarketType
    quantity: Decimal
    price: Optional[Decimal]
    stop_price: Optional[Decimal]

    status: OrderStatus = OrderStatus.PENDING
    filled_quantity: Decimal = Decimal("0")
    avg_fill_price: Optional[Decimal] = None
    fees_paid: Decimal = Decimal("0")
    fee_currency: str = "USDT"

    strategy_id: Optional[str] = None
    user_id: Optional[str] = None

    created_at_ms: int = field(default_factory=lambda: int(time.time() * 1000))
    updated_at_ms: int = field(default_factory=lambda: int(time.time() * 1000))
    filled_at_ms: Optional[int] = None

    @property
    def remaining_quantity(self) -> Decimal:
        return self.quantity - self.filled_quantity

    @property
    def is_active(self) -> bool:
        return self.status in (OrderStatus.PENDING, OrderStatus.OPEN, OrderStatus.PARTIALLY_FILLED)

    @property
    def notional_value(self) -> Optional[Decimal]:
        price = self.avg_fill_price or self.price
        if price:
            return self.filled_quantity * price
        return None


@dataclass
class Fill:
    """Individual trade execution — one order can have multiple fills."""
    fill_id: str
    order_id: str
    symbol: str
    side: OrderSide
    price: Decimal
    quantity: Decimal
    fee: Decimal
    fee_currency: str
    timestamp_ms: int
    is_maker: bool = False


# ---------------------------------------------------------------------------
# Positions
# ---------------------------------------------------------------------------

@dataclass
class Position:
    """
    Current open position for a symbol within a strategy.
    Updated in real-time as fills arrive.
    """
    symbol: str
    side: PositionSide
    quantity: Decimal
    avg_entry_price: Decimal
    market_type: MarketType
    strategy_id: str
    opened_at_ms: int

    # Live values updated by position tracker
    current_price: Decimal = Decimal("0")
    unrealized_pnl: Decimal = Decimal("0")
    realized_pnl: Decimal = Decimal("0")
    leverage: Decimal = Decimal("1")

    # Futures-specific
    liquidation_price: Optional[Decimal] = None
    margin_used: Decimal = Decimal("0")

    def update_price(self, price: Decimal) -> None:
        self.current_price = price
        if self.side == PositionSide.LONG:
            self.unrealized_pnl = (price - self.avg_entry_price) * self.quantity
        elif self.side == PositionSide.SHORT:
            self.unrealized_pnl = (self.avg_entry_price - price) * self.quantity

    @property
    def total_pnl(self) -> Decimal:
        return self.realized_pnl + self.unrealized_pnl

    @property
    def notional_value(self) -> Decimal:
        return self.quantity * self.current_price

    @property
    def pnl_percent(self) -> Decimal:
        cost_basis = self.quantity * self.avg_entry_price
        if cost_basis == 0:
            return Decimal("0")
        return (self.unrealized_pnl / cost_basis) * 100


# ---------------------------------------------------------------------------
# Portfolio
# ---------------------------------------------------------------------------

@dataclass
class Portfolio:
    """
    Aggregated view of all positions and balances for a strategy.
    The strategy accesses this via self.portfolio.
    """
    strategy_id: str
    base_currency: str = "USDT"

    balances: dict[str, Decimal] = field(default_factory=dict)
    positions: dict[str, Position] = field(default_factory=dict)

    total_realized_pnl: Decimal = Decimal("0")
    peak_equity: Decimal = Decimal("0")

    def get_balance(self, currency: str) -> Decimal:
        return self.balances.get(currency, Decimal("0"))

    def get_position(self, symbol: str) -> Optional[Position]:
        return self.positions.get(symbol)

    @property
    def total_unrealized_pnl(self) -> Decimal:
        return sum(p.unrealized_pnl for p in self.positions.values())

    @property
    def total_equity(self) -> Decimal:
        return self.get_balance(self.base_currency) + self.total_unrealized_pnl

    @property
    def max_drawdown(self) -> Decimal:
        if self.peak_equity == 0:
            return Decimal("0")
        return ((self.peak_equity - self.total_equity) / self.peak_equity) * 100


# ---------------------------------------------------------------------------
# Strategy performance metrics
# ---------------------------------------------------------------------------

@dataclass
class PerformanceMetrics:
    """
    Computed at the end of a backtest or live session.
    """
    strategy_id: str
    period_start_ms: int
    period_end_ms: int

    # Returns
    total_return_pct: float = 0.0
    annualized_return_pct: float = 0.0
    total_pnl: Decimal = Decimal("0")

    # Risk-adjusted
    sharpe_ratio: float = 0.0
    sortino_ratio: float = 0.0
    calmar_ratio: float = 0.0

    # Drawdown
    max_drawdown_pct: float = 0.0
    max_drawdown_duration_days: int = 0
    avg_drawdown_pct: float = 0.0

    # Trade stats
    total_trades: int = 0
    winning_trades: int = 0
    losing_trades: int = 0
    win_rate_pct: float = 0.0
    profit_factor: float = 0.0   # gross profit / gross loss
    avg_win: Decimal = Decimal("0")
    avg_loss: Decimal = Decimal("0")
    largest_win: Decimal = Decimal("0")
    largest_loss: Decimal = Decimal("0")

    # Costs
    total_fees_paid: Decimal = Decimal("0")
    total_slippage: Decimal = Decimal("0")

    # Volatility
    daily_volatility_pct: float = 0.0
    annualized_volatility_pct: float = 0.0

    @property
    def loss_rate_pct(self) -> float:
        return 100.0 - self.win_rate_pct

    @property
    def risk_reward_ratio(self) -> float:
        if self.avg_loss == 0:
            return 0.0
        return float(abs(self.avg_win / self.avg_loss))
