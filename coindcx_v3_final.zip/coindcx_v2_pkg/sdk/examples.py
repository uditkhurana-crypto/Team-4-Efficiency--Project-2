"""
CoinDCX Algo Platform — Built-in Example Strategies

These strategies ship with the SDK as references.
Users can copy, modify, and extend them.

Included:
  1. MACrossoverStrategy     — classic EMA crossover
  2. RSIMeanReversionStrategy — RSI oversold/overbought
  3. BollingerBandStrategy    — mean reversion with BB
  4. FundingRateArbitrage    — spot + perp funding arb
  5. GridTradingStrategy      — automated grid orders
"""

from __future__ import annotations

from decimal import Decimal
from typing import Optional

from sdk.strategy import BaseStrategy
from sdk.models import Bar, Tick, FundingRate, Order, OrderType, MarketType


# ---------------------------------------------------------------------------
# 1. EMA Crossover
# ---------------------------------------------------------------------------

class MACrossoverStrategy(BaseStrategy):
    """
    Classic EMA crossover strategy.

    Params:
        fast_period: int (default 10)   — fast EMA period
        slow_period: int (default 30)   — slow EMA period
        quantity: float (default 0.001) — order quantity
        symbol: str (default "BTCUSDT")
    """

    SYMBOL = "BTCUSDT"
    RESOLUTION = "1h"

    def on_start(self):
        self.fast_period = self.params.get("fast_period", 10)
        self.slow_period = self.params.get("slow_period", 30)
        self.qty = Decimal(str(self.params.get("quantity", "0.001")))
        self.in_position = False

        self.log.info(
            f"MA Crossover started: fast={self.fast_period}, slow={self.slow_period}"
        )

    def on_bar(self, bar: Bar):
        if len(self.bars) < self.slow_period + 1:
            return   # Not enough data yet

        fast_ma = self.indicators.ema(self.bars.close, self.fast_period)
        slow_ma = self.indicators.ema(self.bars.close, self.slow_period)

        if len(fast_ma) < 2 or len(slow_ma) < 2:
            return

        # Golden cross — fast crosses above slow → BUY
        if fast_ma[-1] > slow_ma[-1] and fast_ma[-2] <= slow_ma[-2]:
            if not self.in_position:
                self.log.info(f"Golden cross at {bar.close} — buying {self.qty}")
                self.buy(symbol=self.SYMBOL, quantity=self.qty)
                self.in_position = True

        # Death cross — fast crosses below slow → SELL
        elif fast_ma[-1] < slow_ma[-1] and fast_ma[-2] >= slow_ma[-2]:
            if self.in_position:
                self.log.info(f"Death cross at {bar.close} — closing position")
                self.close_position(self.SYMBOL)
                self.in_position = False

    def on_order_update(self, order: Order):
        self.log.debug(f"Order update: {order.order_id[:8]} → {order.status.value}")


# ---------------------------------------------------------------------------
# 2. RSI Mean Reversion
# ---------------------------------------------------------------------------

class RSIMeanReversionStrategy(BaseStrategy):
    """
    Buy oversold (RSI < 30), sell overbought (RSI > 70).

    Params:
        rsi_period: int (default 14)
        oversold: float (default 30)
        overbought: float (default 70)
        quantity: float (default 0.001)
        symbol: str (default "BTCUSDT")
    """

    SYMBOL = "BTCUSDT"
    RESOLUTION = "4h"

    def on_start(self):
        self.rsi_period = self.params.get("rsi_period", 14)
        self.oversold = self.params.get("oversold", 30.0)
        self.overbought = self.params.get("overbought", 70.0)
        self.qty = Decimal(str(self.params.get("quantity", "0.001")))
        self.last_signal: Optional[str] = None

        self.log.info(f"RSI Mean Reversion: period={self.rsi_period}, OB={self.overbought}, OS={self.oversold}")

    def on_bar(self, bar: Bar):
        if len(self.bars) < self.rsi_period + 5:
            return

        rsi = self.indicators.rsi(self.bars.close, self.rsi_period)
        if not rsi:
            return

        current_rsi = rsi[-1]

        # Oversold → buy signal
        if current_rsi < self.oversold and self.last_signal != "buy":
            if not self.has_position(self.SYMBOL):
                self.log.info(f"RSI oversold ({current_rsi:.1f}) at {bar.close} — buying")
                self.buy(symbol=self.SYMBOL, quantity=self.qty)
                self.last_signal = "buy"

        # Overbought → sell signal
        elif current_rsi > self.overbought and self.last_signal != "sell":
            if self.has_position(self.SYMBOL):
                self.log.info(f"RSI overbought ({current_rsi:.1f}) at {bar.close} — closing")
                self.close_position(self.SYMBOL)
                self.last_signal = "sell"


# ---------------------------------------------------------------------------
# 3. Bollinger Band Mean Reversion
# ---------------------------------------------------------------------------

class BollingerBandStrategy(BaseStrategy):
    """
    Buy when price touches lower band, sell at middle band.
    Uses ATR for stop loss placement.

    Params:
        bb_period: int (default 20)
        bb_std: float (default 2.0)
        atr_period: int (default 14)
        atr_stop_multiplier: float (default 2.0)
        quantity: float (default 0.001)
    """

    SYMBOL = "BTCUSDT"
    RESOLUTION = "4h"

    def on_start(self):
        self.bb_period = self.params.get("bb_period", 20)
        self.bb_std = self.params.get("bb_std", 2.0)
        self.atr_period = self.params.get("atr_period", 14)
        self.atr_stop_mult = self.params.get("atr_stop_multiplier", 2.0)
        self.qty = Decimal(str(self.params.get("quantity", "0.001")))
        self.stop_price: Optional[Decimal] = None
        self.take_profit: Optional[Decimal] = None

    def on_bar(self, bar: Bar):
        min_bars = max(self.bb_period, self.atr_period) + 5
        if len(self.bars) < min_bars:
            return

        upper, middle, lower = self.indicators.bollinger_bands(
            self.bars.close, self.bb_period, self.bb_std
        )
        atr = self.indicators.atr(self.bars.high, self.bars.low, self.bars.close, self.atr_period)

        if not upper or not atr:
            return

        close = float(bar.close)
        current_atr = atr[-1]

        # Check stop loss / take profit if in position
        if self.has_position(self.SYMBOL):
            if self.stop_price and bar.close <= self.stop_price:
                self.log.info(f"Stop loss hit at {bar.close}")
                self.close_position(self.SYMBOL)
                self.stop_price = None
                return
            if self.take_profit and bar.close >= self.take_profit:
                self.log.info(f"Take profit hit at {bar.close}")
                self.close_position(self.SYMBOL)
                self.take_profit = None
                return

        # Entry: price touches lower band
        if close <= lower[-1] and not self.has_position(self.SYMBOL):
            stop = bar.close - Decimal(str(self.atr_stop_mult * current_atr))
            target = Decimal(str(middle[-1]))
            risk_reward = float(bar.close - stop) / float(target - bar.close) if target != bar.close else 0
            if risk_reward < 2.0:   # Only trade if R:R > 2:1
                return
            self.log.info(
                f"BB lower touch at {bar.close}, target={target:.2f}, stop={stop:.2f}"
            )
            self.buy(symbol=self.SYMBOL, quantity=self.qty)
            self.stop_price = stop
            self.take_profit = target

        # Exit: price reaches middle band
        elif self.has_position(self.SYMBOL) and close >= middle[-1]:
            self.close_position(self.SYMBOL)
            self.stop_price = None
            self.take_profit = None


# ---------------------------------------------------------------------------
# 4. Funding Rate Arbitrage (Futures + Spot)
# ---------------------------------------------------------------------------

class FundingRateArbitrageStrategy(BaseStrategy):
    """
    Exploit funding rate differentials.
    When funding rate is highly positive: short perp, long spot.
    When funding rate is highly negative: long perp, short spot.

    This strategy holds delta-neutral positions and collects funding.

    Params:
        min_funding_rate_pct: float (default 0.05) — min annualized rate to enter
        quantity: float (default 0.01)
    """

    SYMBOL = "BTCUSDT"
    RESOLUTION = "1h"
    MARKET_TYPE = MarketType.FUTURES

    def on_start(self):
        self.min_rate = self.params.get("min_funding_rate_pct", 0.05)
        self.qty = Decimal(str(self.params.get("quantity", "0.01")))
        self.in_arb = False
        self.arb_direction: Optional[str] = None
        self.log.info(f"Funding Rate Arb: min_rate={self.min_rate}%")

    def on_bar(self, bar: Bar):
        # Main logic runs in on_funding() when funding rate data arrives
        pass

    def on_funding(self, funding: FundingRate):
        """Called every 8 hours when funding rate is published."""
        # Annualize: funding is per 8h, ~1095 periods per year
        annualized_rate_pct = float(funding.rate) * 1095 * 100

        self.log.info(f"Funding rate: {float(funding.rate)*100:.4f}% (ann: {annualized_rate_pct:.2f}%)")

        if annualized_rate_pct > self.min_rate and not self.in_arb:
            # Positive funding: longs pay shorts → go short perp, long spot
            self.log.info(f"Entering funding arb (short perp, long spot): {annualized_rate_pct:.2f}% APY")
            self.sell(symbol=self.SYMBOL, quantity=self.qty)   # Short futures
            # Note: long spot would be handled by a parallel spot strategy instance
            self.in_arb = True
            self.arb_direction = "short_perp"

        elif annualized_rate_pct < -self.min_rate and not self.in_arb:
            # Negative funding: shorts pay longs → go long perp, short spot
            self.log.info(f"Entering funding arb (long perp): {annualized_rate_pct:.2f}% APY")
            self.buy(symbol=self.SYMBOL, quantity=self.qty)
            self.in_arb = True
            self.arb_direction = "long_perp"

        elif self.in_arb and abs(annualized_rate_pct) < self.min_rate / 2:
            # Rate normalized — exit arb
            self.log.info(f"Exiting funding arb: rate normalized to {annualized_rate_pct:.2f}%")
            self.close_position(self.SYMBOL)
            self.in_arb = False
            self.arb_direction = None


# ---------------------------------------------------------------------------
# 5. Grid Trading
# ---------------------------------------------------------------------------

class GridTradingStrategy(BaseStrategy):
    """
    Places a grid of buy and sell limit orders around current price.
    Profits from price oscillation within the grid range.

    Params:
        lower_price: float  — bottom of grid range
        upper_price: float  — top of grid range
        num_grids: int (default 10) — number of grid levels
        quantity_per_grid: float    — quantity at each grid level
        symbol: str (default "BTCUSDT")
    """

    SYMBOL = "BTCUSDT"
    RESOLUTION = "1m"

    def on_start(self):
        self.lower = Decimal(str(self.params["lower_price"]))
        self.upper = Decimal(str(self.params["upper_price"]))
        self.num_grids = self.params.get("num_grids", 10)
        self.qty_per_grid = Decimal(str(self.params["quantity_per_grid"]))
        self.grid_initialized = False
        self.grid_levels: list[Decimal] = []
        self.grid_orders: dict[Decimal, str] = {}  # price → order_id

        step = (self.upper - self.lower) / self.num_grids
        self.grid_levels = [self.lower + step * i for i in range(self.num_grids + 1)]
        self.log.info(
            f"Grid strategy: {self.lower}–{self.upper}, {self.num_grids} levels, "
            f"{self.qty_per_grid} per grid"
        )

    def on_bar(self, bar: Bar):
        if not self.grid_initialized:
            self._initialize_grid(bar.close)
            self.grid_initialized = True

        # Re-fill any grid levels that were hit
        self._check_and_refill_grid(bar.close)

    def _initialize_grid(self, current_price: Decimal) -> None:
        """Place initial grid of buy/sell limit orders."""
        for level in self.grid_levels:
            if level < current_price:
                # Place buy limit below current price
                self.buy(
                    symbol=self.SYMBOL,
                    quantity=self.qty_per_grid,
                    order_type=OrderType.LIMIT,
                    price=level,
                )
                self.log.debug(f"Grid BUY limit placed at {level}")
            elif level > current_price:
                # Place sell limit above current price
                self.sell(
                    symbol=self.SYMBOL,
                    quantity=self.qty_per_grid,
                    order_type=OrderType.LIMIT,
                    price=level,
                )
                self.log.debug(f"Grid SELL limit placed at {level}")

    def _check_and_refill_grid(self, current_price: Decimal) -> None:
        """Check if price is outside grid range and adjust if needed."""
        if current_price < self.lower:
            self.log.warning(f"Price {current_price} below grid lower bound {self.lower}")
        elif current_price > self.upper:
            self.log.warning(f"Price {current_price} above grid upper bound {self.upper}")

    def on_order_update(self, order: Order):
        from sdk.models import OrderStatus
        if order.status == OrderStatus.FILLED:
            self.log.info(
                f"Grid order filled: {order.side.value} {order.filled_quantity} "
                f"@ {order.avg_fill_price}"
            )
