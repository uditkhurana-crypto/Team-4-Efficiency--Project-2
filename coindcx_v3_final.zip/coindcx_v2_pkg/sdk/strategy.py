"""
CoinDCX Algo Platform — Strategy Base Class

Every user-written strategy inherits from BaseStrategy.
The engine calls lifecycle methods; strategies call order methods.

Example minimal strategy:

    from coindcx_algo import BaseStrategy, Bar, OrderSide

    class MACrossover(BaseStrategy):
        SYMBOL = "BTCUSDT"
        RESOLUTION = "1h"

        def on_start(self):
            self.fast_period = self.params.get("fast_period", 10)
            self.slow_period = self.params.get("slow_period", 30)

        def on_bar(self, bar: Bar):
            if len(self.bars) < self.slow_period:
                return
            fast_ma = self.indicators.ema(self.bars.close, self.fast_period)
            slow_ma = self.indicators.ema(self.bars.close, self.slow_period)
            if fast_ma[-1] > slow_ma[-1] and fast_ma[-2] <= slow_ma[-2]:
                self.buy(symbol=self.SYMBOL, quantity=self.params.get("qty", "0.01"))
            elif fast_ma[-1] < slow_ma[-1] and fast_ma[-2] >= slow_ma[-2]:
                self.sell(symbol=self.SYMBOL, quantity=self.params.get("qty", "0.01"))
"""

from __future__ import annotations

import asyncio
import logging
from abc import ABC, abstractmethod
from decimal import Decimal
from typing import Optional, Any
from collections import deque

from sdk.models import (
    Bar, Tick, OrderBook, FundingRate,
    Order, OrderRequest, OrderSide, OrderType,
    MarketType, TimeInForce, Portfolio, Position,
    PerformanceMetrics
)


logger = logging.getLogger(__name__)


class BarBuffer:
    """
    Ring buffer of recent bars accessible inside on_bar().
    Provides numpy-friendly .close, .high, .low, .open, .volume arrays.
    """

    def __init__(self, maxlen: int = 500):
        self._bars: deque[Bar] = deque(maxlen=maxlen)

    def append(self, bar: Bar) -> None:
        self._bars.append(bar)

    def __len__(self) -> int:
        return len(self._bars)

    def __getitem__(self, idx: int) -> Bar:
        return list(self._bars)[idx]

    @property
    def close(self) -> list[Decimal]:
        return [b.close for b in self._bars]

    @property
    def open(self) -> list[Decimal]:
        return [b.open for b in self._bars]

    @property
    def high(self) -> list[Decimal]:
        return [b.high for b in self._bars]

    @property
    def low(self) -> list[Decimal]:
        return [b.low for b in self._bars]

    @property
    def volume(self) -> list[Decimal]:
        return [b.volume for b in self._bars]

    @property
    def latest(self) -> Optional[Bar]:
        return self._bars[-1] if self._bars else None


class IndicatorLibrary:
    """
    Built-in technical indicators available via self.indicators.
    All methods accept list[Decimal] and return list[float].
    """

    @staticmethod
    def sma(values: list[Decimal], period: int) -> list[float]:
        if len(values) < period:
            return []
        result = []
        vals = [float(v) for v in values]
        for i in range(period - 1, len(vals)):
            result.append(sum(vals[i - period + 1:i + 1]) / period)
        return result

    @staticmethod
    def ema(values: list[Decimal], period: int) -> list[float]:
        if len(values) < period:
            return []
        vals = [float(v) for v in values]
        multiplier = 2.0 / (period + 1)
        ema_values = [sum(vals[:period]) / period]
        for price in vals[period:]:
            ema_values.append((price - ema_values[-1]) * multiplier + ema_values[-1])
        return ema_values

    @staticmethod
    def rsi(values: list[Decimal], period: int = 14) -> list[float]:
        if len(values) < period + 1:
            return []
        vals = [float(v) for v in values]
        deltas = [vals[i] - vals[i - 1] for i in range(1, len(vals))]
        gains = [max(d, 0) for d in deltas]
        losses = [abs(min(d, 0)) for d in deltas]

        avg_gain = sum(gains[:period]) / period
        avg_loss = sum(losses[:period]) / period
        result = []

        for i in range(period, len(deltas)):
            avg_gain = (avg_gain * (period - 1) + gains[i]) / period
            avg_loss = (avg_loss * (period - 1) + losses[i]) / period
            rs = avg_gain / avg_loss if avg_loss != 0 else float("inf")
            result.append(100 - (100 / (1 + rs)))

        return result

    @staticmethod
    def macd(
        values: list[Decimal],
        fast: int = 12,
        slow: int = 26,
        signal: int = 9,
    ) -> tuple[list[float], list[float], list[float]]:
        """Returns (macd_line, signal_line, histogram)."""
        fast_ema = IndicatorLibrary.ema(values, fast)
        slow_ema = IndicatorLibrary.ema(values, slow)
        min_len = min(len(fast_ema), len(slow_ema))
        macd_line = [fast_ema[-(min_len - i)] - slow_ema[-(min_len - i)] for i in range(min_len)]
        signal_line = IndicatorLibrary.ema(
            [Decimal(str(m)) for m in macd_line], signal
        )
        histogram = [
            macd_line[-(len(signal_line) - i)] - signal_line[i]
            for i in range(len(signal_line))
        ]
        return macd_line, signal_line, histogram

    @staticmethod
    def bollinger_bands(
        values: list[Decimal],
        period: int = 20,
        std_dev: float = 2.0,
    ) -> tuple[list[float], list[float], list[float]]:
        """Returns (upper, middle, lower)."""
        import math
        if len(values) < period:
            return [], [], []
        vals = [float(v) for v in values]
        middle = []
        upper = []
        lower = []
        for i in range(period - 1, len(vals)):
            window = vals[i - period + 1:i + 1]
            mean = sum(window) / period
            variance = sum((x - mean) ** 2 for x in window) / period
            sd = math.sqrt(variance)
            middle.append(mean)
            upper.append(mean + std_dev * sd)
            lower.append(mean - std_dev * sd)
        return upper, middle, lower

    @staticmethod
    def atr(
        highs: list[Decimal],
        lows: list[Decimal],
        closes: list[Decimal],
        period: int = 14,
    ) -> list[float]:
        """Average True Range."""
        if len(closes) < period + 1:
            return []
        trs = []
        for i in range(1, len(closes)):
            h, l, pc = float(highs[i]), float(lows[i]), float(closes[i - 1])
            tr = max(h - l, abs(h - pc), abs(l - pc))
            trs.append(tr)
        atr_vals = [sum(trs[:period]) / period]
        for i in range(period, len(trs)):
            atr_vals.append((atr_vals[-1] * (period - 1) + trs[i]) / period)
        return atr_vals

    @staticmethod
    def vwap(
        highs: list[Decimal],
        lows: list[Decimal],
        closes: list[Decimal],
        volumes: list[Decimal],
    ) -> list[float]:
        """Volume-weighted average price."""
        result = []
        cumulative_tp_vol = 0.0
        cumulative_vol = 0.0
        for h, l, c, v in zip(highs, lows, closes, volumes):
            typical_price = (float(h) + float(l) + float(c)) / 3
            vol = float(v)
            cumulative_tp_vol += typical_price * vol
            cumulative_vol += vol
            result.append(cumulative_tp_vol / cumulative_vol if cumulative_vol > 0 else 0.0)
        return result


class StrategyContext:
    """
    Read-only interface into platform services.
    Injected by the engine — strategies never instantiate this directly.
    """

    def __init__(
        self,
        strategy_id: str,
        user_id: str,
        mode: str,  # "live", "paper", "backtest"
        exchange: str,
    ):
        self.strategy_id = strategy_id
        self.user_id = user_id
        self.mode = mode
        self.exchange = exchange
        self.is_live = mode == "live"
        self.is_paper = mode == "paper"
        self.is_backtest = mode == "backtest"


class BaseStrategy(ABC):
    """
    Base class for all CoinDCX Algo Platform strategies.

    Lifecycle:
        on_start()  → called once when strategy initialises
        on_tick()   → called on every trade event (if subscribed)
        on_bar()    → called on every completed bar (if subscribed)
        on_order_update() → called when an order status changes
        on_fill()   → called when a fill is received
        on_stop()   → called when strategy is stopped/paused

    Order methods:
        self.buy(...)
        self.sell(...)
        self.cancel_order(order_id)
        self.close_position(symbol)

    Data access:
        self.bars        → BarBuffer (recent OHLCV)
        self.portfolio   → Portfolio (balances, positions, PnL)
        self.context     → StrategyContext (mode, ids, exchange)
        self.indicators  → IndicatorLibrary (TA functions)
        self.params      → dict (user-configured parameters)
        self.log         → structured logger
    """

    # Strategy authors declare these at class level
    SYMBOL: str = ""
    SYMBOLS: list[str] = []
    RESOLUTION: str = "1m"    # Default bar resolution
    MARKET_TYPE: MarketType = MarketType.SPOT

    def __init__(
        self,
        strategy_id: str,
        params: dict[str, Any],
        context: StrategyContext,
        order_callback,      # Async callable: (OrderRequest) -> Order
        cancel_callback,     # Async callable: (order_id) -> bool
        portfolio: Portfolio,
    ):
        self.strategy_id = strategy_id
        self.params = params
        self.context = context
        self._order_callback = order_callback
        self._cancel_callback = cancel_callback
        self.portfolio = portfolio

        self.bars = BarBuffer(maxlen=params.get("bar_buffer_size", 500))
        self.indicators = IndicatorLibrary()
        self.log = logging.getLogger(f"strategy.{strategy_id}")

        self._open_orders: dict[str, Order] = {}
        self._running = False

    # ------------------------------------------------------------------
    # Lifecycle methods — override these in your strategy
    # ------------------------------------------------------------------

    def on_start(self) -> None:
        """Called once when the strategy starts. Initialise state here."""
        pass

    @abstractmethod
    def on_bar(self, bar: Bar) -> None:
        """Called on each completed bar. Main strategy logic goes here."""
        raise NotImplementedError

    def on_tick(self, tick: Tick) -> None:
        """Called on each trade tick. Override for tick-level strategies."""
        pass

    def on_order_book(self, order_book: OrderBook) -> None:
        """Called on each order book update. Override for market-making strategies."""
        pass

    def on_order_update(self, order: Order) -> None:
        """Called when any order status changes."""
        pass

    def on_fill(self, order: Order, fill_price: Decimal, fill_qty: Decimal) -> None:
        """Called when an order fill is received."""
        pass

    def on_funding(self, funding: FundingRate) -> None:
        """Called on funding rate updates (futures only)."""
        pass

    def on_stop(self) -> None:
        """Called when the strategy is stopped. Clean up state here."""
        pass

    # ------------------------------------------------------------------
    # Order methods — call these inside lifecycle methods
    # ------------------------------------------------------------------

    def buy(
        self,
        symbol: str,
        quantity: Decimal | str | float,
        order_type: OrderType = OrderType.MARKET,
        price: Optional[Decimal | str | float] = None,
        stop_price: Optional[Decimal | str | float] = None,
        time_in_force: TimeInForce = TimeInForce.GTC,
        reduce_only: bool = False,
        post_only: bool = False,
        tags: Optional[dict[str, str]] = None,
    ) -> asyncio.Future:
        return self._submit_order(
            symbol=symbol,
            side=OrderSide.BUY,
            quantity=Decimal(str(quantity)),
            order_type=order_type,
            price=Decimal(str(price)) if price else None,
            stop_price=Decimal(str(stop_price)) if stop_price else None,
            time_in_force=time_in_force,
            reduce_only=reduce_only,
            post_only=post_only,
            tags=tags or {},
        )

    def sell(
        self,
        symbol: str,
        quantity: Decimal | str | float,
        order_type: OrderType = OrderType.MARKET,
        price: Optional[Decimal | str | float] = None,
        stop_price: Optional[Decimal | str | float] = None,
        time_in_force: TimeInForce = TimeInForce.GTC,
        reduce_only: bool = False,
        post_only: bool = False,
        tags: Optional[dict[str, str]] = None,
    ) -> asyncio.Future:
        return self._submit_order(
            symbol=symbol,
            side=OrderSide.SELL,
            quantity=Decimal(str(quantity)),
            order_type=order_type,
            price=Decimal(str(price)) if price else None,
            stop_price=Decimal(str(stop_price)) if stop_price else None,
            time_in_force=time_in_force,
            reduce_only=reduce_only,
            post_only=post_only,
            tags=tags or {},
        )

    def close_position(self, symbol: str) -> Optional[asyncio.Future]:
        """Close the full open position for a symbol at market."""
        position = self.portfolio.get_position(symbol)
        if not position or position.quantity == 0:
            self.log.warning(f"No open position to close for {symbol}")
            return None
        side = OrderSide.SELL if position.side.value == "long" else OrderSide.BUY
        return self._submit_order(
            symbol=symbol,
            side=side,
            quantity=position.quantity,
            order_type=OrderType.MARKET,
            reduce_only=True,
        )

    def cancel_order(self, order_id: str) -> asyncio.Future:
        """Cancel an open order by ID."""
        return asyncio.ensure_future(self._cancel_callback(order_id))

    def cancel_all_orders(self, symbol: Optional[str] = None) -> list[asyncio.Future]:
        """Cancel all open orders, optionally filtered by symbol."""
        futures = []
        for oid, order in list(self._open_orders.items()):
            if symbol is None or order.symbol == symbol:
                futures.append(self.cancel_order(oid))
        return futures

    # ------------------------------------------------------------------
    # Convenience helpers
    # ------------------------------------------------------------------

    def get_position(self, symbol: str) -> Optional[Position]:
        return self.portfolio.get_position(symbol)

    def get_balance(self, currency: str = "USDT") -> Decimal:
        return self.portfolio.get_balance(currency)

    def has_position(self, symbol: str) -> bool:
        pos = self.get_position(symbol)
        return pos is not None and pos.quantity > 0

    def equity(self) -> Decimal:
        return self.portfolio.total_equity

    def drawdown(self) -> Decimal:
        return self.portfolio.max_drawdown

    # ------------------------------------------------------------------
    # Internal — not for strategy authors
    # ------------------------------------------------------------------

    def _submit_order(self, **kwargs):
        import uuid
        req = OrderRequest(
            idempotency_key=str(uuid.uuid4()),
            strategy_id=self.strategy_id,
            market_type=self.MARKET_TYPE,
            **kwargs,
        )
        # Support both sync callbacks (backtest) and async callbacks (live)
        import inspect
        result = self._order_callback(req)
        if inspect.isawaitable(result):
            return asyncio.ensure_future(result)
        return result

    def _handle_bar(self, bar: Bar) -> None:
        self.bars.append(bar)
        self.on_bar(bar)

    def _handle_tick(self, tick: Tick) -> None:
        self.on_tick(tick)

    def _handle_order_update(self, order: Order) -> None:
        if order.is_active:
            self._open_orders[order.order_id] = order
        else:
            self._open_orders.pop(order.order_id, None)
        self.on_order_update(order)
