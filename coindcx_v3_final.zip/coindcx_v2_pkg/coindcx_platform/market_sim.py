"""
CoinDCX Algo Platform — Market Data Simulator

Generates realistic OHLCV bar and tick data for local development.
Replaces live exchange WebSocket feeds during testing.

Models:
  - Geometric Brownian Motion for price simulation
  - Configurable drift, volatility, and mean-reversion
  - Realistic volume profiles (higher at open/close)
  - Funding rate simulation for futures
  - Order book depth simulation
"""

from __future__ import annotations

import math
import random
import time
from dataclasses import dataclass
from decimal import Decimal
from typing import Iterator, Optional


@dataclass
class SimConfig:
    symbol: str = "BTCUSDT"
    initial_price: float = 50000.0
    daily_volatility: float = 0.03      # 3% daily vol
    daily_drift: float = 0.0002         # slight upward drift
    mean_reversion: float = 0.01        # pull back towards mean
    base_volume: float = 100.0          # average volume per bar
    seed: Optional[int] = 42


class MarketSimulator:
    """
    Generates synthetic but realistic market data.
    Uses GBM with mean reversion (Ornstein-Uhlenbeck process).
    """

    RESOLUTION_SECONDS = {
        "1m": 60, "5m": 300, "15m": 900, "30m": 1800,
        "1h": 3600, "4h": 14400, "1d": 86400,
    }

    def __init__(self, config: SimConfig = None):
        self.cfg = config or SimConfig()
        if self.cfg.seed is not None:
            random.seed(self.cfg.seed)
        self._price = self.cfg.initial_price
        self._long_run_mean = self.cfg.initial_price

    def generate_bars(
        self,
        symbol: str,
        resolution: str,
        start_ms: int,
        end_ms: int,
        initial_price: float = None,
    ) -> list[dict]:
        """Generate a full series of OHLCV bars."""
        if initial_price:
            self._price = initial_price
        res_s = self.RESOLUTION_SECONDS.get(resolution, 3600)
        res_ms = res_s * 1000
        vol_per_bar = self.cfg.daily_volatility * math.sqrt(res_s / 86400)
        drift_per_bar = self.cfg.daily_drift * (res_s / 86400)

        bars = []
        ts = start_ms
        while ts < end_ms:
            bar = self._generate_bar(symbol, resolution, ts, vol_per_bar, drift_per_bar)
            bars.append(bar)
            ts += res_ms
        return bars

    def _generate_bar(self, symbol: str, resolution: str,
                      timestamp_ms: int, vol: float, drift: float) -> dict:
        """Generate a single OHLCV bar."""
        open_p = self._price

        # OU process: drift + volatility + mean reversion
        noise = random.gauss(0, vol)
        mr_pull = self.cfg.mean_reversion * (self._long_run_mean - open_p) / self._long_run_mean
        ret = drift + mr_pull + noise
        close_p = max(open_p * (1 + ret), 0.01)

        # High and low are derived from GBM path within bar
        intrabar_vol = vol * 0.5
        high_p = max(open_p, close_p) * (1 + abs(random.gauss(0, intrabar_vol)))
        low_p = min(open_p, close_p) * (1 - abs(random.gauss(0, intrabar_vol)))
        low_p = max(low_p, 0.01)

        # Volume: higher at market open/close (simulated by adding noise)
        volume = max(self.cfg.base_volume * random.lognormvariate(0, 0.5), 0.1)

        self._price = close_p

        return {
            "symbol": symbol,
            "resolution": resolution,
            "open": round(open_p, 2),
            "high": round(high_p, 2),
            "low": round(low_p, 2),
            "close": round(close_p, 2),
            "volume": round(volume, 4),
            "timestamp_ms": timestamp_ms,
            "num_trades": random.randint(10, 500),
        }

    def generate_ticks(self, symbol: str, bar: dict, n_ticks: int = 20) -> list[dict]:
        """Generate individual tick events within a bar."""
        ticks = []
        price = bar["open"]
        bar_start = bar["timestamp_ms"]
        bar_end = bar_start + self.RESOLUTION_SECONDS.get(bar["resolution"], 3600) * 1000
        interval = (bar_end - bar_start) / n_ticks

        for i in range(n_ticks):
            # Walk price towards close
            target = bar["close"]
            price += (target - price) * 0.1 + random.gauss(0, bar["close"] * 0.0002)
            price = max(price, 0.01)
            qty = random.uniform(0.001, 2.0)
            ticks.append({
                "symbol": symbol,
                "price": round(price, 2),
                "quantity": round(qty, 6),
                "side": "buy" if random.random() > 0.5 else "sell",
                "timestamp_ms": int(bar_start + i * interval),
            })
        return ticks

    def generate_orderbook(self, symbol: str, mid_price: float, depth: int = 10) -> dict:
        """Generate a synthetic order book."""
        spread_pct = 0.001  # 0.1% spread
        spread = mid_price * spread_pct
        bids = []
        asks = []
        for i in range(depth):
            bid_price = mid_price - spread / 2 - i * spread * 0.5
            ask_price = mid_price + spread / 2 + i * spread * 0.5
            # Volume increases deeper in the book
            size = random.uniform(0.1, 5.0) * (1 + i * 0.3)
            bids.append({"price": round(bid_price, 2), "quantity": round(size, 4)})
            asks.append({"price": round(ask_price, 2), "quantity": round(size, 4)})
        return {
            "symbol": symbol,
            "bids": bids,
            "asks": asks,
            "timestamp_ms": int(time.time() * 1000),
            "mid_price": mid_price,
            "spread": round(spread, 2),
        }

    def generate_funding_rate(self, symbol: str) -> dict:
        """Generate synthetic futures funding rate."""
        rate = random.gauss(0.0001, 0.0002)  # ~0.01% typical funding
        return {
            "symbol": symbol,
            "rate": round(rate, 6),
            "next_funding_ms": int((time.time() + 3600) * 1000),
            "timestamp_ms": int(time.time() * 1000),
        }

    @staticmethod
    def ms_range_for_lookback(resolution: str, n_bars: int) -> tuple[int, int]:
        """Calculate start/end timestamps for N bars of given resolution."""
        res_s = MarketSimulator.RESOLUTION_SECONDS.get(resolution, 3600)
        end_ms = int(time.time() * 1000)
        start_ms = end_ms - n_bars * res_s * 1000
        return start_ms, end_ms


class LiveFeedSimulator:
    """
    Simulates a live market data feed by replaying bars with real-time delays.
    Used in paper trading and strategy live-testing.
    """

    def __init__(self, symbol: str, resolution: str, speed_multiplier: float = 1.0):
        self.symbol = symbol
        self.resolution = resolution
        self.speed = speed_multiplier   # >1 = faster than real-time
        self._sim = MarketSimulator()
        self._subscribers: list = []
        self._running = False

    def subscribe(self, callback) -> None:
        self._subscribers.append(callback)

    async def run(self, n_bars: int = 100) -> None:
        """Stream bars to all subscribers."""
        import asyncio
        start_ms, end_ms = MarketSimulator.ms_range_for_lookback(self.resolution, n_bars)
        bars = self._sim.generate_bars(self.symbol, self.resolution, start_ms, end_ms)
        res_s = MarketSimulator.RESOLUTION_SECONDS.get(self.resolution, 3600)
        delay = res_s / self.speed

        self._running = True
        for bar in bars:
            if not self._running:
                break
            for cb in self._subscribers:
                try:
                    if asyncio.iscoroutinefunction(cb):
                        await cb(bar)
                    else:
                        cb(bar)
                except Exception as e:
                    print(f"[LiveFeedSimulator] Callback error: {e}")
            if self.speed < 1000:   # Don't sleep for ultra-fast backtests
                await asyncio.sleep(delay / 1000)  # Small delay for realism

    def stop(self) -> None:
        self._running = False


def generate_multi_asset_bars(
    symbols: list[str],
    resolution: str,
    n_bars: int,
    correlations: dict[str, float] = None,
    seed: int = 42,
) -> dict[str, list[dict]]:
    """
    Generate correlated bar data for multiple assets.
    correlations: {symbol: correlation_with_BTC} e.g. {"ETHUSDT": 0.8}
    """
    correlations = correlations or {}
    result = {}
    random.seed(seed)
    start_ms, end_ms = MarketSimulator.ms_range_for_lookback(resolution, n_bars)

    # Generate BTC first (or first symbol)
    base_symbol = symbols[0]
    base_sim = MarketSimulator(SimConfig(symbol=base_symbol, seed=seed))
    base_bars = base_sim.generate_bars(base_symbol, resolution, start_ms, end_ms)
    result[base_symbol] = base_bars
    base_returns = [
        (base_bars[i]["close"] - base_bars[i-1]["close"]) / base_bars[i-1]["close"]
        for i in range(1, len(base_bars))
    ]

    for symbol in symbols[1:]:
        corr = correlations.get(symbol, 0.5)
        prices = [50000.0 * (0.5 + random.random())]  # random start price
        sim = MarketSimulator(SimConfig(symbol=symbol, seed=seed + hash(symbol) % 1000))
        raw_bars = sim.generate_bars(symbol, resolution, start_ms, end_ms)

        # Blend with base returns according to correlation
        blended_bars = []
        price = raw_bars[0]["open"] if raw_bars else prices[0]
        for i, bar in enumerate(raw_bars):
            if i > 0 and i - 1 < len(base_returns):
                base_ret = base_returns[i - 1]
                own_ret = (bar["close"] - bar["open"]) / bar["open"] if bar["open"] != 0 else 0
                blended_ret = corr * base_ret + (1 - corr) * own_ret
                close = price * (1 + blended_ret)
                high = max(price, close) * (1 + abs(random.gauss(0, 0.003)))
                low = min(price, close) * (1 - abs(random.gauss(0, 0.003)))
                blended_bars.append({
                    "symbol": symbol, "resolution": resolution,
                    "open": round(price, 2), "high": round(high, 2),
                    "low": round(max(low, 0.01), 2), "close": round(max(close, 0.01), 2),
                    "volume": bar["volume"], "timestamp_ms": bar["timestamp_ms"],
                })
                price = close
            else:
                blended_bars.append(bar)
                price = bar["close"]
        result[symbol] = blended_bars

    return result
