"""
CoinDCX Algo Platform — WebSocket Price Stream Server
======================================================
Pure stdlib WebSocket server (no external deps).
Streams live simulated prices for all 50+ tokens every 1.5s.

Usage:
    from coindcx_platform.ws_server import WsServer
    ws = WsServer(port=8001)
    ws.start()      # non-blocking, runs in background thread
    ws.stop()
"""
from __future__ import annotations

import base64
import hashlib
import json
import math
import random
import socket
import struct
import threading
import time
import urllib.request
from typing import Optional

# ─────────────────────────────────────────────────
# Fallback prices (INR) — used only if CoinDCX API unreachable
# ─────────────────────────────────────────────────
BASE_PRICES: dict[str, float] = {
    "BTC": 8_650_000, "ETH": 280_000, "BNB": 52_000,  "SOL": 17_500,
    "ADA": 38.5,      "MATIC": 58.2,  "DOT": 580,     "AVAX": 3_100,
    "LINK": 1_100,    "UNI": 900,     "LTC": 7_200,   "XRP": 48.0,
    "DOGE": 11.2,     "SHIB": 0.00082,"ATOM": 780,    "NEAR": 390,
    "FTM": 38.2,      "ALGO": 14.8,   "VET": 2.8,     "THETA": 145,
    "FIL": 340,       "AAVE": 7_800,  "COMP": 3_800,  "SNX": 240,
    "CRV": 38.4,      "GRT": 16.2,    "BAT": 18.4,    "ZIL": 2.4,
    "ENJ": 24.2,      "CHZ": 9.2,     "MANA": 28.0,   "SAND": 38.2,
    "AXS": 480,       "GALA": 3.8,    "IMX": 140,     "APE": 120,
    "OP": 240,        "ARB": 128,     "SUI": 140,     "SEI": 40.2,
    "TIA": 520,       "INJ": 2_400,   "BLUR": 24.2,   "WLD": 380,
    "JTO": 220,       "PYTH": 32.4,   "BONK": 0.00142,"WIF": 240,
    "JUP": 72.4,      "STRK": 110,    "MANTA": 120,   "PIXEL": 20.4,
}

INR_USD_RATE = 84.2

# ─────────────────────────────────────────────────
# CoinDCX public ticker → INR symbol map
# ─────────────────────────────────────────────────
CDX_INR_MARKETS = {
    "BTC": "BTCINR", "ETH": "ETHINR", "BNB": "BNBINR", "SOL": "SOLINR",
    "ADA": "ADAINR", "MATIC": "MATICINR", "DOT": "DOTINR", "AVAX": "AVAXINR",
    "LINK": "LINKINR", "UNI": "UNIINR", "LTC": "LTCINR", "XRP": "XRPINR",
    "DOGE": "DOGEINR", "SHIB": "SHIBINR", "ATOM": "ATOMINR", "NEAR": "NEARINR",
    "FTM": "FTMINR", "ALGO": "ALGOINR", "VET": "VETINR", "THETA": "THETAINR",
    "FIL": "FILINR", "AAVE": "AAVEINR", "COMP": "COMPINR", "GRT": "GRTINR",
    "BAT": "BATINR", "ENJ": "ENJINR", "MANA": "MANAINR", "SAND": "SANDINR",
    "AXS": "AXSINR", "OP": "OPINR", "ARB": "ARBINR", "SUI": "SUIINR",
    "INJ": "INJINR", "WLD": "WLDINR", "PYTH": "PYTHINR", "JUP": "JUPINR",
    "TIA": "TIAINR", "SEI": "SEIINR", "BLUR": "BLURINR", "WIF": "WIFINR",
    "BONK": "BONKINR", "JTO": "JTOINR", "STRK": "STRKINR",
}

# ─────────────────────────────────────────────────
# Live price fetch from CoinDCX public ticker
# ─────────────────────────────────────────────────
_TICKER_URL = "https://api.coindcx.com/exchange/ticker"
_last_live_fetch: float = 0
_LIVE_FETCH_INTERVAL = 30  # seconds

def _fetch_live_prices() -> dict[str, float]:
    """Fetch real prices from CoinDCX public ticker (no API key needed)."""
    global _last_live_fetch
    try:
        req = urllib.request.Request(
            _TICKER_URL,
            headers={"Accept": "application/json", "User-Agent": "CoinDCXAlgo/3.0"},
        )
        with urllib.request.urlopen(req, timeout=8) as resp:
            tickers = json.loads(resp.read())

        live = {}
        market_to_sym = {v: k for k, v in CDX_INR_MARKETS.items()}
        for t in tickers:
            market = t.get("market", "")
            lp = float(t.get("last_price", 0) or 0)
            if lp > 0 and market in market_to_sym:
                sym = market_to_sym[market]
                live[sym] = lp
        _last_live_fetch = time.time()
        print(f"[WS] Fetched {len(live)} live prices from CoinDCX ✓ (BTC=₹{live.get('BTC',0):,.0f})")
        return live
    except Exception as e:
        print(f"[WS] Live price fetch failed: {e} — using fallback/GBM prices")
        return {}

# ─────────────────────────────────────────────────
# Price state — seeded from CoinDCX live, then drifts with GBM
# ─────────────────────────────────────────────────
_live_seed = _fetch_live_prices()  # fetch on module load
_prices:  dict[str, float] = {
    s: _live_seed.get(s, p) * (0.9995 + random.random() * 0.001)
    for s, p in BASE_PRICES.items()
}
# Seed changes from actual live vs fallback
_changes: dict[str, float] = {
    s: (((_live_seed.get(s, BASE_PRICES[s]) - BASE_PRICES[s]) / BASE_PRICES[s] * 100)
        if s in _live_seed else (random.random() - 0.45) * 8)
    for s in BASE_PRICES
}
_lock = threading.Lock()


def _tick_prices():
    """Refresh from CoinDCX every 30s, then apply tiny GBM noise for intra-tick realism."""
    global _last_live_fetch
    # Periodic live refresh from CoinDCX public ticker
    if time.time() - _last_live_fetch > _LIVE_FETCH_INTERVAL:
        live = _fetch_live_prices()
        if live:
            with _lock:
                for sym, price in live.items():
                    if sym in _prices:
                        _prices[sym] = price
            return  # skip GBM step on refresh frame

    with _lock:
        for sym in list(_prices.keys()):
            # Very small noise (0.05%) so chart ticks are smooth between refreshes
            noise = random.gauss(0, 0.0005)
            _prices[sym] = max(_prices[sym] * (1 + noise), 0.000001)
            _changes[sym] += random.gauss(0, 0.02)
            _changes[sym]  = max(-50, min(50, _changes[sym]))


def get_snapshot() -> dict:
    """Return current price snapshot for all tokens."""
    with _lock:
        return {
            sym: {
                "price_inr": round(p, 6),
                "price_usd": round(p / INR_USD_RATE, 6),
                "change_24h": round(_changes[sym], 3),
                "volume_inr": round(p * random.uniform(800, 8000), 0),
            }
            for sym, p in _prices.items()
        }


# ─────────────────────────────────────────────────
# Minimal stdlib WebSocket implementation
# ─────────────────────────────────────────────────

def _ws_handshake(conn: socket.socket, request_data: bytes) -> bool:
    """Perform HTTP→WebSocket upgrade handshake."""
    try:
        header_text = request_data.decode("utf-8", errors="replace")
        lines = header_text.split("\r\n")
        headers: dict[str, str] = {}
        for line in lines[1:]:
            if ":" in line:
                k, _, v = line.partition(":")
                headers[k.strip().lower()] = v.strip()

        key = headers.get("sec-websocket-key", "")
        if not key:
            return False

        accept = base64.b64encode(
            hashlib.sha1((key + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11").encode()).digest()
        ).decode()

        response = (
            "HTTP/1.1 101 Switching Protocols\r\n"
            "Upgrade: websocket\r\n"
            "Connection: Upgrade\r\n"
            f"Sec-WebSocket-Accept: {accept}\r\n"
            "Access-Control-Allow-Origin: *\r\n"
            "\r\n"
        )
        conn.sendall(response.encode())
        return True
    except Exception:
        return False


def _ws_send(conn: socket.socket, message: str) -> bool:
    """Send a WebSocket text frame."""
    try:
        data = message.encode("utf-8")
        length = len(data)
        if length <= 125:
            frame = struct.pack("!BB", 0x81, length) + data
        elif length <= 65535:
            frame = struct.pack("!BBH", 0x81, 126, length) + data
        else:
            frame = struct.pack("!BBQ", 0x81, 127, length) + data
        conn.sendall(frame)
        return True
    except (BrokenPipeError, ConnectionResetError, OSError):
        return False


def _ws_recv(conn: socket.socket) -> Optional[str]:
    """Read one WebSocket frame, return text payload or None on close/error."""
    try:
        conn.settimeout(1.0)
        header = conn.recv(2)
        if len(header) < 2:
            return None
        opcode = header[0] & 0x0F
        if opcode == 8:  # close frame
            return None
        masked   = (header[1] & 0x80) != 0
        length   = header[1] & 0x7F
        if length == 126:
            length = struct.unpack("!H", conn.recv(2))[0]
        elif length == 127:
            length = struct.unpack("!Q", conn.recv(8))[0]
        mask_key = conn.recv(4) if masked else b""
        payload  = conn.recv(length)
        if masked:
            payload = bytes(b ^ mask_key[i % 4] for i, b in enumerate(payload))
        return payload.decode("utf-8", errors="replace")
    except (socket.timeout, ConnectionResetError, OSError):
        return None


# ─────────────────────────────────────────────────
# WebSocket Server
# ─────────────────────────────────────────────────

class WsServer:
    """
    Standalone WebSocket price stream server.
    Listens on a separate port from the HTTP API.

    Clients connect to ws://localhost:8001/ws/market-stream
    and receive JSON price updates every 1.5 seconds.

    Message format:
        { "type": "prices", "data": { "BTC": { price_inr, price_usd, change_24h }, ... } }
        { "type": "ticker", "symbol": "BTC", "data": { ... } }
    """

    def __init__(self, host: str = "127.0.0.1", port: int = 8001):
        self.host     = host
        self.port     = port
        self._clients: set[socket.socket] = set()
        self._lock    = threading.Lock()
        self._running = False
        self._server_sock: Optional[socket.socket] = None
        self._threads: list[threading.Thread] = []

    def start(self) -> None:
        """Start WebSocket server and price broadcast loop in background threads."""
        self._running = True
        t_accept = threading.Thread(target=self._accept_loop, daemon=True, name="ws-accept")
        t_broadcast = threading.Thread(target=self._broadcast_loop, daemon=True, name="ws-broadcast")
        t_accept.start()
        t_broadcast.start()
        self._threads = [t_accept, t_broadcast]
        print(f"[WS] Price stream server running at ws://{self.host}:{self.port}")

    def stop(self) -> None:
        self._running = False
        if self._server_sock:
            try:
                self._server_sock.close()
            except Exception:
                pass

    def client_count(self) -> int:
        with self._lock:
            return len(self._clients)

    def broadcast_extra(self, data: dict) -> None:
        """Broadcast extra message (enriched candle, signal) to all WS clients."""
        try:
            msg = json.dumps(data, default=str)
            with self._lock:
                dead = []
                for client in list(self._clients.values()):
                    try:
                        client.send_text(msg)
                    except Exception:
                        dead.append(id(client))
                for d in dead:
                    self._clients.pop(d, None)
        except Exception:
            pass



    def _accept_loop(self) -> None:
        try:
            self._server_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self._server_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            self._server_sock.bind((self.host, self.port))
            self._server_sock.listen(50)
            self._server_sock.settimeout(1.0)
        except Exception as e:
            print(f"[WS] Failed to bind port {self.port}: {e}")
            return

        while self._running:
            try:
                conn, addr = self._server_sock.accept()
                t = threading.Thread(
                    target=self._handle_client, args=(conn,),
                    daemon=True, name=f"ws-client-{addr[1]}"
                )
                t.start()
            except socket.timeout:
                continue
            except OSError:
                break

    def _handle_client(self, conn: socket.socket) -> None:
        """Perform WS handshake, then keep alive until client disconnects."""
        try:
            conn.settimeout(5.0)
            data = conn.recv(4096)
            if not data:
                return
            if not _ws_handshake(conn, data):
                return

            # Send immediate snapshot
            snap = get_snapshot()
            _ws_send(conn, json.dumps({"type": "snapshot", "data": snap,
                                        "timestamp_ms": int(time.time() * 1000)}))

            with self._lock:
                self._clients.add(conn)

            # Keep connection alive, handle pings
            while self._running:
                msg = _ws_recv(conn)
                if msg is None:
                    break
                # Echo any subscribe requests
                try:
                    parsed = json.loads(msg)
                    if parsed.get("type") == "subscribe":
                        syms = parsed.get("symbols", [])
                        _ws_send(conn, json.dumps({
                            "type": "subscribed",
                            "symbols": syms,
                            "message": f"Subscribed to {len(syms)} symbols"
                        }))
                except (json.JSONDecodeError, Exception):
                    pass

        except Exception:
            pass
        finally:
            with self._lock:
                self._clients.discard(conn)
            try:
                conn.close()
            except Exception:
                pass

    def _broadcast_loop(self) -> None:
        """Tick prices and broadcast to all connected clients every 1.5s."""
        while self._running:
            time.sleep(1.5)
            _tick_prices()
            snap = get_snapshot()
            msg  = json.dumps({
                "type": "prices",
                "data": snap,
                "timestamp_ms": int(time.time() * 1000),
            })
            with self._lock:
                dead = set()
                for conn in self._clients:
                    if not _ws_send(conn, msg):
                        dead.add(conn)
                for conn in dead:
                    self._clients.discard(conn)
                    try:
                        conn.close()
                    except Exception:
                        pass

    def _broadcast_one(self, message: str) -> None:
        """Broadcast a custom message to all connected clients."""
        with self._lock:
            dead = set()
            for conn in self._clients:
                if not _ws_send(conn, message):
                    dead.add(conn)
            for conn in dead:
                self._clients.discard(conn)


# Module-level singleton
_ws_instance: Optional[WsServer] = None


def get_ws_server(host: str = "127.0.0.1", port: int = 8001) -> WsServer:
    global _ws_instance
    if _ws_instance is None:
        _ws_instance = WsServer(host=host, port=port)
    return _ws_instance


def broadcast_signal(strategy_id: str, symbol: str, action: str, price: float) -> None:
    """Broadcast a trading signal to all WS clients."""
    ws = get_ws_server()
    ws._broadcast_one(json.dumps({
        "type": "signal",
        "strategy_id": strategy_id,
        "symbol": symbol,
        "action": action,
        "price": price,
        "timestamp_ms": int(time.time() * 1000),
    }))
