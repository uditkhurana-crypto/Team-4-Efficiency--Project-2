"""
CoinDCX Algo Platform — Core Runtime
# Note: this package is named 'coindcx_platform' internally to avoid shadowing stdlib 'platform'

Self-contained platform runtime for local development and testing.
Replaces Redis/Kafka/PostgreSQL with in-memory equivalents.

In production these swap to:
  EventBus       → Redis pub/sub + Kafka
  StateStore     → PostgreSQL + Redis
  TaskQueue      → Celery + Redis
  MarketFeed     → Exchange WebSocket connections
"""

from __future__ import annotations

import asyncio
import collections
import json
import sqlite3
import threading
import time
import uuid
from dataclasses import asdict, dataclass, field
from decimal import Decimal
from pathlib import Path
from typing import Any, Callable, Optional


# ─────────────────────────────────────────────────────────────────────────────
# Event Bus  (replaces Redis pub/sub + Kafka in local dev)
# ─────────────────────────────────────────────────────────────────────────────

class EventBus:
    """In-process pub/sub. Thread-safe and asyncio-safe."""

    def __init__(self):
        self._subscribers: dict[str, list[Callable]] = {}
        self._lock = threading.Lock()
        self._event_log: list[dict] = []          # audit trail
        self._stats: dict[str, int] = collections.defaultdict(int)

    def subscribe(self, channel: str, handler: Callable) -> None:
        with self._lock:
            self._subscribers.setdefault(channel, []).append(handler)

    def unsubscribe(self, channel: str, handler: Callable) -> None:
        with self._lock:
            if channel in self._subscribers:
                self._subscribers[channel] = [
                    h for h in self._subscribers[channel] if h is not handler
                ]

    def publish(self, channel: str, data: Any) -> int:
        """Publish to channel synchronously. Returns recipient count."""
        with self._lock:
            handlers = list(self._subscribers.get(channel, []))
            self._stats[channel] += 1
            self._event_log.append({
                "channel": channel, "ts": time.time(), "data": data
            })
            if len(self._event_log) > 10000:
                self._event_log = self._event_log[-5000:]

        for handler in handlers:
            try:
                if asyncio.iscoroutinefunction(handler):
                    asyncio.ensure_future(handler(data))
                else:
                    handler(data)
            except Exception as e:
                print(f"[EventBus] Handler error on {channel}: {e}")
        return len(handlers)

    async def publish_async(self, channel: str, data: Any) -> int:
        with self._lock:
            handlers = list(self._subscribers.get(channel, []))
            self._stats[channel] += 1
        results = []
        for handler in handlers:
            try:
                if asyncio.iscoroutinefunction(handler):
                    await handler(data)
                else:
                    handler(data)
                results.append(True)
            except Exception as e:
                print(f"[EventBus] Async handler error on {channel}: {e}")
                results.append(False)
        return len([r for r in results if r])

    def stats(self) -> dict:
        return dict(self._stats)

    def recent_events(self, channel: str = None, n: int = 20) -> list:
        events = self._event_log
        if channel:
            events = [e for e in events if e["channel"] == channel]
        return events[-n:]


# ─────────────────────────────────────────────────────────────────────────────
# State Store  (replaces PostgreSQL + Redis in local dev)
# ─────────────────────────────────────────────────────────────────────────────

class StateStore:
    """
    SQLite-backed persistent state store.
    Schema mirrors the production PostgreSQL schema.
    """

    def __init__(self, db_path: str = ":memory:"):
        self._db_path = db_path
        self._conn = sqlite3.connect(db_path, check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._lock = threading.Lock()
        self._init_schema()

    def _init_schema(self) -> None:
        with self._lock:
            c = self._conn
            c.executescript("""
                PRAGMA journal_mode=WAL;
                PRAGMA foreign_keys=ON;

                CREATE TABLE IF NOT EXISTS users (
                    user_id TEXT PRIMARY KEY,
                    email TEXT UNIQUE NOT NULL,
                    display_name TEXT NOT NULL,
                    password_hash TEXT,
                    tier TEXT NOT NULL DEFAULT 'free',
                    is_active INTEGER NOT NULL DEFAULT 1,
                    created_at REAL NOT NULL,
                    metadata TEXT NOT NULL DEFAULT '{}'
                );

                CREATE TABLE IF NOT EXISTS strategies (
                    strategy_id TEXT PRIMARY KEY,
                    user_id TEXT NOT NULL,
                    name TEXT NOT NULL,
                    description TEXT,
                    symbols TEXT NOT NULL DEFAULT '["BTCUSDT"]',
                    resolution TEXT NOT NULL DEFAULT '1h',
                    status TEXT NOT NULL DEFAULT 'draft',
                    code TEXT NOT NULL DEFAULT '',
                    params TEXT NOT NULL DEFAULT '{}',
                    version INTEGER NOT NULL DEFAULT 1,
                    created_at REAL NOT NULL,
                    updated_at REAL NOT NULL
                );

                CREATE TABLE IF NOT EXISTS backtest_jobs (
                    job_id TEXT PRIMARY KEY,
                    strategy_id TEXT NOT NULL,
                    user_id TEXT NOT NULL,
                    symbol TEXT NOT NULL,
                    resolution TEXT NOT NULL,
                    start_ms INTEGER NOT NULL,
                    end_ms INTEGER NOT NULL,
                    initial_capital REAL NOT NULL,
                    status TEXT NOT NULL DEFAULT 'queued',
                    result_json TEXT,
                    error TEXT,
                    queued_at REAL NOT NULL,
                    started_at REAL,
                    completed_at REAL,
                    duration_s REAL
                );

                CREATE TABLE IF NOT EXISTS deployments (
                    deployment_id TEXT PRIMARY KEY,
                    strategy_id TEXT NOT NULL,
                    user_id TEXT NOT NULL,
                    mode TEXT NOT NULL,
                    initial_capital REAL NOT NULL,
                    status TEXT NOT NULL DEFAULT 'starting',
                    started_at REAL NOT NULL,
                    stopped_at REAL,
                    stop_reason TEXT
                );

                CREATE TABLE IF NOT EXISTS orders (
                    order_id TEXT PRIMARY KEY,
                    client_order_id TEXT NOT NULL,
                    exchange_order_id TEXT,
                    deployment_id TEXT,
                    strategy_id TEXT NOT NULL,
                    user_id TEXT NOT NULL,
                    symbol TEXT NOT NULL,
                    side TEXT NOT NULL,
                    order_type TEXT NOT NULL,
                    quantity REAL NOT NULL,
                    price REAL,
                    status TEXT NOT NULL,
                    filled_quantity REAL NOT NULL DEFAULT 0,
                    avg_fill_price REAL,
                    fees_paid REAL NOT NULL DEFAULT 0,
                    created_at REAL NOT NULL,
                    filled_at REAL
                );

                CREATE TABLE IF NOT EXISTS marketplace_listings (
                    listing_id TEXT PRIMARY KEY,
                    strategy_id TEXT NOT NULL,
                    publisher_user_id TEXT NOT NULL,
                    display_name TEXT NOT NULL,
                    description TEXT NOT NULL DEFAULT '',
                    subscription_fee_usd REAL NOT NULL DEFAULT 0,
                    status TEXT NOT NULL DEFAULT 'pending_review',
                    subscriber_count INTEGER NOT NULL DEFAULT 0,
                    verified_sharpe REAL,
                    verified_return_pct REAL,
                    created_at REAL NOT NULL
                );

                CREATE TABLE IF NOT EXISTS subscriptions (
                    subscription_id TEXT PRIMARY KEY,
                    listing_id TEXT NOT NULL,
                    subscriber_user_id TEXT NOT NULL,
                    master_strategy_id TEXT NOT NULL,
                    allocated_capital_usdt REAL NOT NULL,
                    copy_mode TEXT NOT NULL DEFAULT 'proportional',
                    is_active INTEGER NOT NULL DEFAULT 1,
                    subscribed_at REAL NOT NULL
                );

                CREATE TABLE IF NOT EXISTS audit_log (
                    log_id TEXT PRIMARY KEY,
                    user_id TEXT,
                    action TEXT NOT NULL,
                    resource_type TEXT NOT NULL,
                    resource_id TEXT,
                    details TEXT NOT NULL DEFAULT '{}',
                    occurred_at REAL NOT NULL
                );

                CREATE TABLE IF NOT EXISTS paper_wallets (
                    wallet_id TEXT PRIMARY KEY,
                    user_id TEXT NOT NULL UNIQUE,
                    balance_inr REAL NOT NULL DEFAULT 1000000.0,
                    initial_balance_inr REAL NOT NULL DEFAULT 1000000.0,
                    pnl_realized REAL NOT NULL DEFAULT 0.0,
                    positions_json TEXT NOT NULL DEFAULT '{}',
                    created_at REAL NOT NULL,
                    updated_at REAL NOT NULL
                );

                CREATE TABLE IF NOT EXISTS paper_trades (
                    trade_id TEXT PRIMARY KEY,
                    user_id TEXT NOT NULL,
                    deployment_id TEXT,
                    strategy_name TEXT NOT NULL DEFAULT '',
                    symbol TEXT NOT NULL,
                    side TEXT NOT NULL,
                    quantity REAL NOT NULL,
                    fill_price REAL NOT NULL,
                    fee REAL NOT NULL DEFAULT 0.0,
                    net_pnl REAL NOT NULL DEFAULT 0.0,
                    mode TEXT NOT NULL DEFAULT 'paper',
                    executed_at REAL NOT NULL
                );

                CREATE TABLE IF NOT EXISTS signals (
                    signal_id TEXT PRIMARY KEY,
                    strategy_id TEXT NOT NULL,
                    user_id TEXT NOT NULL,
                    symbol TEXT NOT NULL,
                    action TEXT NOT NULL,
                    price REAL,
                    confidence REAL,
                    metadata TEXT NOT NULL DEFAULT '{}',
                    created_at REAL NOT NULL
                );
            """)
            self._conn.commit()

    def execute(self, sql: str, params=()) -> list[dict]:
        with self._lock:
            cur = self._conn.execute(sql, params)
            self._conn.commit()
            if cur.description:
                return [dict(row) for row in cur.fetchall()]
            return []

    def execute_one(self, sql: str, params=()) -> Optional[dict]:
        rows = self.execute(sql, params)
        return rows[0] if rows else None

    # ── Users ──────────────────────────────────────────────────────────────

    def create_user(self, email: str, display_name: str,
                    password_hash: str = None, tier: str = "free") -> dict:
        uid = str(uuid.uuid4())
        self.execute(
            "INSERT INTO users VALUES (?,?,?,?,?,1,?,?)",
            (uid, email, display_name, password_hash, tier, time.time(), "{}")
        )
        self.audit(uid, "user.created", "user", uid, {"email": email})
        return self.get_user(uid)

    def get_user(self, user_id: str) -> Optional[dict]:
        return self.execute_one("SELECT * FROM users WHERE user_id=?", (user_id,))

    def get_user_by_email(self, email: str) -> Optional[dict]:
        return self.execute_one("SELECT * FROM users WHERE email=?", (email,))

    # ── Strategies ─────────────────────────────────────────────────────────

    def create_strategy(self, user_id: str, name: str, code: str = "",
                        symbols: list = None, resolution: str = "1h",
                        params: dict = None, description: str = "") -> dict:
        sid = str(uuid.uuid4())
        now = time.time()
        self.execute(
            "INSERT INTO strategies VALUES (?,?,?,?,?,?,?,?,?,1,?,?)",
            (sid, user_id, name, description,
             json.dumps(symbols or ["BTCUSDT"]), resolution,
             "draft", code, json.dumps(params or {}), now, now)
        )
        self.audit(user_id, "strategy.created", "strategy", sid, {"name": name})
        return self.get_strategy(sid)

    def get_strategy(self, strategy_id: str) -> Optional[dict]:
        row = self.execute_one("SELECT * FROM strategies WHERE strategy_id=?", (strategy_id,))
        if row:
            row["symbols"] = json.loads(row["symbols"])
            row["params"] = json.loads(row["params"])
        return row

    def update_strategy_code(self, strategy_id: str, code: str, params: dict = None) -> None:
        self.execute(
            "UPDATE strategies SET code=?, params=?, updated_at=?, version=version+1 WHERE strategy_id=?",
            (code, json.dumps(params or {}), time.time(), strategy_id)
        )

    def list_strategies(self, user_id: str) -> list[dict]:
        rows = self.execute("SELECT * FROM strategies WHERE user_id=? ORDER BY created_at DESC", (user_id,))
        for r in rows:
            r["symbols"] = json.loads(r["symbols"])
            r["params"] = json.loads(r["params"])
        return rows

    # ── Backtest Jobs ───────────────────────────────────────────────────────

    def create_backtest_job(self, strategy_id: str, user_id: str, symbol: str,
                            resolution: str, start_ms: int, end_ms: int,
                            initial_capital: float) -> dict:
        jid = str(uuid.uuid4())
        self.execute(
            "INSERT INTO backtest_jobs VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (jid, strategy_id, user_id, symbol, resolution, start_ms, end_ms,
             initial_capital, "queued", None, None, time.time(), None, None, None)
        )
        return self.get_backtest_job(jid)

    def get_backtest_job(self, job_id: str) -> Optional[dict]:
        row = self.execute_one("SELECT * FROM backtest_jobs WHERE job_id=?", (job_id,))
        if row and row.get("result_json"):
            row["result"] = json.loads(row["result_json"])
        return row

    def update_backtest_job(self, job_id: str, status: str,
                            result: dict = None, error: str = None,
                            duration_s: float = None) -> None:
        now = time.time()
        if status == "running":
            self.execute("UPDATE backtest_jobs SET status=?, started_at=? WHERE job_id=?",
                         (status, now, job_id))
        elif status in ("completed", "failed"):
            self.execute(
                "UPDATE backtest_jobs SET status=?, completed_at=?, result_json=?, error=?, duration_s=? WHERE job_id=?",
                (status, now, json.dumps(result) if result else None, error, duration_s, job_id)
            )

    def list_backtest_jobs(self, strategy_id: str) -> list[dict]:
        return self.execute(
            "SELECT job_id, strategy_id, status, queued_at, completed_at, duration_s FROM backtest_jobs WHERE strategy_id=? ORDER BY queued_at DESC",
            (strategy_id,)
        )

    # ── Deployments ─────────────────────────────────────────────────────────

    def create_deployment(self, strategy_id: str, user_id: str,
                          mode: str, initial_capital: float) -> dict:
        did = str(uuid.uuid4())
        self.execute(
            "INSERT INTO deployments VALUES (?,?,?,?,?,?,?,?,?)",
            (did, strategy_id, user_id, mode, initial_capital, "starting", time.time(), None, None)
        )
        self.audit(user_id, f"deployment.{mode}.started", "deployment", did,
                   {"strategy_id": strategy_id, "capital": initial_capital})
        return self.get_deployment(did)

    def get_deployment(self, deployment_id: str) -> Optional[dict]:
        return self.execute_one("SELECT * FROM deployments WHERE deployment_id=?", (deployment_id,))

    def update_deployment_status(self, deployment_id: str, status: str, reason: str = None) -> None:
        if status == "running":
            self.execute("UPDATE deployments SET status=? WHERE deployment_id=?", (status, deployment_id))
        else:
            self.execute(
                "UPDATE deployments SET status=?, stopped_at=?, stop_reason=? WHERE deployment_id=?",
                (status, time.time(), reason, deployment_id)
            )

    def list_deployments(self, user_id: str) -> list[dict]:
        return self.execute(
            "SELECT * FROM deployments WHERE user_id=? ORDER BY started_at DESC", (user_id,)
        )

    # ── Orders ──────────────────────────────────────────────────────────────

    def save_order(self, order: dict) -> None:
        self.execute(
            "INSERT OR REPLACE INTO orders VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (order["order_id"], order["client_order_id"],
             order.get("exchange_order_id"), order.get("deployment_id"),
             order["strategy_id"], order["user_id"], order["symbol"],
             order["side"], order["order_type"], float(order["quantity"]),
             float(order["price"]) if order.get("price") else None,
             order["status"], float(order.get("filled_quantity", 0)),
             float(order["avg_fill_price"]) if order.get("avg_fill_price") else None,
             float(order.get("fees_paid", 0)),
             order.get("created_at", time.time()),
             order.get("filled_at"))
        )

    def list_orders(self, strategy_id: str, limit: int = 50) -> list[dict]:
        return self.execute(
            "SELECT * FROM orders WHERE strategy_id=? ORDER BY created_at DESC LIMIT ?",
            (strategy_id, limit)
        )

    # ── Marketplace ─────────────────────────────────────────────────────────

    def create_listing(self, strategy_id: str, publisher_id: str,
                       name: str, description: str, fee_usd: float = 0) -> dict:
        lid = str(uuid.uuid4())
        self.execute(
            "INSERT INTO marketplace_listings VALUES (?,?,?,?,?,?,?,?,?,?,?)",
            (lid, strategy_id, publisher_id, name, description, fee_usd,
             "pending_review", 0, None, None, time.time())
        )
        return self.get_listing(lid)

    def get_listing(self, listing_id: str) -> Optional[dict]:
        return self.execute_one(
            "SELECT * FROM marketplace_listings WHERE listing_id=?", (listing_id,)
        )

    def list_marketplace(self, status: str = "active") -> list[dict]:
        return self.execute(
            "SELECT * FROM marketplace_listings WHERE status=? ORDER BY subscriber_count DESC",
            (status,)
        )

    def approve_listing(self, listing_id: str, sharpe: float = None, ret: float = None) -> None:
        self.execute(
            "UPDATE marketplace_listings SET status='active', verified_sharpe=?, verified_return_pct=? WHERE listing_id=?",
            (sharpe, ret, listing_id)
        )

    def subscribe_to_listing(self, listing_id: str, subscriber_id: str,
                             master_strategy_id: str, capital: float,
                             copy_mode: str = "proportional") -> dict:
        sid = str(uuid.uuid4())
        self.execute(
            "INSERT INTO subscriptions VALUES (?,?,?,?,?,?,1,?)",
            (sid, listing_id, subscriber_id, master_strategy_id, capital, copy_mode, time.time())
        )
        self.execute(
            "UPDATE marketplace_listings SET subscriber_count=subscriber_count+1 WHERE listing_id=?",
            (listing_id,)
        )
        return {"subscription_id": sid}

    # ── Audit ───────────────────────────────────────────────────────────────

    def audit(self, user_id: str, action: str, resource_type: str,
              resource_id: str, details: dict = None) -> None:
        self.execute(
            "INSERT INTO audit_log VALUES (?,?,?,?,?,?,?)",
            (str(uuid.uuid4()), user_id, action, resource_type,
             resource_id, json.dumps(details or {}), time.time())
        )

    def get_audit_log(self, user_id: str = None, limit: int = 50) -> list[dict]:
        if user_id:
            rows = self.execute(
                "SELECT * FROM audit_log WHERE user_id=? ORDER BY occurred_at DESC LIMIT ?",
                (user_id, limit)
            )
        else:
            rows = self.execute(
                "SELECT * FROM audit_log ORDER BY occurred_at DESC LIMIT ?", (limit,)
            )
        for r in rows:
            r["details"] = json.loads(r.get("details", "{}"))
        return rows


    # ── Paper Wallet ────────────────────────────────────────────────────────

    def get_or_create_wallet(self, user_id: str, initial_inr: float = 1_000_000.0) -> dict:
        row = self.execute_one("SELECT * FROM paper_wallets WHERE user_id=?", (user_id,))
        if not row:
            wid = str(uuid.uuid4())
            now = time.time()
            self.execute(
                "INSERT INTO paper_wallets VALUES (?,?,?,?,?,?,?,?)",
                (wid, user_id, initial_inr, initial_inr, 0.0, "{}", now, now)
            )
            row = self.execute_one("SELECT * FROM paper_wallets WHERE user_id=?", (user_id,))
        row["positions"] = json.loads(row.get("positions_json", "{}"))
        return row

    def update_wallet(self, user_id: str, balance_inr: float,
                      pnl_realized: float, positions: dict) -> None:
        self.execute(
            "UPDATE paper_wallets SET balance_inr=?, pnl_realized=?, positions_json=?, updated_at=? WHERE user_id=?",
            (balance_inr, pnl_realized, json.dumps(positions), time.time(), user_id)
        )

    def log_trade(self, user_id: str, symbol: str, side: str, quantity: float,
                  fill_price: float, fee: float, net_pnl: float,
                  mode: str = "paper", strategy_name: str = "",
                  deployment_id: str = None) -> dict:
        tid = str(uuid.uuid4())
        now = time.time()
        self.execute(
            "INSERT INTO paper_trades VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
            (tid, user_id, deployment_id, strategy_name,
             symbol, side, quantity, fill_price, fee, net_pnl, mode, now)
        )
        return {"trade_id": tid, "executed_at": now}

    def list_trades(self, user_id: str, limit: int = 100) -> list[dict]:
        return self.execute(
            "SELECT * FROM paper_trades WHERE user_id=? ORDER BY executed_at DESC LIMIT ?",
            (user_id, limit)
        )

    # ── Signals ─────────────────────────────────────────────────────────────

    def log_signal(self, strategy_id: str, user_id: str, symbol: str,
                   action: str, price: float = None, confidence: float = None,
                   metadata: dict = None) -> dict:
        sid = str(uuid.uuid4())
        self.execute(
            "INSERT INTO signals VALUES (?,?,?,?,?,?,?,?,?)",
            (sid, strategy_id, user_id, symbol, action, price, confidence,
             json.dumps(metadata or {}), time.time())
        )
        return {"signal_id": sid, "action": action, "symbol": symbol}

    def list_signals(self, user_id: str, limit: int = 50) -> list[dict]:
        rows = self.execute(
            "SELECT * FROM signals WHERE user_id=? ORDER BY created_at DESC LIMIT ?",
            (user_id, limit)
        )
        for r in rows:
            r["metadata"] = json.loads(r.get("metadata", "{}"))
        return rows

    # ── Demo Seeder ─────────────────────────────────────────────────────────

    def seed_demo_data(self, user_id: str) -> dict:
        """
        Pre-load demo strategies + completed backtests + paper wallet
        so the UI has rich data immediately on first login.
        """
        from sdk.examples import (
            MACrossoverStrategy, RSIMeanReversionStrategy,
            BollingerBandStrategy, FundingRateArbitrageStrategy, GridTradingStrategy
        )
        import inspect

        existing = self.list_strategies(user_id)
        if len(existing) >= 3:
            return {"seeded": False, "reason": "already seeded"}

        # 1. Create wallet
        self.get_or_create_wallet(user_id, initial_inr=1_000_000.0)

        demo_strategies = [
            {
                "name": "BTC EMA Crossover",
                "description": "Classic 9/21 EMA crossover on BTC/INR. Captures medium-term trends with clear entry/exit signals.",
                "symbols": ["BTCUSDT"],
                "resolution": "1h",
                "params": {"fast_period": 9, "slow_period": 21, "quantity": "0.001"},
                "code": inspect.getsource(MACrossoverStrategy),
                "backtest": {
                    "total_return_pct": 28.4,
                    "annualized_return_pct": 34.1,
                    "sharpe_ratio": 1.42,
                    "sortino_ratio": 1.84,
                    "max_drawdown_pct": -12.1,
                    "win_rate_pct": 62.3,
                    "profit_factor": 1.84,
                    "total_trades": 234,
                    "total_fees_paid": 18.42,
                },
            },
            {
                "name": "ETH RSI Mean Reversion",
                "description": "RSI oversold/overbought on ETH. Buys dips below RSI 30, exits above RSI 70. Works best in ranging markets.",
                "symbols": ["BTCUSDT"],
                "resolution": "4h",
                "params": {"rsi_period": 14, "oversold": 30, "overbought": 70, "quantity": "0.01"},
                "code": inspect.getsource(RSIMeanReversionStrategy),
                "backtest": {
                    "total_return_pct": 21.2,
                    "annualized_return_pct": 25.4,
                    "sharpe_ratio": 1.18,
                    "sortino_ratio": 1.52,
                    "max_drawdown_pct": -9.4,
                    "win_rate_pct": 58.4,
                    "profit_factor": 1.62,
                    "total_trades": 412,
                    "total_fees_paid": 32.14,
                },
            },
            {
                "name": "BTC Bollinger Band Bounce",
                "description": "Mean reversion at lower Bollinger Band with ATR-based stop loss. Only trades R:R > 2:1 setups.",
                "symbols": ["BTCUSDT"],
                "resolution": "4h",
                "params": {"bb_period": 20, "bb_std": 2.0, "atr_period": 14, "quantity": "0.001"},
                "code": inspect.getsource(BollingerBandStrategy),
                "backtest": {
                    "total_return_pct": 24.8,
                    "annualized_return_pct": 29.7,
                    "sharpe_ratio": 1.31,
                    "sortino_ratio": 1.68,
                    "max_drawdown_pct": -11.2,
                    "win_rate_pct": 56.8,
                    "profit_factor": 1.74,
                    "total_trades": 186,
                    "total_fees_paid": 14.28,
                },
            },
            {
                "name": "MACD Momentum",
                "description": "MACD histogram crossover strategy for momentum capture. Fast 12/26/9 configuration.",
                "symbols": ["BTCUSDT"],
                "resolution": "1h",
                "params": {"fast": 12, "slow": 26, "signal": 9, "quantity": "0.001"},
                "code": """from sdk.strategy import BaseStrategy\nfrom sdk.models import Bar\nfrom decimal import Decimal\n\nclass MACDMomentum(BaseStrategy):\n    SYMBOL = \"BTCUSDT\"\n    RESOLUTION = \"1h\"\n    def on_start(self):\n        self.fast = int(self.params.get(\"fast\", 12))\n        self.slow = int(self.params.get(\"slow\", 26))\n        self.signal_p = int(self.params.get(\"signal\", 9))\n        self.qty = Decimal(str(self.params.get(\"quantity\", \"0.001\")))\n    def _ema(self, data, p):\n        k, e = 2/(p+1), float(data[0])\n        return [e := float(v)*k + e*(1-k) for v in data]\n    def on_bar(self, bar: Bar):\n        closes = self.bars.close\n        if len(closes) < self.slow + self.signal_p + 2: return\n        m12 = self._ema(closes, self.fast)\n        m26 = self._ema(closes, self.slow)\n        macd = [a-b for a,b in zip(m12,m26)]\n        sig = self._ema(macd, self.signal_p)\n        if len(sig) < 2: return\n        if macd[-1] > sig[-1] and macd[-2] <= sig[-2]:\n            if not self.has_position(self.SYMBOL): self.buy(self.SYMBOL, self.qty)\n        elif macd[-1] < sig[-1] and macd[-2] >= sig[-2]:\n            if self.has_position(self.SYMBOL): self.close_position(self.SYMBOL)\n""",
                "backtest": {
                    "total_return_pct": 31.8,
                    "annualized_return_pct": 38.2,
                    "sharpe_ratio": 1.54,
                    "sortino_ratio": 1.98,
                    "max_drawdown_pct": -14.2,
                    "win_rate_pct": 60.1,
                    "profit_factor": 1.96,
                    "total_trades": 298,
                    "total_fees_paid": 23.84,
                },
            },
            {
                "name": "Grid Trading BTC",
                "description": "Automated grid strategy that profits from BTC price oscillation. Places buy/sell orders at fixed intervals.",
                "symbols": ["BTCUSDT"],
                "resolution": "1m",
                "params": {"lower_price": "45000", "upper_price": "55000", "num_grids": 10, "quantity_per_grid": "0.001"},
                "code": inspect.getsource(GridTradingStrategy),
                "backtest": {
                    "total_return_pct": 18.4,
                    "annualized_return_pct": 22.1,
                    "sharpe_ratio": 0.98,
                    "sortino_ratio": 1.24,
                    "max_drawdown_pct": -6.2,
                    "win_rate_pct": 72.4,
                    "profit_factor": 2.14,
                    "total_trades": 1842,
                    "total_fees_paid": 184.2,
                },
            },
        ]

        seeded_ids = []
        for ds in demo_strategies:
            s = self.create_strategy(
                user_id=user_id, name=ds["name"],
                code=ds["code"], symbols=ds["symbols"],
                resolution=ds["resolution"], params=ds["params"],
                description=ds["description"]
            )
            sid = s["strategy_id"]
            seeded_ids.append(sid)

            # Create a completed backtest job with pre-computed results
            jid = str(uuid.uuid4())
            now = time.time()
            n_bars = 500
            initial_capital = 100_000.0
            from coindcx_platform.market_sim import MarketSimulator
            start_ms, end_ms = MarketSimulator.ms_range_for_lookback(ds["resolution"], n_bars)

            m = ds["backtest"]
            # Generate a realistic equity curve
            import math, random as _rand
            _rand.seed(42)
            eq = [initial_capital]
            daily_ret = m["total_return_pct"] / 100 / n_bars
            for i in range(n_bars - 1):
                noise = _rand.gauss(0, 0.008)
                v = eq[-1] * (1 + daily_ret + noise)
                eq.append(max(v, initial_capital * 0.5))
            equity_curve = [[start_ms + i * (end_ms - start_ms) // n_bars, round(v, 2)] for i, v in enumerate(eq)]

            # Monthly returns
            monthly = {}
            months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
                      "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
            for i, mo in enumerate(months):
                monthly[mo] = round(_rand.gauss(m["total_return_pct"] / 12, 3), 2)

            result = {
                "metrics": m,
                "equity_curve": equity_curve[-200:],
                "monthly_returns": monthly,
                "bars_processed": n_bars,
                "errors": [],
                "trades": [
                    {
                        "symbol": ds["symbols"][0],
                        "side": "buy" if i % 2 == 0 else "sell",
                        "entry_price": 50000 + _rand.gauss(0, 2000),
                        "exit_price": 50000 + _rand.gauss(0, 2000),
                        "quantity": 0.001,
                        "net_pnl": _rand.gauss(50, 120),
                        "return_pct": _rand.gauss(0.8, 1.2),
                    }
                    for i in range(min(m["total_trades"], 20))
                ],
            }

            self.execute(
                "INSERT INTO backtest_jobs VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (jid, sid, user_id, ds["symbols"][0], ds["resolution"],
                 start_ms, end_ms, initial_capital, "completed",
                 json.dumps(result), None, now - 3600, now - 3500, now, 4.2)
            )

            # Create an active paper deployment
            dep = self.create_deployment(sid, user_id, "paper", initial_capital)
            self.update_deployment_status(dep["deployment_id"], "running")

            # Seed some paper trades
            wallet = self.get_or_create_wallet(user_id)
            for i in range(6):
                side = "BUY" if i % 2 == 0 else "SELL"
                px = 50000 + _rand.gauss(0, 1000)
                qty = 0.001
                fee = px * qty * 0.001
                pnl = _rand.gauss(40, 80) if side == "SELL" else 0.0
                self.log_trade(
                    user_id=user_id, symbol=ds["symbols"][0],
                    side=side, quantity=qty, fill_price=px,
                    fee=fee, net_pnl=pnl, mode="paper",
                    strategy_name=ds["name"],
                    deployment_id=dep["deployment_id"]
                )

            # Seed marketplace listing
            listing = self.create_listing(
                strategy_id=sid, publisher_id=user_id,
                name=ds["name"], description=ds["description"],
                fee_usd=29.99 + len(seeded_ids) * 10
            )
            self.approve_listing(
                listing["listing_id"],
                sharpe=m["sharpe_ratio"],
                ret=m["total_return_pct"]
            )
            # Bump subscriber count
            self.execute(
                "UPDATE marketplace_listings SET subscriber_count=? WHERE listing_id=?",
                (_rand.randint(80, 1200), listing["listing_id"])
            )

        # Update wallet with paper PnL
        self.update_wallet(user_id, 1_042_350.0, 42_350.0, {
            "BTC": {"qty": 0.012, "avg_price": 3_380_000, "side": "LONG"},
            "ETH": {"qty": 0.48, "avg_price": 242_000, "side": "LONG"},
        })

        return {"seeded": True, "strategies": len(seeded_ids), "strategy_ids": seeded_ids}


# ─────────────────────────────────────────────────────────────────────────────
# Task Queue  (replaces Celery in local dev)
# ─────────────────────────────────────────────────────────────────────────────

class TaskQueue:
    """In-process task queue using threads. Mirrors Celery API."""

    def __init__(self):
        self._queue: collections.deque = collections.deque()
        self._results: dict[str, dict] = {}
        self._lock = threading.Lock()
        self._running = False
        self._worker_thread: Optional[threading.Thread] = None

    def start(self) -> None:
        self._running = True
        self._worker_thread = threading.Thread(target=self._worker_loop, daemon=True)
        self._worker_thread.start()

    def stop(self) -> None:
        self._running = False

    def submit(self, task_fn: Callable, task_id: str = None, **kwargs) -> str:
        tid = task_id or str(uuid.uuid4())
        with self._lock:
            self._queue.append({"task_id": tid, "fn": task_fn, "kwargs": kwargs})
            self._results[tid] = {"status": "queued", "task_id": tid}
        return tid

    def get_result(self, task_id: str) -> Optional[dict]:
        return self._results.get(task_id)

    def _worker_loop(self) -> None:
        while self._running:
            task = None
            with self._lock:
                if self._queue:
                    task = self._queue.popleft()
            if task:
                tid = task["task_id"]
                self._results[tid] = {"status": "running", "task_id": tid, "started_at": time.time()}
                try:
                    result = task["fn"](**task["kwargs"])
                    self._results[tid] = {
                        "status": "completed", "task_id": tid,
                        "result": result, "completed_at": time.time()
                    }
                except Exception as e:
                    self._results[tid] = {
                        "status": "failed", "task_id": tid,
                        "error": str(e), "completed_at": time.time()
                    }
            else:
                time.sleep(0.05)


# ─────────────────────────────────────────────────────────────────────────────
# Singleton Platform
# ─────────────────────────────────────────────────────────────────────────────

class Platform:
    """Single entry point to all platform services."""

    _instance: Optional["Platform"] = None

    def __init__(self, db_path: str = ":memory:"):
        self.db = StateStore(db_path)
        self.bus = EventBus()
        self.tasks = TaskQueue()
        self.tasks.start()
        self._started_at = time.time()

    @classmethod
    def get(cls, db_path: str = ":memory:") -> "Platform":
        if cls._instance is None:
            cls._instance = cls(db_path)
        return cls._instance

    @classmethod
    def reset(cls) -> None:
        """Reset singleton — used in tests."""
        if cls._instance:
            cls._instance.tasks.stop()
        cls._instance = None

    def uptime(self) -> float:
        return time.time() - self._started_at

    def health(self) -> dict:
        return {
            "status": "ok",
            "uptime_s": round(self.uptime(), 1),
            "bus_channels": len(self.db.execute("SELECT 1")),
            "task_queue_depth": len(self.tasks._queue),
        }
