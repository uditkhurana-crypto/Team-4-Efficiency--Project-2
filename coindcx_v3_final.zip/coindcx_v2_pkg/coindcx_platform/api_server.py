"""
CoinDCX Algo Platform — Local Development API Server

Stdlib-only HTTP server that implements the full platform REST API.
Used for local development and E2E testing without FastAPI/uvicorn.

Endpoints match the production FastAPI app exactly.
In production, swap this file for api/main.py + uvicorn.
"""

from __future__ import annotations

import asyncio
import hashlib
import hmac
import json
import os
import sys
import time
import traceback
import uuid
from decimal import Decimal
from http.server import BaseHTTPRequestHandler, HTTPServer
from threading import Thread
from typing import Any
from urllib.parse import parse_qs, urlparse

# Add parent to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from coindcx_platform.core import Platform
from coindcx_platform.market_sim import MarketSimulator, SimConfig


JWT_SECRET = os.environ.get("JWT_SECRET", "dev-secret-change-in-prod")
_platform: Platform = None


def get_platform() -> Platform:
    global _platform
    if _platform is None:
        _platform = Platform.get(db_path=os.environ.get("DB_PATH", ":memory:"))
    return _platform


# ─────────────────────────────────────────────────
# Minimal JWT implementation (stdlib only)
# ─────────────────────────────────────────────────

import base64

def _b64url_encode(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode()

def _b64url_decode(s: str) -> bytes:
    s += "=" * (4 - len(s) % 4)
    return base64.urlsafe_b64decode(s)

def create_token(user_id: str, expires_in: int = 86400) -> str:
    header = _b64url_encode(json.dumps({"alg": "HS256", "typ": "JWT"}).encode())
    payload = _b64url_encode(json.dumps({
        "sub": user_id,
        "exp": int(time.time()) + expires_in,
        "iat": int(time.time()),
    }).encode())
    sig_data = f"{header}.{payload}".encode()
    sig = hmac.new(JWT_SECRET.encode(), sig_data, hashlib.sha256).digest()
    return f"{header}.{payload}.{_b64url_encode(sig)}"

def verify_token(token: str) -> dict | None:
    try:
        parts = token.split(".")
        if len(parts) != 3:
            return None
        header, payload, sig = parts
        sig_data = f"{header}.{payload}".encode()
        expected = hmac.new(JWT_SECRET.encode(), sig_data, hashlib.sha256).digest()
        if not hmac.compare_digest(_b64url_encode(expected), sig):
            return None
        data = json.loads(_b64url_decode(payload))
        if data.get("exp", 0) < time.time():
            return None
        return data
    except Exception:
        return None


# ─────────────────────────────────────────────────
# Route handlers
# ─────────────────────────────────────────────────

class Router:
    def __init__(self):
        self._routes: list[tuple[str, str, Any]] = []

    def add(self, method: str, path: str, handler):
        self._routes.append((method, path, handler))

    def match(self, method: str, path: str) -> tuple[Any, dict]:
        for m, pattern, handler in self._routes:
            if m != method:
                continue
            params = self._match_pattern(pattern, path)
            if params is not None:
                return handler, params
        return None, {}

    def _match_pattern(self, pattern: str, path: str) -> dict | None:
        p_parts = pattern.strip("/").split("/")
        r_parts = path.strip("/").split("/")
        if len(p_parts) != len(r_parts):
            return None
        params = {}
        for pp, rp in zip(p_parts, r_parts):
            if pp.startswith("{") and pp.endswith("}"):
                params[pp[1:-1]] = rp
            elif pp != rp:
                return None
        return params


router = Router()

def route(method: str, path: str):
    def decorator(fn):
        router.add(method, path, fn)
        return fn
    return decorator


# ─────────────────────────────────────────────────
# API Route Handlers
# ─────────────────────────────────────────────────

@route("GET", "/health")
def health(req, params):
    p = get_platform()
    return {"status": "ok", "uptime_s": round(p.uptime(), 1), "version": "1.0.0"}

@route("GET", "/api/v1/status")
def status(req, params):
    p = get_platform()
    return {
        "platform": "CoinDCX Algo",
        "version": "1.0.0",
        "mode": "local_dev",
        "uptime_s": round(p.uptime(), 1),
        "bus_stats": p.bus.stats(),
    }

# ── Auth ────────────────────────────────────────

@route("POST", "/api/v1/auth/register")
def register(req, params):
    body = req.get("body", {})
    email = body.get("email", "").strip().lower()
    name = body.get("display_name", email.split("@")[0])
    password = body.get("password", "")
    if not email or not password:
        raise ValueError("email and password are required")
    p = get_platform()
    if p.db.get_user_by_email(email):
        raise ValueError(f"Email '{email}' already registered")
    pw_hash = hashlib.sha256(password.encode()).hexdigest()
    user = p.db.create_user(email, name, pw_hash)
    token = create_token(user["user_id"])
    return {"user_id": user["user_id"], "email": user["email"],
            "display_name": user["display_name"], "token": token}

@route("POST", "/api/v1/auth/login")
def login(req, params):
    body = req.get("body", {})
    email = body.get("email", "").strip().lower()
    password = body.get("password", "")
    p = get_platform()
    user = p.db.get_user_by_email(email)
    if not user:
        raise PermissionError("Invalid credentials")
    pw_hash = hashlib.sha256(password.encode()).hexdigest()
    if user.get("password_hash") and user["password_hash"] != pw_hash:
        raise PermissionError("Invalid credentials")
    token = create_token(user["user_id"])
    p.db.audit(user["user_id"], "auth.login", "user", user["user_id"], {})
    return {"token": token, "user_id": user["user_id"],
            "email": user["email"], "tier": user["tier"]}

@route("GET", "/api/v1/auth/me")
def me(req, params):
    user = _require_auth(req)
    return {"user_id": user["user_id"], "email": user["email"],
            "display_name": user["display_name"], "tier": user["tier"]}

# ── Strategies ──────────────────────────────────

@route("POST", "/api/v1/strategies")
def create_strategy(req, params):
    user = _require_auth(req)
    body = req.get("body", {})
    name = body.get("name", "").strip()
    if not name:
        raise ValueError("name is required")
    p = get_platform()
    strategy = p.db.create_strategy(
        user_id=user["user_id"],
        name=name,
        code=body.get("code", ""),
        symbols=body.get("symbols", ["BTCUSDT"]),
        resolution=body.get("resolution", "1h"),
        params=body.get("params", {}),
        description=body.get("description", ""),
    )
    p.bus.publish("strategy.created", {"strategy_id": strategy["strategy_id"], "user_id": user["user_id"]})
    return strategy

@route("GET", "/api/v1/strategies")
def list_strategies(req, params):
    user = _require_auth(req)
    p = get_platform()
    return {"strategies": p.db.list_strategies(user["user_id"])}

@route("GET", "/api/v1/strategies/{strategy_id}")
def get_strategy(req, params):
    user = _require_auth(req)
    p = get_platform()
    s = p.db.get_strategy(params["strategy_id"])
    if not s:
        raise KeyError("Strategy not found")
    if s["user_id"] != user["user_id"]:
        raise PermissionError("Access denied")
    return s

@route("PUT", "/api/v1/strategies/{strategy_id}/code")
def update_strategy_code(req, params):
    user = _require_auth(req)
    body = req.get("body", {})
    code = body.get("code", "")
    p = get_platform()
    s = p.db.get_strategy(params["strategy_id"])
    if not s or s["user_id"] != user["user_id"]:
        raise PermissionError("Access denied")

    # Validate before saving
    from engine.execution.validator import StrategyValidator
    val_result = StrategyValidator().validate(code)
    p.db.update_strategy_code(params["strategy_id"], code, body.get("params", s["params"]))
    return {
        "strategy_id": params["strategy_id"],
        "version": s["version"] + 1,
        "validation": {
            "is_valid": val_result.is_valid,
            "errors": [{"code": i.code, "message": i.message} for i in val_result.errors],
            "warnings": [{"code": i.code, "message": i.message} for i in val_result.warnings],
            "complexity_score": val_result.complexity_score,
            "detected_class": val_result.strategy_class_name,
        }
    }

@route("POST", "/api/v1/strategies/{strategy_id}/validate")
def validate_strategy(req, params):
    user = _require_auth(req)
    body = req.get("body", {})
    code = body.get("code", "")
    from engine.execution.validator import StrategyValidator
    result = StrategyValidator().validate(code)
    return {
        "is_valid": result.is_valid,
        "errors": [{"code": i.code, "message": i.message, "line": i.line} for i in result.errors],
        "warnings": [{"code": i.code, "message": i.message} for i in result.warnings],
        "complexity_score": result.complexity_score,
        "detected_class": result.strategy_class_name,
        "detected_symbols": result.detected_symbols,
        "detected_resolution": result.detected_resolution,
    }

# ── Backtesting ─────────────────────────────────

@route("POST", "/api/v1/backtests")
def submit_backtest(req, params):
    user = _require_auth(req)
    body = req.get("body", {})
    strategy_id = body.get("strategy_id")
    if not strategy_id:
        raise ValueError("strategy_id is required")
    p = get_platform()
    s = p.db.get_strategy(strategy_id)
    if not s or s["user_id"] != user["user_id"]:
        raise PermissionError("Access denied")
    if not s.get("code", "").strip():
        raise ValueError("Strategy has no code. Update strategy code before running backtest.")

    symbol = body.get("symbol", s["symbols"][0] if s["symbols"] else "BTCUSDT")
    resolution = body.get("resolution", s["resolution"])
    n_bars = body.get("n_bars", 500)
    initial_capital = float(body.get("initial_capital", 10000))

    sim = MarketSimulator(SimConfig(symbol=symbol, seed=42))
    start_ms, end_ms = MarketSimulator.ms_range_for_lookback(resolution, n_bars)
    job = p.db.create_backtest_job(
        strategy_id, user["user_id"], symbol, resolution,
        start_ms, end_ms, initial_capital
    )

    # Run backtest synchronously in thread (in prod this is Celery)
    def _run():
        from backtesting.engine import BacktestEngine, BacktestConfig
        from engine.execution.validator import StrategyValidator
        import importlib.util, tempfile

        p.db.update_backtest_job(job["job_id"], "running")
        t0 = time.time()
        try:
            bars_data = sim.generate_bars(symbol, resolution, start_ms, end_ms)
            # Load strategy class dynamically
            with tempfile.NamedTemporaryFile(suffix=".py", mode="w", delete=False) as f:
                f.write(s["code"])
                tmp = f.name
            spec = importlib.util.spec_from_file_location("_strat", tmp)
            mod = importlib.util.module_from_spec(spec)
            # Ensure project root is on path so strategy can import sdk.*
            import sys as _sys
            _project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            if _project_root not in _sys.path:
                _sys.path.insert(0, _project_root)
            spec.loader.exec_module(mod)
            from sdk.strategy import BaseStrategy
            classes = [v for v in vars(mod).values()
                       if isinstance(v, type) and issubclass(v, BaseStrategy) and v is not BaseStrategy]
            if not classes:
                raise ValueError("No BaseStrategy subclass found")
            klass = classes[-1]

            from sdk.models import Bar
            bars = [Bar(
                symbol=b["symbol"], open=Decimal(str(b["open"])),
                high=Decimal(str(b["high"])), low=Decimal(str(b["low"])),
                close=Decimal(str(b["close"])), volume=Decimal(str(b["volume"])),
                timestamp_ms=b["timestamp_ms"], resolution=b["resolution"],
            ) for b in bars_data]

            config = BacktestConfig(
                strategy_class=klass,
                strategy_params=s.get("params", {}),
                symbol=symbol, resolution=resolution,
                start_ms=start_ms, end_ms=end_ms,
                initial_capital=Decimal(str(initial_capital)),
                simulate_latency=False,
            )
            engine = BacktestEngine(config)
            loop = asyncio.new_event_loop()
            result = loop.run_until_complete(engine.run(bars))
            loop.close()

            result_dict = {
                "metrics": {
                    "total_return_pct": result.metrics.total_return_pct,
                    "annualized_return_pct": result.metrics.annualized_return_pct,
                    "sharpe_ratio": result.metrics.sharpe_ratio,
                    "sortino_ratio": result.metrics.sortino_ratio,
                    "max_drawdown_pct": result.metrics.max_drawdown_pct,
                    "win_rate_pct": result.metrics.win_rate_pct,
                    "profit_factor": result.metrics.profit_factor,
                    "total_trades": result.metrics.total_trades,
                    "total_fees_paid": float(result.metrics.total_fees_paid),
                },
                "equity_curve": [[ts, float(eq)] for ts, eq in result.equity_curve[-100:]],
                "trades": [
                    {"symbol": t.symbol, "side": t.side.value,
                     "entry_price": float(t.entry_price), "exit_price": float(t.exit_price),
                     "quantity": float(t.quantity), "net_pnl": float(t.net_pnl),
                     "return_pct": t.return_pct}
                    for t in result.trades
                ],
                "bars_processed": result.bars_processed,
                "errors": result.errors,
            }
            duration = time.time() - t0
            p.db.update_backtest_job(job["job_id"], "completed", result_dict, duration_s=duration)
            p.bus.publish("backtest.completed", {"job_id": job["job_id"], "strategy_id": strategy_id})
        except Exception as e:
            p.db.update_backtest_job(job["job_id"], "failed", error=str(e))
            p.bus.publish("backtest.failed", {"job_id": job["job_id"], "error": str(e)})

    p.tasks.submit(_run, task_id=job["job_id"])
    return {"job_id": job["job_id"], "status": "queued",
            "message": "Backtest queued. Poll GET /api/v1/backtests/{job_id} for results."}

@route("GET", "/api/v1/backtests/{job_id}")
def get_backtest(req, params):
    user = _require_auth(req)
    p = get_platform()
    job = p.db.get_backtest_job(params["job_id"])
    if not job:
        raise KeyError("Backtest job not found")
    if job["user_id"] != user["user_id"]:
        raise PermissionError("Access denied")
    return job

@route("GET", "/api/v1/strategies/{strategy_id}/backtests")
def list_backtests(req, params):
    user = _require_auth(req)
    p = get_platform()
    s = p.db.get_strategy(params["strategy_id"])
    if not s or s["user_id"] != user["user_id"]:
        raise PermissionError("Access denied")
    return {"jobs": p.db.list_backtest_jobs(params["strategy_id"])}

# ── Deployments ─────────────────────────────────

@route("POST", "/api/v1/deployments")
def create_deployment(req, params):
    user = _require_auth(req)
    body = req.get("body", {})
    strategy_id = body.get("strategy_id")
    mode = body.get("mode", "paper")
    capital = float(body.get("initial_capital", 10000))
    if mode not in ("paper", "live"):
        raise ValueError("mode must be 'paper' or 'live'")
    p = get_platform()
    s = p.db.get_strategy(strategy_id)
    if not s or s["user_id"] != user["user_id"]:
        raise PermissionError("Access denied")

    dep = p.db.create_deployment(strategy_id, user["user_id"], mode, capital)
    # Simulate deployment starting
    time.sleep(0.1)
    p.db.update_deployment_status(dep["deployment_id"], "running")
    dep = p.db.get_deployment(dep["deployment_id"])
    p.bus.publish(f"deployment.{mode}.started",
                  {"deployment_id": dep["deployment_id"], "strategy_id": strategy_id})
    return dep

@route("GET", "/api/v1/deployments")
def list_deployments(req, params):
    user = _require_auth(req)
    p = get_platform()
    return {"deployments": p.db.list_deployments(user["user_id"])}

@route("GET", "/api/v1/deployments/{deployment_id}")
def get_deployment(req, params):
    user = _require_auth(req)
    p = get_platform()
    dep = p.db.get_deployment(params["deployment_id"])
    if not dep:
        raise KeyError("Deployment not found")
    if dep["user_id"] != user["user_id"]:
        raise PermissionError("Access denied")
    return dep

@route("POST", "/api/v1/deployments/{deployment_id}/stop")
def stop_deployment(req, params):
    user = _require_auth(req)
    body = req.get("body", {})
    p = get_platform()
    dep = p.db.get_deployment(params["deployment_id"])
    if not dep or dep["user_id"] != user["user_id"]:
        raise PermissionError("Access denied")
    p.db.update_deployment_status(dep["deployment_id"], "stopped", body.get("reason", "user_requested"))
    p.bus.publish("deployment.stopped", {"deployment_id": dep["deployment_id"]})
    return {"deployment_id": dep["deployment_id"], "status": "stopped"}

# ── Market Data ─────────────────────────────────

@route("GET", "/api/v1/market/bars/{symbol}/{resolution}")
def get_bars(req, params):
    _require_auth(req)
    symbol = params["symbol"]
    resolution = params.get("resolution", "1h")
    n_bars = int(req.get("query", {}).get("n", ["100"])[0])
    sim = MarketSimulator(SimConfig(symbol=symbol, seed=42))
    start_ms, end_ms = MarketSimulator.ms_range_for_lookback(resolution, n_bars)
    bars = sim.generate_bars(symbol, resolution, start_ms, end_ms)
    return {"symbol": symbol, "resolution": resolution,
            "count": len(bars), "bars": bars[-100:]}

@route("GET", "/api/v1/market/ticker/{symbol}")
def get_ticker(req, params):
    _require_auth(req)
    symbol = params["symbol"]
    sim = MarketSimulator(SimConfig(symbol=symbol))
    bars = sim.generate_bars(symbol, "1m", int(time.time() * 1000) - 60000, int(time.time() * 1000))
    price = bars[-1]["close"] if bars else 50000.0
    return {"symbol": symbol, "price": price,
            "change_24h": round((price - 50000) / 50000 * 100, 2),
            "volume_24h": round(50000 * 100, 2),
            "timestamp_ms": int(time.time() * 1000)}

@route("GET", "/api/v1/market/orderbook/{symbol}")
def get_orderbook(req, params):
    _require_auth(req)
    sim = MarketSimulator()
    ob = sim.generate_orderbook(params["symbol"], 50000.0)
    return ob

# ── Analytics ────────────────────────────────────

@route("GET", "/api/v1/analytics/strategy/{strategy_id}")
def get_strategy_analytics(req, params):
    user = _require_auth(req)
    p = get_platform()
    s = p.db.get_strategy(params["strategy_id"])
    if not s or s["user_id"] != user["user_id"]:
        raise PermissionError("Access denied")
    jobs = p.db.list_backtest_jobs(params["strategy_id"])
    completed = [j for j in jobs if j.get("status") == "completed"]
    if not completed:
        return {"message": "No completed backtests yet", "strategy_id": params["strategy_id"]}
    latest_job = p.db.get_backtest_job(completed[0]["job_id"])
    return {
        "strategy_id": params["strategy_id"],
        "backtests_run": len(completed),
        "latest_metrics": latest_job.get("result", {}).get("metrics", {}),
    }

# ── Marketplace ──────────────────────────────────

@route("POST", "/api/v1/marketplace/listings")
def create_listing(req, params):
    user = _require_auth(req)
    body = req.get("body", {})
    strategy_id = body.get("strategy_id")
    p = get_platform()
    s = p.db.get_strategy(strategy_id)
    if not s or s["user_id"] != user["user_id"]:
        raise PermissionError("Access denied")
    listing = p.db.create_listing(
        strategy_id=strategy_id,
        publisher_id=user["user_id"],
        name=body.get("name", s["name"]),
        description=body.get("description", ""),
        fee_usd=float(body.get("subscription_fee_usd", 0)),
    )
    return listing

@route("GET", "/api/v1/marketplace/listings")
def list_listings(req, params):
    _require_auth(req)
    p = get_platform()
    status = req.get("query", {}).get("status", ["active"])[0]
    return {"listings": p.db.list_marketplace(status)}

@route("POST", "/api/v1/marketplace/listings/{listing_id}/approve")
def approve_listing(req, params):
    user = _require_auth(req)
    body = req.get("body", {})
    p = get_platform()
    p.db.approve_listing(
        params["listing_id"],
        sharpe=body.get("verified_sharpe"),
        ret=body.get("verified_return_pct"),
    )
    p.bus.publish("marketplace.listing.approved", {"listing_id": params["listing_id"]})
    return {"listing_id": params["listing_id"], "status": "active"}

@route("POST", "/api/v1/marketplace/listings/{listing_id}/subscribe")
def subscribe_listing(req, params):
    user = _require_auth(req)
    body = req.get("body", {})
    p = get_platform()
    listing = p.db.get_listing(params["listing_id"])
    if not listing:
        raise KeyError("Listing not found")
    if listing["status"] != "active":
        raise ValueError("Listing is not active")
    result = p.db.subscribe_to_listing(
        listing_id=params["listing_id"],
        subscriber_id=user["user_id"],
        master_strategy_id=listing["strategy_id"],
        capital=float(body.get("allocated_capital_usdt", 1000)),
        copy_mode=body.get("copy_mode", "proportional"),
    )
    p.bus.publish("marketplace.subscription.created",
                  {"listing_id": params["listing_id"], "subscriber": user["user_id"]})
    return result

# ── Audit & Admin ────────────────────────────────

@route("GET", "/api/v1/audit/log")
def get_audit_log(req, params):
    user = _require_auth(req)
    p = get_platform()
    return {"events": p.db.get_audit_log(user["user_id"], limit=50)}

@route("GET", "/api/v1/admin/platform-stats")
def platform_stats(req, params):
    user = _require_auth(req)
    p = get_platform()
    users = p.db.execute("SELECT COUNT(*) as c FROM users")[0]["c"]
    strategies = p.db.execute("SELECT COUNT(*) as c FROM strategies")[0]["c"]
    jobs = p.db.execute("SELECT COUNT(*) as c FROM backtest_jobs")[0]["c"]
    listings = p.db.execute("SELECT COUNT(*) as c FROM marketplace_listings")[0]["c"]
    return {
        "users": users, "strategies": strategies,
        "backtest_jobs": jobs, "marketplace_listings": listings,
        "uptime_s": round(p.uptime(), 1),
        "event_bus_stats": p.bus.stats(),
    }

# ── Paper Wallet ─────────────────────────────────

@route("GET", "/api/v1/wallet")
def get_wallet(req, params):
    user = _require_auth(req)
    p = get_platform()
    wallet = p.db.get_or_create_wallet(user["user_id"])
    return wallet

@route("POST", "/api/v1/wallet/trade")
def manual_trade(req, params):
    """Execute a paper or live trade with strategy attribution."""
    user = _require_auth(req)
    body = req.get("body", {})
    symbol      = body.get("symbol", "BTC").upper().replace("/INR","").replace("INR","").replace("USDT","")
    side        = body.get("side", "BUY").upper()
    qty         = float(body.get("quantity", 0.001))
    mode        = body.get("mode", "paper")
    strategy_id = body.get("strategy_id")
    strategy_name = body.get("strategy_name", "Manual Trade")

    from execution_engine.engine import ExecutionEngine
    _engines = _get_engines()
    uid = user["user_id"]
    if uid not in _engines:
        wallet = get_platform().db.get_or_create_wallet(uid)
        _engines[uid] = ExecutionEngine(mode=mode, initial_capital=wallet["balance_inr"])

    eng = _engines[uid]
    eng.set_mode(mode)

    if side == "BUY":
        result = eng.place_market_buy(symbol, qty,
                                       strategy_id=strategy_id, strategy_name=strategy_name)
    else:
        result = eng.place_market_sell(symbol, qty,
                                        strategy_id=strategy_id, strategy_name=strategy_name)

    p = get_platform()
    if result.success:
        p.db.log_trade(
            user_id=uid, symbol=symbol, side=side,
            quantity=result.quantity, fill_price=result.fill_price,
            fee=result.fee, net_pnl=result.net_pnl, mode=mode,
            strategy_name=strategy_name,
        )
        if mode != "live":
            ws = eng.wallet
            p.db.update_wallet(uid, ws.balance_inr, ws.pnl_realized, ws.positions)

    p.bus.publish("trade.executed", {"user_id": uid, "symbol": symbol,
                                      "side": side, "mode": mode, "success": result.success})
    return {
        "trade_id":        result.trade_id,
        "order_id":        result.order_id,
        "client_order_id": result.client_order_id,
        "symbol":          symbol,
        "side":            side,
        "quantity":        result.quantity,
        "fill_price":      result.fill_price,
        "fee":             result.fee,
        "net_pnl":         result.net_pnl,
        "mode":            result.mode,
        "success":         result.success,
        "error":           result.error,
        "order_status":    result.order_status,
        "reject_reason":   result.reject_reason,
        "human_status":    result.order_status or ("Filled ✓" if result.success else (result.error or "Failed")),
        "wallet":          eng.get_wallet_state(),
    }

@route("GET", "/api/v1/wallet/trades")
def list_wallet_trades(req, params):
    user = _require_auth(req)
    p = get_platform()
    limit = int(req.get("query", {}).get("limit", ["100"])[0])
    return {"trades": p.db.list_trades(user["user_id"], limit=limit)}


# ── Order Status (live) ──────────────────────────

@route("GET", "/api/v1/orders/{order_id}/status")
def get_order_status(req, params):
    """Poll real CoinDCX order status and surface rejection reason."""
    user = _require_auth(req)
    order_id = params.get("order_id", "")
    _engines = _get_engines()
    uid = user["user_id"]
    if uid not in _engines:
        from execution_engine.engine import ExecutionEngine
        _engines[uid] = ExecutionEngine()
    eng = _engines[uid]
    return eng.get_order_status(order_id)


# ── Strategy P&L attribution ──────────────────────

@route("GET", "/api/v1/strategies/{strategy_id}/pnl")
def get_strategy_pnl(req, params):
    """Return realized P&L, fees and trade list attributed to a strategy."""
    user = _require_auth(req)
    strategy_id = params.get("strategy_id", "")
    _engines = _get_engines()
    uid = user["user_id"]
    if uid not in _engines:
        from execution_engine.engine import ExecutionEngine
        _engines[uid] = ExecutionEngine()
    eng = _engines[uid]
    return eng.get_strategy_pnl(strategy_id)


# ── Live wallet (real CoinDCX balance) ────────────

@route("GET", "/api/v1/wallet/live")
def get_live_wallet(req, params):
    """Fetch real wallet balance from CoinDCX (requires live API keys)."""
    user = _require_auth(req)
    uid  = user["user_id"]
    _engines = _get_engines()
    if uid not in _engines:
        from execution_engine.engine import ExecutionEngine
        _engines[uid] = ExecutionEngine(mode="live")
    eng = _engines[uid]
    eng.set_mode("live")
    return eng.get_wallet_state()


# ── Freqtrade strategy export ──────────────────────

@route("GET", "/api/v1/strategies/{strategy_id}/export/freqtrade")
def export_freqtrade(req, params):
    """
    Export a strategy as a Freqtrade-compatible Python class.
    Freqtrade is the most widely used open-source crypto algo framework (47K GitHub stars).
    The exported file can be dropped into ~/freqtrade/user_data/strategies/ and run directly.
    """
    user = _require_auth(req)
    p = get_platform()
    strategy_id = params.get("strategy_id", "")
    strat = p.db.get_strategy(strategy_id)
    if not strat:
        raise ValueError(f"Strategy {strategy_id} not found")

    name     = strat.get("name", "MyStrategy")
    code     = strat.get("code", "")
    symbol   = strat.get("symbol", "BTC/INR")
    timeframe = strat.get("timeframe", "1h")

    # Detect strategy type from code/name to pick the right Freqtrade template
    code_lower = (code + name).lower()
    if "ema" in code_lower and "crossover" in code_lower:
        indicator_code = """
        # EMA Crossover
        dataframe['ema_fast'] = ta.EMA(dataframe, timeperiod=9)
        dataframe['ema_slow'] = ta.EMA(dataframe, timeperiod=21)"""
        buy_cond  = "dataframe['ema_fast'] > dataframe['ema_slow']"
        sell_cond = "dataframe['ema_fast'] < dataframe['ema_slow']"
        strat_type = "EMA Crossover"
    elif "rsi" in code_lower:
        indicator_code = """
        # RSI Mean Reversion
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=14)"""
        buy_cond  = "dataframe['rsi'] < 30"
        sell_cond = "dataframe['rsi'] > 70"
        strat_type = "RSI Mean Reversion"
    elif "bollinger" in code_lower or "bb" in code_lower:
        indicator_code = """
        # Bollinger Bands
        bollinger = qtpylib.bollinger_bands(dataframe['close'], window=20, stds=2)
        dataframe['bb_lower'] = bollinger['lower']
        dataframe['bb_mid']   = bollinger['mid']
        dataframe['bb_upper'] = bollinger['upper']"""
        buy_cond  = "dataframe['close'] < dataframe['bb_lower']"
        sell_cond = "dataframe['close'] > dataframe['bb_upper']"
        strat_type = "Bollinger Band Bounce"
    elif "macd" in code_lower:
        indicator_code = """
        # MACD Momentum
        macd = ta.MACD(dataframe)
        dataframe['macd']   = macd['macd']
        dataframe['signal'] = macd['macdsignal']
        dataframe['hist']   = macd['macdhist']"""
        buy_cond  = "(dataframe['macd'] > dataframe['signal']) & (dataframe['hist'] > 0)"
        sell_cond = "(dataframe['macd'] < dataframe['signal']) & (dataframe['hist'] < 0)"
        strat_type = "MACD Momentum"
    elif "grid" in code_lower:
        indicator_code = """
        # Grid Trading — use ATR for grid sizing
        dataframe['atr'] = ta.ATR(dataframe, timeperiod=14)
        dataframe['sma'] = ta.SMA(dataframe, timeperiod=50)"""
        buy_cond  = "dataframe['close'] < dataframe['sma'] * 0.995"
        sell_cond = "dataframe['close'] > dataframe['sma'] * 1.005"
        strat_type = "Grid Trading"
    else:
        indicator_code = """
        # Custom indicators — adapt as needed
        dataframe['ema_fast'] = ta.EMA(dataframe, timeperiod=9)
        dataframe['ema_slow'] = ta.EMA(dataframe, timeperiod=21)"""
        buy_cond  = "dataframe['ema_fast'] > dataframe['ema_slow']"
        sell_cond = "dataframe['ema_fast'] < dataframe['ema_slow']"
        strat_type = "Custom"

    class_name = "".join(w.capitalize() for w in name.replace("-","_").split()) + "FT"

    freqtrade_code = f'''"""
{name} — Freqtrade Strategy
Auto-exported from CoinDCX Algo Platform
Strategy type: {strat_type}
Original symbol: {symbol} | Timeframe: {timeframe}

Usage:
    1. Place this file in: ~/freqtrade/user_data/strategies/
    2. Run: freqtrade trade --strategy {class_name} --config config.json
    3. Or backtest: freqtrade backtesting --strategy {class_name} --timerange 20230101-
"""
import talib.abstract as ta
import freqtrade.vendor.qtpylib.indicators as qtpylib
from freqtrade.strategy import IStrategy, IntParameter, DecimalParameter
from pandas import DataFrame


class {class_name}(IStrategy):
    """
    {name}
    Exported from CoinDCX Algo Platform (CoinDCX brand algo engine)
    Strategy type: {strat_type}
    """

    INTERFACE_VERSION = 3
    timeframe         = '{timeframe}'

    # ROI table — 3% profit exits after various hold times
    minimal_roi = {{
        "0":   0.05,
        "60":  0.03,
        "120": 0.02,
        "360": 0.01,
    }}

    stoploss     = -0.05   # 5% stop loss
    trailing_stop = True
    trailing_stop_positive = 0.02
    trailing_stop_positive_offset = 0.04

    # Hyperopt parameters
    buy_rsi_threshold  = IntParameter(low=20, high=40, default=30, space="buy",  optimize=True)
    sell_rsi_threshold = IntParameter(low=60, high=80, default=70, space="sell", optimize=True)

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        {indicator_code}
        # Volume and trend filters
        dataframe['volume_mean'] = dataframe['volume'].rolling(20).mean()
        dataframe['adx']         = ta.ADX(dataframe, timeperiod=14)
        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe.loc[
            (
                ({buy_cond}) &
                (dataframe['volume'] > 0) &
                (dataframe['volume'] > dataframe['volume_mean'] * 0.5)
            ),
            'enter_long'
        ] = 1
        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe.loc[
            (
                ({sell_cond}) &
                (dataframe['volume'] > 0)
            ),
            'exit_long'
        ] = 1
        return dataframe
'''

    return {
        "strategy_id":   strategy_id,
        "strategy_name": name,
        "strategy_type": strat_type,
        "freqtrade_class": class_name,
        "timeframe":     timeframe,
        "code":          freqtrade_code,
        "filename":      f"{class_name}.py",
        "instructions": [
            f"Save as: ~/freqtrade/user_data/strategies/{class_name}.py",
            f"Run: freqtrade backtesting --strategy {class_name} --timerange 20230101-20240101",
            f"Live: freqtrade trade --strategy {class_name} --config config.json",
            "Freqtrade docs: https://www.freqtrade.io/en/stable/strategy-customization/",
        ],
    }


# ── Signals ──────────────────────────────────────

@route("GET", "/api/v1/signals")
def list_signals(req, params):
    user = _require_auth(req)
    p = get_platform()
    return {"signals": p.db.list_signals(user["user_id"], limit=50)}

# ── Demo Seeder ──────────────────────────────────

@route("POST", "/api/v1/demo/seed")
def seed_demo(req, params):
    """Seed demo strategies, backtests, and wallet data for this user."""
    user = _require_auth(req)
    p = get_platform()
    result = p.db.seed_demo_data(user["user_id"])
    return result

# ── Strategy Code Validate (standalone, no strategy_id needed) ──────────────

@route("POST", "/api/v1/validate")
def validate_code_standalone(req, params):
    body = req.get("body", {})
    code = body.get("code", "")
    from engine.execution.validator import StrategyValidator
    result = StrategyValidator().validate(code)
    return {
        "is_valid": result.is_valid,
        "errors": [{"code": i.code, "message": i.message, "line": i.line} for i in result.errors],
        "warnings": [{"code": i.code, "message": i.message} for i in result.warnings],
        "complexity_score": result.complexity_score,
        "detected_class": result.strategy_class_name,
        "detected_symbols": result.detected_symbols,
    }

# ── Kill Switch ───────────────────────────────────

@route("POST", "/api/v1/risk/kill-switch")
def kill_switch(req, params):
    user = _require_auth(req)
    body = req.get("body", {})
    engage = body.get("engage", True)
    _engines = _get_engines()
    uid = user["user_id"]
    if uid in _engines:
        if engage:
            _engines[uid].engage_kill_switch()
        else:
            _engines[uid].release_kill_switch()
    get_platform().bus.publish("risk.kill_switch", {"user_id": uid, "engaged": engage})
    return {"kill_switch": "engaged" if engage else "released", "user_id": uid}

# ── WebSocket info endpoint ───────────────────────

@route("GET", "/api/v1/ws/info")
def ws_info(req, params):
    from coindcx_platform.ws_server import get_ws_server
    ws = get_ws_server()
    return {
        "ws_url": "ws://127.0.0.1:8001",
        "protocol": "websocket",
        "connected_clients": ws.client_count(),
        "description": "Connect and receive JSON price updates every 1.5s",
        "message_types": ["snapshot", "prices", "signal", "subscribed"],
    }

@route("GET", "/api/v1/market/prices")
def get_all_prices(req, params):
    """Live prices from CoinDCX public ticker (no API key needed)."""
    _require_auth(req)
    from execution_engine.engine import get_all_live_prices
    prices_raw = get_all_live_prices()
    # Reshape: {SYM: {price, change_24h}} → {SYM: {price_inr, price_usd, change_24h}}
    INR_USD = 84.2
    prices = {}
    for sym, d in prices_raw.items():
        prices[sym] = {
            "price_inr":  d["price"],
            "price_usd":  round(d["price"] / INR_USD, 6),
            "price":      d["price"],
            "change_24h": d["change_24h"],
        }
    return {"prices": prices, "timestamp_ms": int(time.time() * 1000), "source": "coindcx_live"}

# ── Execution engine registry ─────────────────────

_user_engines: dict = {}

def _get_engines() -> dict:
    return _user_engines


# ─────────────────────────────────────────────────
# Auth helper
# ─────────────────────────────────────────────────

def _require_auth(req: dict) -> dict:
    token = req.get("headers", {}).get("authorization", "").replace("Bearer ", "").strip()
    if not token:
        raise PermissionError("Authorization header required")
    payload = verify_token(token)
    if not payload:
        raise PermissionError("Invalid or expired token")
    p = get_platform()
    user = p.db.get_user(payload["sub"])
    if not user:
        raise PermissionError("User not found")
    return user


# ─────────────────────────────────────────────────
# HTTP Server
# ─────────────────────────────────────────────────

class PlatformHandler(BaseHTTPRequestHandler):
    def log_message(self, format, *args):
        pass  # Suppress default logging

    def _send_json(self, data: Any, status: int = 200) -> None:
        body = json.dumps(data, default=str).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Headers", "Authorization, Content-Type")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS")
        self.end_headers()
        self.wfile.write(body)

    def do_OPTIONS(self):
        self._send_json({}, 200)

    def _handle(self, method: str) -> None:
        parsed = urlparse(self.path)
        path = parsed.path
        query = parse_qs(parsed.query)

        headers = {k.lower(): v for k, v in self.headers.items()}
        body = {}
        if method in ("POST", "PUT", "PATCH"):
            length = int(self.headers.get("Content-Length", 0))
            if length:
                try:
                    body = json.loads(self.rfile.read(length))
                except Exception:
                    body = {}

        req = {"headers": headers, "body": body, "query": query, "path": path}
        handler, params = router.match(method, path)
        if not handler:
            self._send_json({"error": f"Not found: {method} {path}"}, 404)
            return

        try:
            result = handler(req, params)
            self._send_json(result, 200)
        except PermissionError as e:
            self._send_json({"error": str(e)}, 403)
        except KeyError as e:
            self._send_json({"error": str(e)}, 404)
        except ValueError as e:
            self._send_json({"error": str(e)}, 400)
        except Exception as e:
            self._send_json({"error": str(e), "trace": traceback.format_exc()}, 500)

    def do_GET(self): self._handle("GET")
    def do_POST(self): self._handle("POST")
    def do_PUT(self): self._handle("PUT")
    def do_DELETE(self): self._handle("DELETE")


# ═══════════════════════════════════════════════════════════════════════════
# EXTENDED ROUTES — Added by upgrade (Step 2–14)
# These EXTEND the existing router without replacing anything above.
# ═══════════════════════════════════════════════════════════════════════════

# ── Market Data (Candles + Indicators) ──────────────────────────────────────

@route("GET", "/api/v1/market/candles/{symbol}/{resolution}")
def get_candles_with_indicators(req, params):
    """Return candle OHLCV + computed indicators for a symbol/resolution."""
    _require_auth(req)
    from market_data.binance_stream import get_market_data_service
    mds    = get_market_data_service()
    symbol = params["symbol"].upper()
    res    = params["resolution"]
    limit  = int(req.get("query", {}).get("limit", ["200"])[0])
    candles    = mds.get_candles(symbol, res, limit)
    indicators = mds.get_indicators(symbol, res)
    return {
        "symbol": symbol,
        "resolution": res,
        "count": len(candles),
        "candles": candles,
        "indicators": indicators,
        "source": "binance" if mds._binance and mds._binance.connected else "simulator",
    }

@route("GET", "/api/v1/market/indicators/{symbol}/{resolution}")
def get_live_indicators(req, params):
    """Return only the latest indicator values (lightweight endpoint)."""
    _require_auth(req)
    from market_data.binance_stream import get_market_data_service
    mds  = get_market_data_service()
    sym  = params["symbol"].upper()
    res  = params["resolution"]
    ind  = mds.get_indicators(sym, res)
    price = mds.current_price(sym)
    return {
        "symbol": sym,
        "resolution": res,
        "price": round(price, 2),
        "indicators": ind,
        "timestamp_ms": int(time.time() * 1000),
    }

@route("GET", "/api/v1/market/stream-info")
def stream_info(req, params):
    """Returns WS connection info + data source status."""
    _require_auth(req)
    from market_data.binance_stream import get_market_data_service
    mds = get_market_data_service()
    return {
        "ws_url": "ws://127.0.0.1:8001",
        "data_source": "binance" if (mds._binance and mds._binance.connected) else "simulator",
        "symbols_tracked": list(mds.BASE_PRICES_INR.keys()),
        "resolutions": mds.SUPPORTED_RESOLUTIONS,
        "message_types": ["candle", "signal", "prices", "snapshot"],
    }

# ── Enhanced Backtest Results ────────────────────────────────────────────────

@route("GET", "/api/v1/backtests/{job_id}/rich")
def get_rich_backtest(req, params):
    """Return backtest with full rich metrics (monthly returns, drawdown series, markers)."""
    user = _require_auth(req)
    p    = get_platform()
    job  = p.db.get_backtest_job(params["job_id"])
    if not job:
        raise KeyError("Backtest job not found")
    if job["user_id"] != user["user_id"]:
        raise PermissionError("Access denied")

    result = job.get("result", {})
    if not result:
        return {**job, "rich_metrics": None}

    # Compute rich metrics from existing result
    from backtesting.metrics_engine import MetricsCalculator, RichMetrics
    equity_raw  = result.get("equity_curve", [])
    trades_raw  = result.get("trades", [])
    metrics_raw = result.get("metrics", {})

    # Build equity curve with real timestamps if missing
    if equity_raw and not isinstance(equity_raw[0][0], int):
        now = int(time.time() * 1000)
        equity_raw = [[now - (len(equity_raw)-i)*3600000, v] for i, (_, v) in enumerate(equity_raw)]

    rich = MetricsCalculator.compute(
        equity_curve    = [(t, v) for t, v in equity_raw],
        trades          = trades_raw,
        initial_capital = float(job.get("initial_capital", 100000)),
        price_series    = [],
    )

    return {
        **job,
        "rich_metrics": rich.to_dict(),
    }

@route("GET", "/api/v1/demo/prebuilt-results")
def get_prebuilt_results(req, params):
    """Return pre-seeded demo backtest results for all 5 strategies (no login needed)."""
    from backtesting.metrics_engine import DemoResultsGenerator
    return DemoResultsGenerator.generate_all_demos()

# ── Signal Pipeline ──────────────────────────────────────────────────────────

@route("POST", "/api/v1/signals/manual")
def post_manual_signal(req, params):
    """
    Submit a manual trading signal.
    Signal format: {strategy_id, symbol, action, timestamp_ms}
    Optionally auto-execute if deployment exists.
    """
    user = _require_auth(req)
    body = req.get("body", {})
    symbol      = body.get("symbol", "BTC").upper().replace("/INR","").replace("USDT","")
    action      = body.get("action", "BUY").upper()
    strategy_id = body.get("strategy_id", "manual")
    qty         = float(body.get("quantity", 0.001))
    auto_exec   = body.get("auto_execute", False)
    mode        = body.get("mode", "paper")

    signal = {
        "strategy_id": strategy_id,
        "symbol":      symbol,
        "action":      action,
        "timestamp_ms": int(time.time() * 1000),
        "price":       body.get("price"),
        "auto_executed": False,
        "trade_result": None,
    }

    p = get_platform()
    p.db.log_signal(strategy_id, user["user_id"], symbol, action,
                    float(body.get("price", 0) or 0))
    p.bus.publish("signal.generated", {
        "user_id": user["user_id"], **signal
    })

    # Auto-execute if requested
    if auto_exec:
        from execution_engine.engine import ExecutionEngine
        _engines = _get_engines()
        uid = user["user_id"]
        if uid not in _engines:
            wallet = p.db.get_or_create_wallet(uid)
            _engines[uid] = ExecutionEngine(mode=mode, initial_capital=wallet["balance_inr"])
        eng = _engines[uid]
        if action == "BUY":
            result = eng.place_market_buy(symbol, qty)
        else:
            result = eng.place_market_sell(symbol, qty)
        if result.success:
            p.db.log_trade(
                user_id=uid, symbol=symbol, side=action,
                quantity=result.quantity, fill_price=result.fill_price,
                fee=result.fee, net_pnl=result.net_pnl, mode=mode,
                strategy_name=strategy_id,
            )
            ws = eng.wallet
            p.db.update_wallet(uid, ws.balance_inr, ws.pnl_realized, ws.positions)
        signal["auto_executed"] = result.success
        signal["trade_result"]  = {
            "trade_id":   result.trade_id,
            "fill_price": result.fill_price,
            "quantity":   result.quantity,
            "fee":        result.fee,
            "net_pnl":    result.net_pnl,
            "success":    result.success,
            "error":      result.error,
        }

    return signal

# ── Risk Management ──────────────────────────────────────────────────────────

@route("GET", "/api/v1/risk/config")
def get_risk_config(req, params):
    user = _require_auth(req)
    uid  = user["user_id"]
    _engines = _get_engines()
    if uid in _engines:
        eng = _engines[uid]
        return {
            "max_position_pct":  eng.risk.max_position_pct,
            "max_daily_trades":  eng.risk.max_daily_trades,
            "stop_loss_pct":     eng.risk.stop_loss_pct,
            "kill_switch_active": eng.risk._kill_switch,
            "daily_trade_count": eng.risk._daily_trades.get(time.strftime("%Y-%m-%d"), 0),
        }
    return {"max_position_pct": 5.0, "max_daily_trades": 50, "stop_loss_pct": 2.0,
            "kill_switch_active": False, "daily_trade_count": 0}

@route("PUT", "/api/v1/risk/config")
def update_risk_config(req, params):
    user = _require_auth(req)
    body = req.get("body", {})
    uid  = user["user_id"]
    _engines = _get_engines()
    if uid not in _engines:
        wallet = get_platform().db.get_or_create_wallet(uid)
        _engines[uid] = __import__("execution_engine.engine", fromlist=["ExecutionEngine"]).ExecutionEngine(
            initial_capital=wallet["balance_inr"])
    eng = _engines[uid]
    if "max_position_pct" in body:
        eng.risk.max_position_pct = float(body["max_position_pct"])
    if "max_daily_trades" in body:
        eng.risk.max_daily_trades = int(body["max_daily_trades"])
    if "stop_loss_pct" in body:
        eng.risk.stop_loss_pct = float(body["stop_loss_pct"])
    return {"updated": True, "config": {
        "max_position_pct": eng.risk.max_position_pct,
        "max_daily_trades": eng.risk.max_daily_trades,
        "stop_loss_pct":    eng.risk.stop_loss_pct,
    }}

# ── Execution Mode ────────────────────────────────────────────────────────────

@route("POST", "/api/v1/execution/mode")
def set_execution_mode(req, params):
    """Switch between paper and live mode."""
    user = _require_auth(req)
    body = req.get("body", {})
    mode = body.get("mode", "paper")
    if mode not in ("paper", "live", "safe"):
        raise ValueError("mode must be 'paper', 'live', or 'safe'")
    uid = user["user_id"]
    _engines = _get_engines()
    if uid not in _engines:
        wallet = get_platform().db.get_or_create_wallet(uid)
        _engines[uid] = __import__("execution_engine.engine", fromlist=["ExecutionEngine"]).ExecutionEngine(
            initial_capital=wallet["balance_inr"])
    _engines[uid].set_mode(mode)
    get_platform().bus.publish("execution.mode.changed", {"user_id": uid, "mode": mode})
    warning = ""
    if mode == "live":
        warning = ("⚠️  LIVE MODE ACTIVE — Real orders will be placed on CoinDCX. "
                   "Ensure COINDCX_API_KEY and COINDCX_SECRET_KEY are set.")
    return {"mode": mode, "warning": warning}

@route("GET", "/api/v1/execution/mode")
def get_execution_mode(req, params):
    user = _require_auth(req)
    uid  = user["user_id"]
    _engines = _get_engines()
    if uid in _engines:
        return {"mode": _engines[uid].mode.value}
    return {"mode": "paper"}

# ── Paper Wallet Extended ────────────────────────────────────────────────────

@route("GET", "/api/v1/wallet/full")
def get_wallet_full(req, params):
    """Extended wallet with P&L breakdown, positions, recent trades, equity curve."""
    user   = _require_auth(req)
    uid    = user["user_id"]
    p      = get_platform()
    wallet = p.db.get_or_create_wallet(uid)
    trades = p.db.list_trades(uid, limit=100)

    _engines = _get_engines()
    engine_wallet = _engines[uid].wallet.to_dict() if uid in _engines else {}

    return {
        "wallet": {**wallet, **engine_wallet},
        "recent_trades": trades[:20],
        "trade_count": len(trades),
        "mode": _engines[uid].mode.value if uid in _engines else "paper",
    }

@route("POST", "/api/v1/wallet/reset")
def reset_wallet(req, params):
    """Reset paper wallet to initial balance (demo use)."""
    user = _require_auth(req)
    uid  = user["user_id"]
    body = req.get("body", {})
    initial = float(body.get("initial_balance", 1_000_000.0))
    p = get_platform()
    p.db.update_wallet(uid, initial, 0.0, {})
    _engines = _get_engines()
    if uid in _engines:
        from execution_engine.engine import ExecutionEngine
        _engines[uid] = ExecutionEngine(mode="paper", initial_capital=initial)
    p.bus.publish("wallet.reset", {"user_id": uid, "initial_balance": initial})
    return {"reset": True, "balance_inr": initial}

# ── Strategy Signal Feed ─────────────────────────────────────────────────────

@route("GET", "/api/v1/market/latest-signals")
def latest_signals(req, params):
    """Return latest auto-generated signals from Market Data Service."""
    _require_auth(req)
    from market_data.binance_stream import get_market_data_service
    # MDS generates signals internally; return recent ones from event bus
    p = get_platform()
    events = p.bus.recent_events("signal.generated", n=20)
    return {
        "signals": [e["data"] for e in reversed(events)],
        "count": len(events),
    }

# ── Platform Health Extended ─────────────────────────────────────────────────

@route("GET", "/api/v1/status/full")
def status_full(req, params):
    """Extended status including MDS, WS, execution engine states."""
    _require_auth(req)
    p = get_platform()

    # WS server
    try:
        from coindcx_platform.ws_server import get_ws_server
        ws = get_ws_server()
        ws_info = {"running": True, "clients": ws.client_count(), "port": 8001}
    except Exception:
        ws_info = {"running": False}

    # Market Data Service
    try:
        from market_data.binance_stream import get_market_data_service, _mds_instance
        mds_info = {
            "running": _mds_instance is not None,
            "binance_connected": bool(_mds_instance and _mds_instance._binance and _mds_instance._binance.connected),
            "mode": "binance" if (_mds_instance and _mds_instance._binance and _mds_instance._binance.connected) else "simulator",
        } if _mds_instance else {"running": False}
    except Exception:
        mds_info = {"running": False}

    return {
        "platform": "CoinDCX Algo",
        "version": "2.0.0",
        "uptime_s": round(p.uptime(), 1),
        "websocket": ws_info,
        "market_data": mds_info,
        "event_bus": p.bus.stats(),
        "db": {"type": "sqlite", "status": "ok"},
    }


def run_server(host: str = "127.0.0.1", port: int = 8000, ws_port: int = 8001) -> HTTPServer:
    get_platform()  # Initialize
    server = HTTPServer((host, port), PlatformHandler)
    thread = Thread(target=server.serve_forever, daemon=True)
    thread.start()
    print(f"[API] Platform server running at http://{host}:{port}")
    # Start WebSocket price stream server
    try:
        from coindcx_platform.ws_server import get_ws_server
        ws = get_ws_server(host=host, port=ws_port)
        ws.start()
    except Exception as e:
        print(f"[WS] Warning: could not start WebSocket server: {e}")

    # Start Market Data Service (Binance or GBM simulator)
    try:
        from market_data.binance_stream import MarketDataService
        import market_data.binance_stream as _mds_mod

        def _on_enriched_candle(enriched):
            try:
                from coindcx_platform.ws_server import get_ws_server
                ws_srv = get_ws_server()
                if hasattr(ws_srv, 'broadcast_extra'):
                    ws_srv.broadcast_extra(enriched)
            except Exception:
                pass

        def _on_signal(sig):
            get_platform().bus.publish("signal.generated", sig)

        mds = MarketDataService(on_candle=_on_enriched_candle, on_signal=_on_signal)
        mds.start(use_binance=True,
                  symbols=["BTCUSDT", "ETHUSDT", "BNBUSDT", "SOLUSDT"],
                  resolution="1m")
        _mds_mod._mds_instance = mds
        print(f"[MDS] Market Data Service started")
    except Exception as e:
        print(f"[MDS] Warning: {e}")

    return server


if __name__ == "__main__":
    import signal
    server = run_server(port=int(os.environ.get("PORT", 8000)))
    def _shutdown(sig, frame):
        print("\n[API] Shutting down...")
        server.shutdown()
        sys.exit(0)
    signal.signal(signal.SIGINT, _shutdown)
    signal.signal(signal.SIGTERM, _shutdown)
    print("[API] Press Ctrl+C to stop")
    Thread.join(threading.current_thread())  # Block main thread
