"""
CoinDCX Algo Platform — Risk Engine

All risk checks are synchronous and run BEFORE any order is forwarded
to the OMS or exchange. If any check fails, the order is REJECTED
with a descriptive reason — it never reaches the exchange.

Risk layers:
  1. Order-level checks (quantity, price, order type)
  2. Position-level checks (max position size, concentration)
  3. Strategy-level checks (drawdown, daily loss, max open orders)
  4. Portfolio-level checks (total exposure, margin usage)
  5. Platform-level checks (kill switch, circuit breakers)
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from decimal import Decimal
from typing import Optional
from enum import Enum

from sdk.models import (
    OrderRequest, Portfolio, OrderSide, MarketType
)

logger = logging.getLogger(__name__)


class RiskViolation(str, Enum):
    ORDER_TOO_SMALL = "order_too_small"
    ORDER_TOO_LARGE = "order_too_large"
    POSITION_LIMIT_EXCEEDED = "position_limit_exceeded"
    MAX_DRAWDOWN_EXCEEDED = "max_drawdown_exceeded"
    DAILY_LOSS_LIMIT_EXCEEDED = "daily_loss_limit_exceeded"
    MAX_OPEN_ORDERS_EXCEEDED = "max_open_orders_exceeded"
    INSUFFICIENT_BALANCE = "insufficient_balance"
    LEVERAGE_LIMIT_EXCEEDED = "leverage_limit_exceeded"
    KILL_SWITCH_ACTIVE = "kill_switch_active"
    SYMBOL_NOT_ALLOWED = "symbol_not_allowed"
    STRATEGY_SUSPENDED = "strategy_suspended"
    CONCENTRATION_LIMIT_EXCEEDED = "concentration_limit_exceeded"


@dataclass
class RiskCheckResult:
    approved: bool
    violation: Optional[RiskViolation] = None
    reason: str = ""
    suggested_quantity: Optional[Decimal] = None  # If we can suggest a safer quantity


@dataclass
class StrategyRiskConfig:
    """
    Per-strategy risk parameters set by the user at deployment time.
    Stored in PostgreSQL and loaded when strategy starts.
    """
    strategy_id: str

    # Position limits
    max_position_size_usd: Decimal = Decimal("10000")
    max_position_pct_of_equity: Decimal = Decimal("50")  # 50% of equity
    max_open_orders: int = 20
    allowed_symbols: list[str] = field(default_factory=list)  # Empty = all allowed

    # Loss limits
    max_drawdown_pct: Decimal = Decimal("20")       # Stop if DD > 20%
    max_daily_loss_usd: Decimal = Decimal("500")
    max_daily_loss_pct: Decimal = Decimal("10")     # Stop if daily loss > 10%

    # Leverage
    max_leverage: Decimal = Decimal("10")           # Futures only

    # Concentration
    max_single_symbol_pct: Decimal = Decimal("30") # Max % of portfolio in one symbol

    # Order limits
    min_order_size_usd: Decimal = Decimal("10")
    max_order_size_usd: Decimal = Decimal("5000")

    # Kill switch
    kill_switch_active: bool = False

    # Auto-stop triggers
    auto_stop_on_drawdown: bool = True
    auto_stop_on_daily_loss: bool = True


@dataclass
class StrategyRiskState:
    """
    Mutable runtime state tracked per strategy session.
    Persisted in Redis for fast access and crash recovery.
    """
    strategy_id: str
    session_start_equity: Decimal = Decimal("0")
    session_high_equity: Decimal = Decimal("0")
    daily_realized_pnl: Decimal = Decimal("0")
    daily_start_equity: Decimal = Decimal("0")
    open_order_count: int = 0
    is_suspended: bool = False
    suspension_reason: str = ""

    @property
    def current_drawdown_pct(self) -> Decimal:
        if self.session_high_equity == 0:
            return Decimal("0")
        return ((self.session_high_equity - self.session_start_equity) /
                self.session_high_equity * 100)

    @property
    def daily_loss_pct(self) -> Decimal:
        if self.daily_start_equity == 0:
            return Decimal("0")
        return (self.daily_realized_pnl / self.daily_start_equity * 100).copy_abs()


class RiskEngine:
    """
    Stateless risk check executor.
    All checks run synchronously in < 1ms.
    Strategy state is passed in — no I/O inside checks.
    """

    def __init__(self):
        self._platform_kill_switch: bool = False
        self._suspended_strategies: set[str] = set()

    def check_order(
        self,
        request: OrderRequest,
        portfolio: Portfolio,
        config: StrategyRiskConfig,
        state: StrategyRiskState,
        current_price: Decimal,
        open_order_count: int,
    ) -> RiskCheckResult:
        """
        Run all risk checks on an order request.
        Returns immediately on first violation (fail-fast).
        """

        # Layer 0 — Platform kill switch (overrides everything)
        if self._platform_kill_switch:
            return RiskCheckResult(
                approved=False,
                violation=RiskViolation.KILL_SWITCH_ACTIVE,
                reason="Platform kill switch is active",
            )

        # Layer 0b — Strategy kill switch
        if config.kill_switch_active:
            return RiskCheckResult(
                approved=False,
                violation=RiskViolation.KILL_SWITCH_ACTIVE,
                reason="Strategy kill switch is active",
            )

        # Layer 0c — Strategy suspended
        if state.is_suspended:
            return RiskCheckResult(
                approved=False,
                violation=RiskViolation.STRATEGY_SUSPENDED,
                reason=f"Strategy suspended: {state.suspension_reason}",
            )

        # Layer 1 — Symbol allowlist
        if config.allowed_symbols and request.symbol not in config.allowed_symbols:
            return RiskCheckResult(
                approved=False,
                violation=RiskViolation.SYMBOL_NOT_ALLOWED,
                reason=f"Symbol {request.symbol} not in allowlist",
            )

        # Layer 2 — Order size checks
        order_value_usd = request.quantity * current_price

        if order_value_usd < config.min_order_size_usd:
            return RiskCheckResult(
                approved=False,
                violation=RiskViolation.ORDER_TOO_SMALL,
                reason=f"Order value ${order_value_usd:.2f} below minimum ${config.min_order_size_usd}",
            )

        if order_value_usd > config.max_order_size_usd:
            return RiskCheckResult(
                approved=False,
                violation=RiskViolation.ORDER_TOO_LARGE,
                reason=f"Order value ${order_value_usd:.2f} exceeds maximum ${config.max_order_size_usd}",
                suggested_quantity=config.max_order_size_usd / current_price,
            )

        # Layer 3 — Balance check
        if request.side == OrderSide.BUY:
            required_balance = order_value_usd
            available_balance = portfolio.get_balance("USDT")
            if available_balance < required_balance:
                return RiskCheckResult(
                    approved=False,
                    violation=RiskViolation.INSUFFICIENT_BALANCE,
                    reason=f"Insufficient balance: need ${required_balance:.2f}, have ${available_balance:.2f}",
                    suggested_quantity=available_balance / current_price * Decimal("0.99"),
                )

        # Layer 4 — Open orders limit
        if open_order_count >= config.max_open_orders:
            return RiskCheckResult(
                approved=False,
                violation=RiskViolation.MAX_OPEN_ORDERS_EXCEEDED,
                reason=f"Open orders {open_order_count} >= limit {config.max_open_orders}",
            )

        # Layer 5 — Position size check
        existing_position = portfolio.get_position(request.symbol)
        existing_qty = existing_position.quantity if existing_position else Decimal("0")

        if request.side == OrderSide.BUY:
            projected_qty = existing_qty + request.quantity
        else:
            projected_qty = existing_qty - request.quantity

        projected_value = abs(projected_qty) * current_price
        if projected_value > config.max_position_size_usd:
            return RiskCheckResult(
                approved=False,
                violation=RiskViolation.POSITION_LIMIT_EXCEEDED,
                reason=f"Projected position ${projected_value:.2f} exceeds limit ${config.max_position_size_usd}",
            )

        # Layer 5b — Concentration limit
        equity = portfolio.total_equity
        if equity > 0:
            concentration_pct = (projected_value / equity) * 100
            if concentration_pct > config.max_single_symbol_pct:
                return RiskCheckResult(
                    approved=False,
                    violation=RiskViolation.CONCENTRATION_LIMIT_EXCEEDED,
                    reason=f"Concentration {concentration_pct:.1f}% exceeds {config.max_single_symbol_pct}%",
                )

        # Layer 6 — Drawdown check
        current_drawdown = self._compute_drawdown(portfolio, state)
        if current_drawdown > config.max_drawdown_pct:
            if config.auto_stop_on_drawdown:
                state.is_suspended = True
                state.suspension_reason = f"Max drawdown {config.max_drawdown_pct}% exceeded"
            return RiskCheckResult(
                approved=False,
                violation=RiskViolation.MAX_DRAWDOWN_EXCEEDED,
                reason=f"Drawdown {current_drawdown:.1f}% exceeds limit {config.max_drawdown_pct}%",
            )

        # Layer 7 — Daily loss check
        daily_loss_pct = state.daily_loss_pct
        if daily_loss_pct > config.max_daily_loss_pct:
            if config.auto_stop_on_daily_loss:
                state.is_suspended = True
                state.suspension_reason = f"Daily loss limit {config.max_daily_loss_pct}% exceeded"
            return RiskCheckResult(
                approved=False,
                violation=RiskViolation.DAILY_LOSS_LIMIT_EXCEEDED,
                reason=f"Daily loss {daily_loss_pct:.1f}% exceeds limit {config.max_daily_loss_pct}%",
            )

        # Layer 8 — Leverage check (futures only)
        if request.market_type == MarketType.FUTURES:
            leverage_check = self._check_leverage(request, portfolio, config, current_price)
            if not leverage_check.approved:
                return leverage_check

        # All checks passed
        logger.debug(
            f"Risk approved: {request.side.value} {request.quantity} {request.symbol} "
            f"@ ~${current_price:.2f} (strategy={request.strategy_id})"
        )
        return RiskCheckResult(approved=True)

    def activate_platform_kill_switch(self) -> None:
        """Emergency: halt ALL strategies on the platform immediately."""
        self._platform_kill_switch = True
        logger.critical("PLATFORM KILL SWITCH ACTIVATED — all strategies halted")

    def deactivate_platform_kill_switch(self) -> None:
        self._platform_kill_switch = False
        logger.info("Platform kill switch deactivated")

    def suspend_strategy(self, strategy_id: str, reason: str) -> None:
        self._suspended_strategies.add(strategy_id)
        logger.warning(f"Strategy {strategy_id} suspended: {reason}")

    def resume_strategy(self, strategy_id: str) -> None:
        self._suspended_strategies.discard(strategy_id)
        logger.info(f"Strategy {strategy_id} resumed")

    def _compute_drawdown(
        self, portfolio: Portfolio, state: StrategyRiskState
    ) -> Decimal:
        if state.session_high_equity == 0:
            return Decimal("0")
        current = portfolio.total_equity
        peak = state.session_high_equity
        if current >= peak:
            state.session_high_equity = current
            return Decimal("0")
        return ((peak - current) / peak) * 100

    def _check_leverage(
        self,
        request: OrderRequest,
        portfolio: Portfolio,
        config: StrategyRiskConfig,
        current_price: Decimal,
    ) -> RiskCheckResult:
        equity = portfolio.total_equity
        if equity <= 0:
            return RiskCheckResult(
                approved=False,
                violation=RiskViolation.INSUFFICIENT_BALANCE,
                reason="Zero equity for leverage calculation",
            )
        order_notional = request.quantity * current_price
        effective_leverage = order_notional / equity
        if effective_leverage > config.max_leverage:
            return RiskCheckResult(
                approved=False,
                violation=RiskViolation.LEVERAGE_LIMIT_EXCEEDED,
                reason=f"Effective leverage {effective_leverage:.1f}x exceeds {config.max_leverage}x",
            )
        return RiskCheckResult(approved=True)


# Singleton risk engine instance — shared across all strategy runners
_risk_engine = RiskEngine()


def get_risk_engine() -> RiskEngine:
    return _risk_engine
