"""
CoinDCX Algo Platform — Analytics Engine

Computes and serves all performance analytics for strategies.

Two pipelines:
  1. Real-time: updates equity curve / PnL every bar close → TimescaleDB
  2. Batch: computes full metric suite on-demand or scheduled → ClickHouse

Metrics computed:
  - Returns: total, daily, monthly, annualized
  - Risk-adjusted: Sharpe, Sortino, Calmar, Omega
  - Drawdown: max, current, average, duration
  - Trade stats: win rate, profit factor, avg win/loss, expectancy
  - Factor exposure: market beta, volatility, momentum, liquidity
  - Costs: total fees, total slippage, cost-drag on returns
  - Comparison: vs BTC buy-hold, vs ETH buy-hold, vs USDT staking
"""

from __future__ import annotations

import asyncio
import logging
import math
import time
from dataclasses import dataclass, field
from decimal import Decimal
from typing import Optional

try:
    import numpy as np
    _HAS_NUMPY = True
except ImportError:
    _HAS_NUMPY = False
    import math as _math

# ---------------------------------------------------------------------------
# Pure-stdlib math helpers (used when numpy is not installed)
# ---------------------------------------------------------------------------
import math as _math

def _mean(xs):
    return sum(xs) / len(xs) if xs else 0.0

def _std(xs):
    if len(xs) < 2:
        return 0.0
    m = _mean(xs)
    return _math.sqrt(sum((x - m) ** 2 for x in xs) / len(xs))

def _percentile(xs, pct):
    if not xs:
        return 0.0
    s = sorted(xs)
    idx = (pct / 100) * (len(s) - 1)
    lo, hi = int(idx), min(int(idx) + 1, len(s) - 1)
    return s[lo] + (s[hi] - s[lo]) * (idx - lo)

def _cov(xs, ys):
    if len(xs) != len(ys) or len(xs) < 2:
        return 0.0
    mx, my = _mean(xs), _mean(ys)
    return sum((x - mx) * (y - my) for x, y in zip(xs, ys)) / (len(xs) - 1)

def _var(xs):
    if len(xs) < 2:
        return 0.0
    m = _mean(xs)
    return sum((x - m) ** 2 for x in xs) / (len(xs) - 1)



logger = logging.getLogger("analytics.engine")


# ---------------------------------------------------------------------------
# Real-time equity tracker (per strategy session)
# ---------------------------------------------------------------------------

class RealTimeEquityTracker:
    """
    Updates equity curve every bar close.
    Writes to TimescaleDB for charting and drawdown monitoring.
    Triggers alerts if thresholds are crossed.
    """

    def __init__(
        self,
        strategy_id: str,
        initial_equity: Decimal,
        timescale_writer=None,
        alert_engine=None,
    ):
        self.strategy_id = strategy_id
        self._initial_equity = initial_equity
        self._peak_equity = initial_equity
        self._timescale = timescale_writer
        self._alerts = alert_engine

        # In-memory ring buffer for recent equity points (last 500 bars)
        self._equity_points: list[tuple[int, Decimal]] = []  # (timestamp_ms, equity)
        self._drawdown_points: list[tuple[int, Decimal]] = []

        # Alert state — prevent repeated alerts
        self._last_dd_alert_pct: Decimal = Decimal("0")
        self._max_dd_seen: Decimal = Decimal("0")

    def record_equity(self, timestamp_ms: int, equity: Decimal) -> None:
        """Called every bar close. O(1) operation."""
        self._equity_points.append((timestamp_ms, equity))
        if len(self._equity_points) > 500:
            self._equity_points.pop(0)

        # Update peak
        if equity > self._peak_equity:
            self._peak_equity = equity

        # Compute current drawdown
        current_dd = Decimal("0")
        if self._peak_equity > 0 and equity < self._peak_equity:
            current_dd = ((self._peak_equity - equity) / self._peak_equity) * 100

        self._drawdown_points.append((timestamp_ms, current_dd))
        if len(self._drawdown_points) > 500:
            self._drawdown_points.pop(0)

        if current_dd > self._max_dd_seen:
            self._max_dd_seen = current_dd

        # Schedule async DB write (non-blocking)
        asyncio.ensure_future(self._persist(timestamp_ms, equity, current_dd))

        # Check alert thresholds
        if self._alerts and current_dd >= 5 and current_dd > self._last_dd_alert_pct + 5:
            asyncio.ensure_future(self._alerts.send_drawdown_alert(
                strategy_id=self.strategy_id,
                drawdown_pct=float(current_dd),
            ))
            self._last_dd_alert_pct = current_dd

    async def _persist(self, timestamp_ms: int, equity: Decimal, drawdown: Decimal) -> None:
        if not self._timescale:
            return
        try:
            await self._timescale.write_equity_point(
                strategy_id=self.strategy_id,
                timestamp_ms=timestamp_ms,
                equity=float(equity),
                drawdown_pct=float(drawdown),
                peak_equity=float(self._peak_equity),
            )
        except Exception as e:
            logger.debug(f"Equity persist error: {e}")

    @property
    def current_drawdown_pct(self) -> Decimal:
        if not self._equity_points:
            return Decimal("0")
        _, latest_equity = self._equity_points[-1]
        if self._peak_equity == 0:
            return Decimal("0")
        return ((self._peak_equity - latest_equity) / self._peak_equity) * 100

    @property
    def total_return_pct(self) -> Decimal:
        if not self._equity_points or self._initial_equity == 0:
            return Decimal("0")
        _, latest = self._equity_points[-1]
        return ((latest - self._initial_equity) / self._initial_equity) * 100


# ---------------------------------------------------------------------------
# Full metrics suite
# ---------------------------------------------------------------------------

@dataclass
class FullMetrics:
    """Complete analytics output for a strategy over a period."""

    strategy_id: str
    period_label: str        # "7d", "30d", "90d", "1y", "all"
    computed_at_ms: int

    # Returns
    total_return_pct: float = 0.0
    annualized_return_pct: float = 0.0
    daily_returns: list[float] = field(default_factory=list)

    # Risk-adjusted ratios
    sharpe_ratio: float = 0.0
    sortino_ratio: float = 0.0
    calmar_ratio: float = 0.0
    omega_ratio: float = 0.0

    # Drawdown
    max_drawdown_pct: float = 0.0
    max_drawdown_duration_days: int = 0
    current_drawdown_pct: float = 0.0
    avg_drawdown_pct: float = 0.0
    recovery_factor: float = 0.0   # total return / max drawdown

    # Volatility
    daily_volatility_pct: float = 0.0
    annualized_volatility_pct: float = 0.0
    downside_deviation_pct: float = 0.0
    var_95_pct: float = 0.0     # Value at risk, 95% confidence
    cvar_95_pct: float = 0.0    # Conditional VaR (expected shortfall)

    # Trade statistics
    total_trades: int = 0
    winning_trades: int = 0
    losing_trades: int = 0
    win_rate_pct: float = 0.0
    profit_factor: float = 0.0
    expectancy_usd: float = 0.0  # (win_rate * avg_win) - (loss_rate * avg_loss)
    avg_win_usd: float = 0.0
    avg_loss_usd: float = 0.0
    largest_win_usd: float = 0.0
    largest_loss_usd: float = 0.0
    avg_hold_duration_hours: float = 0.0
    max_consecutive_wins: int = 0
    max_consecutive_losses: int = 0

    # Costs
    total_fees_usd: float = 0.0
    total_slippage_usd: float = 0.0
    cost_drag_pct: float = 0.0  # % of returns consumed by costs

    # Benchmark comparison
    btc_return_pct: float = 0.0    # BTC buy-and-hold return over same period
    eth_return_pct: float = 0.0
    alpha_vs_btc: float = 0.0      # strategy return - BTC return
    beta_vs_btc: float = 0.0       # correlation with BTC

    # Monthly breakdown
    monthly_returns: dict[str, float] = field(default_factory=dict)   # "YYYY-MM" → pct


class MetricsComputer:
    """
    Stateless computation engine for all performance metrics.
    Input: equity curve (list of timestamps + values), trade list.
    Output: FullMetrics dataclass.
    """

    RISK_FREE_ANNUAL = 0.05    # 5% annual risk-free rate
    RISK_FREE_DAILY = RISK_FREE_ANNUAL / 365

    def compute(
        self,
        strategy_id: str,
        period_label: str,
        equity_curve: list[tuple[int, float]],  # (timestamp_ms, equity)
        trades: list[dict],
        period_days: float,
        btc_prices: Optional[list[float]] = None,
    ) -> FullMetrics:
        """Compute full metrics suite."""
        if len(equity_curve) < 2:
            return FullMetrics(
                strategy_id=strategy_id,
                period_label=period_label,
                computed_at_ms=int(time.time() * 1000),
            )

        equities = [e for _, e in equity_curve]
        initial = equities[0]
        final = equities[-1]

        # Daily returns
        daily_returns = self._compute_daily_returns(equity_curve)

        # Returns
        total_return = (final - initial) / initial * 100 if initial > 0 else 0.0
        ann_return = (
            ((1 + total_return / 100) ** (365.0 / period_days) - 1) * 100
            if period_days > 0 else 0.0
        )

        # Volatility
        daily_vol = _std(daily_returns) * 100 if daily_returns else 0.0
        ann_vol = daily_vol * math.sqrt(252)  # 252 trading days

        # Downside deviation
        downside = [r for r in daily_returns if r < self.RISK_FREE_DAILY]
        down_dev = _std(downside) * 100 if downside else 0.0

        # Risk-adjusted
        sharpe = self._sharpe(daily_returns)
        sortino = self._sortino(daily_returns)

        # Drawdown analysis
        dd_series = self._compute_drawdown_series(equities)
        max_dd = max(dd_series) if dd_series else 0.0
        avg_dd = _mean([d for d in dd_series if d > 0]) if any(d > 0 for d in dd_series) else 0.0
        calmar = ann_return / max_dd if max_dd > 0 else 0.0
        recovery = total_return / max_dd if max_dd > 0 else 0.0
        max_dd_duration = self._max_drawdown_duration(dd_series, equity_curve)
        current_dd = dd_series[-1] if dd_series else 0.0

        # VaR and CVaR
        var_95 = self._var(daily_returns, 0.95)
        cvar_95 = self._cvar(daily_returns, 0.95)

        # Omega ratio
        omega = self._omega(daily_returns)

        # Trade stats
        trade_stats = self._compute_trade_stats(trades)

        # Beta vs BTC
        beta_btc = 0.0
        alpha_btc = 0.0
        btc_return = 0.0
        if btc_prices and len(btc_prices) > 1:
            btc_returns_list = [(btc_prices[i] - btc_prices[i-1]) / btc_prices[i-1]
                                for i in range(1, len(btc_prices))]
            btc_return = (btc_prices[-1] - btc_prices[0]) / btc_prices[0] * 100
            if len(daily_returns) >= len(btc_returns_list):
                strat_r = daily_returns[-len(btc_returns_list):]
                if _std(btc_returns_list) > 0:
                    cov = _cov(strat_r, btc_returns_list)
                    var_btc = _var(btc_returns_list)
                    beta_btc = cov / var_btc if var_btc > 0 else 0.0
                alpha_btc = ann_return - btc_return

        # Monthly returns
        monthly = self._monthly_returns(equity_curve)

        return FullMetrics(
            strategy_id=strategy_id,
            period_label=period_label,
            computed_at_ms=int(time.time() * 1000),
            total_return_pct=round(total_return, 4),
            annualized_return_pct=round(ann_return, 4),
            daily_returns=daily_returns,
            sharpe_ratio=round(sharpe, 4),
            sortino_ratio=round(sortino, 4),
            calmar_ratio=round(calmar, 4),
            omega_ratio=round(omega, 4),
            max_drawdown_pct=round(max_dd, 4),
            max_drawdown_duration_days=max_dd_duration,
            current_drawdown_pct=round(current_dd, 4),
            avg_drawdown_pct=round(avg_dd, 4),
            recovery_factor=round(recovery, 4),
            daily_volatility_pct=round(daily_vol, 4),
            annualized_volatility_pct=round(ann_vol, 4),
            downside_deviation_pct=round(down_dev, 4),
            var_95_pct=round(var_95, 4),
            cvar_95_pct=round(cvar_95, 4),
            **trade_stats,
            btc_return_pct=round(btc_return, 4),
            alpha_vs_btc=round(alpha_btc, 4),
            beta_vs_btc=round(beta_btc, 4),
            monthly_returns=monthly,
        )

    # ------------------------------------------------------------------
    # Statistical helpers
    # ------------------------------------------------------------------

    def _compute_daily_returns(
        self, equity_curve: list[tuple[int, float]]
    ) -> list[float]:
        """Convert equity curve to daily returns, resampling if needed."""
        if len(equity_curve) < 2:
            return []
        equities = [e for _, e in equity_curve]
        return [
            (equities[i] - equities[i-1]) / equities[i-1]
            for i in range(1, len(equities))
            if equities[i-1] > 0
        ]

    def _compute_drawdown_series(self, equities: list[float]) -> list[float]:
        peak = equities[0]
        dd_series = []
        for eq in equities:
            if eq > peak:
                peak = eq
            dd = (peak - eq) / peak * 100 if peak > 0 else 0.0
            dd_series.append(dd)
        return dd_series

    def _max_drawdown_duration(
        self, dd_series: list[float], equity_curve: list[tuple[int, float]]
    ) -> int:
        """Compute maximum drawdown duration in days."""
        max_duration = 0
        in_dd_since: Optional[int] = None
        for i, (ts_ms, _) in enumerate(equity_curve):
            if dd_series[i] > 0:
                if in_dd_since is None:
                    in_dd_since = ts_ms
                duration_days = (ts_ms - in_dd_since) / 86_400_000
                max_duration = max(max_duration, int(duration_days))
            else:
                in_dd_since = None
        return max_duration

    def _sharpe(self, returns: list[float]) -> float:
        if len(returns) < 2:
            return 0.0
        excess = [r - self.RISK_FREE_DAILY for r in returns]
        mean = _mean(excess)
        std = _std(returns)
        return float(_math.sqrt(252) * mean / std) if std > 0 else 0.0

    def _sortino(self, returns: list[float]) -> float:
        if len(returns) < 2:
            return 0.0
        mean = _mean(returns) - self.RISK_FREE_DAILY
        downside = [r for r in returns if r < self.RISK_FREE_DAILY]
        if not downside:
            return float("inf")
        down_std = _std(downside)
        return float(_math.sqrt(252) * mean / down_std) if down_std > 0 else 0.0

    def _omega(self, returns: list[float], threshold: float = 0.0) -> float:
        gains = sum(r - threshold for r in returns if r > threshold)
        losses = sum(threshold - r for r in returns if r < threshold)
        return gains / losses if losses > 0 else float("inf")

    def _var(self, returns: list[float], confidence: float) -> float:
        if not returns:
            return 0.0
        return float(abs(_percentile(returns, (1 - confidence) * 100))) * 100

    def _cvar(self, returns: list[float], confidence: float) -> float:
        if not returns:
            return 0.0
        cutoff = _percentile(returns, (1 - confidence) * 100)
        tail = [r for r in returns if r <= cutoff]
        return float(abs(_mean(tail))) * 100 if tail else 0.0

    def _compute_trade_stats(self, trades: list[dict]) -> dict:
        if not trades:
            return {
                "total_trades": 0, "winning_trades": 0, "losing_trades": 0,
                "win_rate_pct": 0.0, "profit_factor": 0.0, "expectancy_usd": 0.0,
                "avg_win_usd": 0.0, "avg_loss_usd": 0.0, "largest_win_usd": 0.0,
                "largest_loss_usd": 0.0, "avg_hold_duration_hours": 0.0,
                "max_consecutive_wins": 0, "max_consecutive_losses": 0,
                "total_fees_usd": 0.0, "total_slippage_usd": 0.0, "cost_drag_pct": 0.0,
            }

        pnls = [float(t.get("net_pnl", 0)) for t in trades]
        winning = [p for p in pnls if p > 0]
        losing = [p for p in pnls if p <= 0]

        gross_profit = sum(winning)
        gross_loss = abs(sum(losing))
        win_rate = len(winning) / len(pnls) * 100
        profit_factor = gross_profit / gross_loss if gross_loss > 0 else float("inf")
        avg_win = _mean(winning) if winning else 0.0
        avg_loss = _mean(losing) if losing else 0.0
        expectancy = (win_rate / 100 * avg_win) - ((1 - win_rate / 100) * abs(avg_loss))

        # Consecutive wins/losses
        max_consec_wins = max_consec_losses = cur_wins = cur_losses = 0
        for pnl in pnls:
            if pnl > 0:
                cur_wins += 1
                cur_losses = 0
                max_consec_wins = max(max_consec_wins, cur_wins)
            else:
                cur_losses += 1
                cur_wins = 0
                max_consec_losses = max(max_consec_losses, cur_losses)

        # Hold duration
        durations = []
        for t in trades:
            if t.get("entry_time_ms") and t.get("exit_time_ms"):
                dur_h = (int(t["exit_time_ms"]) - int(t["entry_time_ms"])) / 3_600_000
                durations.append(dur_h)

        total_fees = sum(float(t.get("fees", 0)) for t in trades)
        total_pnl = sum(pnls)
        cost_drag = total_fees / abs(total_pnl) * 100 if total_pnl != 0 else 0.0

        return {
            "total_trades": len(pnls),
            "winning_trades": len(winning),
            "losing_trades": len(losing),
            "win_rate_pct": round(win_rate, 2),
            "profit_factor": round(profit_factor, 4),
            "expectancy_usd": round(expectancy, 4),
            "avg_win_usd": round(avg_win, 4),
            "avg_loss_usd": round(abs(avg_loss), 4),
            "largest_win_usd": round(max(pnls), 4) if pnls else 0.0,
            "largest_loss_usd": round(abs(min(pnls)), 4) if pnls else 0.0,
            "avg_hold_duration_hours": round(_mean(durations), 2) if durations else 0.0,
            "max_consecutive_wins": max_consec_wins,
            "max_consecutive_losses": max_consec_losses,
            "total_fees_usd": round(total_fees, 4),
            "total_slippage_usd": 0.0,  # Would be tracked separately
            "cost_drag_pct": round(cost_drag, 4),
        }

    def _monthly_returns(
        self, equity_curve: list[tuple[int, float]]
    ) -> dict[str, float]:
        """Group equity curve by month and compute return for each."""
        from datetime import datetime, timezone
        monthly: dict[str, list[float]] = {}
        for ts_ms, equity in equity_curve:
            dt = datetime.fromtimestamp(ts_ms / 1000, tz=timezone.utc)
            key = dt.strftime("%Y-%m")
            monthly.setdefault(key, []).append(equity)

        result = {}
        for month, equities in sorted(monthly.items()):
            if len(equities) >= 2:
                ret = (equities[-1] - equities[0]) / equities[0] * 100
                result[month] = round(ret, 4)
        return result
