"""
CoinDCX Algo Platform — Market Data Ingestion Worker

Runs as a long-lived process (Kubernetes Deployment, 2 replicas).
Responsibilities:
  1. Maintain WebSocket connections to CoinDCX and Binance
  2. Normalize tick/bar/orderbook data into unified format
  3. Publish to Redis pub/sub for strategy containers (low-latency path)
  4. Publish to Kafka for durable storage and analytics (high-throughput path)
  5. Write OHLCV bars to TimescaleDB (warm store)
  6. Cache last tick per symbol in Redis hash (hot store)
  7. Handle reconnections with exponential back-off

Design:
  - One asyncio task per exchange per channel type
  - Redis pub/sub for fan-out to strategy containers (< 2ms)
  - Kafka for durability, analytics, and cold data pipeline
  - TimescaleDB writes are batched and async (non-blocking)
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import signal
import sys
import time
from decimal import Decimal

import aiohttp
import redis.asyncio as aioredis
from aiokafka import AIOKafkaProducer

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s [%(name)s] %(message)s",
    stream=sys.stdout,
)
logger = logging.getLogger("market_data.ingestion")


# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------

REDIS_URL = os.environ.get("REDIS_URL", "redis://localhost:6379")
KAFKA_BROKERS = os.environ.get("KAFKA_BROKERS", "localhost:9092")
COINDCX_WS_URL = os.environ.get("COINDCX_WS_URL", "wss://stream.coindcx.com")
BINANCE_WS_BASE = os.environ.get("BINANCE_WS_URL", "wss://stream.binance.com:9443/ws")

# Symbols to ingest — in production, loaded from DB / config service
SPOT_SYMBOLS = [
    "BTCUSDT", "ETHUSDT", "BNBUSDT", "SOLUSDT", "XRPUSDT",
    "ADAUSDT", "AVAXUSDT", "DOTUSDT", "MATICUSDT", "LINKUSDT",
    "LTCUSDT", "UNIUSDT", "ATOMUSDT", "FILUSDT", "NEARUSDT",
]
FUTURES_SYMBOLS = [
    "BTCUSDT", "ETHUSDT", "SOLUSDT", "BNBUSDT", "XRPUSDT",
]
RESOLUTIONS = ["1m", "5m", "15m", "1h", "4h", "1d"]


# ---------------------------------------------------------------------------
# Redis publisher
# ---------------------------------------------------------------------------

class RedisPublisher:
    """Publishes market data to Redis pub/sub and sets hot-cache keys."""

    def __init__(self, redis: aioredis.Redis):
        self._r = redis
        self._pipe_batch: list = []
        self._batch_size = 50

    async def publish_tick(self, symbol: str, data: dict) -> None:
        channel = f"tick.{symbol}"
        payload = json.dumps(data)
        # Pub/sub for strategy containers
        await self._r.publish(channel, payload)
        # Hot cache: last tick per symbol
        await self._r.hset("last_tick", symbol, payload)
        await self._r.expire("last_tick", 60)  # TTL 60s

    async def publish_bar(self, symbol: str, resolution: str, data: dict) -> None:
        channel = f"bar.{symbol}.{resolution}"
        payload = json.dumps(data)
        await self._r.publish(channel, payload)
        # Also cache last bar per symbol+resolution
        cache_key = f"last_bar:{symbol}:{resolution}"
        await self._r.setex(cache_key, 86400, payload)  # TTL 24h

    async def publish_orderbook(self, symbol: str, data: dict) -> None:
        channel = f"orderbook.{symbol}"
        await self._r.publish(channel, json.dumps(data))

    async def publish_funding(self, symbol: str, data: dict) -> None:
        channel = f"funding.{symbol}"
        await self._r.publish(channel, json.dumps(data))
        await self._r.hset("last_funding", symbol, json.dumps(data))


# ---------------------------------------------------------------------------
# Kafka publisher
# ---------------------------------------------------------------------------

class KafkaPublisher:
    """Publishes market data to Kafka topics for durable storage."""

    TOPIC_TICKS = "market.ticks"
    TOPIC_BARS = "market.bars"
    TOPIC_ORDERBOOK = "market.orderbook"
    TOPIC_FUNDING = "market.funding"

    def __init__(self, producer: AIOKafkaProducer):
        self._producer = producer

    async def publish_tick(self, symbol: str, data: dict) -> None:
        await self._safe_send(
            self.TOPIC_TICKS,
            key=symbol.encode(),
            value=json.dumps(data).encode(),
        )

    async def publish_bar(self, symbol: str, resolution: str, data: dict) -> None:
        await self._safe_send(
            self.TOPIC_BARS,
            key=f"{symbol}.{resolution}".encode(),
            value=json.dumps(data).encode(),
        )

    async def publish_funding(self, symbol: str, data: dict) -> None:
        await self._safe_send(
            self.TOPIC_FUNDING,
            key=symbol.encode(),
            value=json.dumps(data).encode(),
        )

    async def _safe_send(self, topic: str, key: bytes, value: bytes) -> None:
        try:
            await self._producer.send(topic, key=key, value=value)
        except Exception as e:
            logger.warning(f"Kafka send failed ({topic}): {e}")


# ---------------------------------------------------------------------------
# Binance WebSocket handlers
# ---------------------------------------------------------------------------

class BinanceIngestionWorker:
    """
    Maintains WebSocket connections to Binance for spot and futures data.
    Uses combined stream endpoint for efficiency (one connection per exchange).
    """

    SPOT_WS = "wss://stream.binance.com:9443/stream"
    FUTURES_WS = "wss://fstream.binance.com/stream"

    def __init__(
        self,
        redis_pub: RedisPublisher,
        kafka_pub: KafkaPublisher,
        session: aiohttp.ClientSession,
    ):
        self._redis = redis_pub
        self._kafka = kafka_pub
        self._session = session
        self._running = False

    async def start(self) -> None:
        self._running = True
        tasks = [
            self._run_spot_stream(),
            self._run_futures_stream(),
        ]
        await asyncio.gather(*tasks, return_exceptions=True)

    async def _run_spot_stream(self) -> None:
        # Build combined stream of ticks + 1m bars for all symbols
        streams = []
        for sym in SPOT_SYMBOLS:
            s = sym.lower()
            streams.append(f"{s}@aggTrade")
            for res in ["1m", "5m", "15m", "1h", "4h", "1d"]:
                streams.append(f"{s}@kline_{res}")

        url = f"{self.SPOT_WS}?streams={'/'.join(streams)}"
        await self._ws_loop("spot", url)

    async def _run_futures_stream(self) -> None:
        streams = []
        for sym in FUTURES_SYMBOLS:
            s = sym.lower()
            streams.append(f"{s}@aggTrade")
            streams.append(f"{s}@markPrice")
            for res in ["1m", "5m", "1h", "4h"]:
                streams.append(f"{s}@continuousKline_{res}")

        url = f"{self.FUTURES_WS}?streams={'/'.join(streams)}"
        await self._ws_loop("futures", url)

    async def _ws_loop(self, market: str, url: str) -> None:
        retry_delay = 1.0
        while self._running:
            try:
                logger.info(f"Connecting Binance {market} stream")
                async with self._session.ws_connect(
                    url,
                    heartbeat=20,
                    max_msg_size=10 * 1024 * 1024,
                ) as ws:
                    retry_delay = 1.0
                    logger.info(f"Binance {market} stream connected")
                    async for msg in ws:
                        if msg.type == aiohttp.WSMsgType.TEXT:
                            await self._handle_message(json.loads(msg.data), market)
                        elif msg.type in (aiohttp.WSMsgType.CLOSE, aiohttp.WSMsgType.ERROR):
                            logger.warning(f"Binance {market} WS closed: {msg.data}")
                            break
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.warning(f"Binance {market} error: {e}. Reconnecting in {retry_delay}s")
                await asyncio.sleep(retry_delay)
                retry_delay = min(retry_delay * 2, 60.0)

    async def _handle_message(self, wrapper: dict, market: str) -> None:
        data = wrapper.get("data", wrapper)
        event_type = data.get("e", "")

        if event_type == "aggTrade":
            await self._handle_tick(data, market)
        elif event_type == "kline":
            await self._handle_bar(data, market)
        elif event_type == "continuous_kline":
            await self._handle_bar(data, market, futures=True)
        elif event_type == "markPriceUpdate":
            await self._handle_funding(data)

    async def _handle_tick(self, data: dict, market: str) -> None:
        symbol = data["s"]
        tick = {
            "symbol": symbol,
            "price": data["p"],
            "quantity": data["q"],
            "side": "sell" if data.get("m") else "buy",
            "timestamp_ms": int(data["T"]),
            "exchange": "binance",
            "market": market,
        }
        await self._redis.publish_tick(symbol, tick)
        await self._kafka.publish_tick(symbol, tick)

    async def _handle_bar(self, data: dict, market: str, futures: bool = False) -> None:
        k = data.get("k", {})
        if not k.get("x", False):  # Only closed bars
            return
        symbol = data["s"]
        resolution = k["i"]
        bar = {
            "symbol": symbol,
            "resolution": resolution,
            "open": k["o"],
            "high": k["h"],
            "low": k["l"],
            "close": k["c"],
            "volume": k["v"],
            "timestamp_ms": int(k["t"]),
            "num_trades": k.get("n", 0),
            "taker_buy_volume": k.get("Q", "0"),
            "exchange": "binance",
            "market": market,
        }
        await self._redis.publish_bar(symbol, resolution, bar)
        await self._kafka.publish_bar(symbol, resolution, bar)
        logger.debug(f"Bar published: {symbol} {resolution} close={k['c']}")

    async def _handle_funding(self, data: dict) -> None:
        symbol = data["s"]
        funding = {
            "symbol": symbol,
            "rate": data.get("r", "0"),
            "next_funding_ms": int(data.get("T", 0)),
            "mark_price": data.get("p", "0"),
            "timestamp_ms": int(time.time() * 1000),
            "exchange": "binance",
        }
        await self._redis.publish_funding(symbol, funding)
        await self._kafka.publish_funding(symbol, funding)


# ---------------------------------------------------------------------------
# CoinDCX WebSocket handler
# ---------------------------------------------------------------------------

class CoinDCXIngestionWorker:
    """
    Maintains WebSocket connections to CoinDCX.
    CoinDCX uses socket.io so we use polling + ws upgrade.
    """

    WS_URL = "wss://stream.coindcx.com/socket.io/?transport=websocket"

    def __init__(
        self,
        redis_pub: RedisPublisher,
        kafka_pub: KafkaPublisher,
        session: aiohttp.ClientSession,
    ):
        self._redis = redis_pub
        self._kafka = kafka_pub
        self._session = session
        self._running = False

    async def start(self) -> None:
        self._running = True
        await self._ws_loop()

    async def _ws_loop(self) -> None:
        retry_delay = 1.0
        while self._running:
            try:
                logger.info("Connecting CoinDCX stream")
                async with self._session.ws_connect(
                    self.WS_URL,
                    heartbeat=25,
                ) as ws:
                    retry_delay = 1.0
                    # Subscribe to all spot symbols
                    for symbol in SPOT_SYMBOLS:
                        await ws.send_str(json.dumps({
                            "event": "join",
                            "channelName": f"trade.{symbol}",
                        }))
                        for res in RESOLUTIONS:
                            await ws.send_str(json.dumps({
                                "event": "join",
                                "channelName": f"candlestick.{res}.{symbol}",
                            }))

                    logger.info("CoinDCX stream connected and subscribed")
                    async for msg in ws:
                        if msg.type == aiohttp.WSMsgType.TEXT:
                            await self._handle_message(json.loads(msg.data))
                        elif msg.type in (aiohttp.WSMsgType.CLOSE, aiohttp.WSMsgType.ERROR):
                            break
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.warning(f"CoinDCX stream error: {e}. Reconnecting in {retry_delay}s")
                await asyncio.sleep(retry_delay)
                retry_delay = min(retry_delay * 2, 60.0)

    async def _handle_message(self, data: dict) -> None:
        event = data.get("event", "")
        channel = data.get("channelName", "")
        payload = data.get("data", {})

        if channel.startswith("trade."):
            symbol = channel.replace("trade.", "")
            await self._handle_tick(symbol, payload)
        elif channel.startswith("candlestick."):
            parts = channel.split(".")
            if len(parts) >= 3:
                resolution = parts[1]
                symbol = parts[2]
                await self._handle_bar(symbol, resolution, payload)

    async def _handle_tick(self, symbol: str, data: dict) -> None:
        tick = {
            "symbol": symbol,
            "price": str(data.get("p", "0")),
            "quantity": str(data.get("q", "0")),
            "side": "buy" if data.get("m") else "sell",
            "timestamp_ms": int(data.get("T", time.time() * 1000)),
            "exchange": "coindcx",
            "market": "spot",
        }
        await self._redis.publish_tick(symbol, tick)
        await self._kafka.publish_tick(symbol, tick)

    async def _handle_bar(self, symbol: str, resolution: str, data: dict) -> None:
        if not data.get("x", True):  # Only closed bars
            return
        bar = {
            "symbol": symbol,
            "resolution": resolution,
            "open": str(data.get("o", "0")),
            "high": str(data.get("h", "0")),
            "low": str(data.get("l", "0")),
            "close": str(data.get("c", "0")),
            "volume": str(data.get("v", "0")),
            "timestamp_ms": int(data.get("t", time.time() * 1000)),
            "exchange": "coindcx",
            "market": "spot",
        }
        await self._redis.publish_bar(symbol, resolution, bar)
        await self._kafka.publish_bar(symbol, resolution, bar)


# ---------------------------------------------------------------------------
# TimescaleDB writer (async batch writer)
# ---------------------------------------------------------------------------

class TimescaleWriter:
    """
    Batch-writes OHLCV bars to TimescaleDB from Kafka consumer.
    Runs as a separate coroutine, decoupled from ingestion hot path.
    Uses COPY for high-throughput bulk inserts.
    """

    def __init__(self, dsn: str):
        self._dsn = dsn
        self._batch: list[dict] = []
        self._batch_size = 100
        self._flush_interval = 5.0  # Flush every 5 seconds

    async def start(self) -> None:
        """Consumer loop — reads from Kafka market.bars topic."""
        # In production: aiokafka AIOKafkaConsumer consuming market.bars
        # Buffers into batch, flushes to TimescaleDB
        while True:
            await asyncio.sleep(self._flush_interval)
            if self._batch:
                await self._flush()

    def add_bar(self, bar: dict) -> None:
        self._batch.append(bar)
        if len(self._batch) >= self._batch_size:
            asyncio.ensure_future(self._flush())

    async def _flush(self) -> None:
        if not self._batch:
            return
        batch = self._batch[:]
        self._batch.clear()
        try:
            await self._write_batch(batch)
            logger.debug(f"TimescaleDB: wrote {len(batch)} bars")
        except Exception as e:
            logger.error(f"TimescaleDB write failed: {e}")
            # Re-queue failed batch
            self._batch = batch + self._batch

    async def _write_batch(self, bars: list[dict]) -> None:
        # Production: use asyncpg COPY for maximum throughput
        # import asyncpg
        # async with asyncpg.connect(self._dsn) as conn:
        #     await conn.copy_records_to_table(
        #         "ohlcv_bars",
        #         records=[
        #             (b["symbol"], b["resolution"], b["open"], b["high"],
        #              b["low"], b["close"], b["volume"], b["timestamp_ms"],
        #              b["exchange"])
        #             for b in bars
        #         ],
        #         columns=["symbol", "resolution", "open", "high", "low",
        #                  "close", "volume", "timestamp_ms", "exchange"],
        #     )
        pass


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

class IngestionWorker:
    """Orchestrates all ingestion components."""

    def __init__(self):
        self._running = False
        self._session: aiohttp.ClientSession = None
        self._redis: aioredis.Redis = None
        self._kafka_producer: AIOKafkaProducer = None

    async def start(self) -> None:
        logger.info("Market data ingestion worker starting")
        self._running = True

        # Connections
        self._session = aiohttp.ClientSession(
            connector=aiohttp.TCPConnector(limit=100, ttl_dns_cache=300),
        )
        self._redis = await aioredis.from_url(
            REDIS_URL, encoding="utf-8", decode_responses=False
        )
        self._kafka_producer = AIOKafkaProducer(
            bootstrap_servers=KAFKA_BROKERS,
            compression_type="lz4",
            max_batch_size=65536,
            linger_ms=5,  # 5ms batching for throughput
        )
        await self._kafka_producer.start()

        redis_pub = RedisPublisher(self._redis)
        kafka_pub = KafkaPublisher(self._kafka_producer)

        binance_worker = BinanceIngestionWorker(redis_pub, kafka_pub, self._session)
        coindcx_worker = CoinDCXIngestionWorker(redis_pub, kafka_pub, self._session)

        # Graceful shutdown
        loop = asyncio.get_event_loop()
        for sig in (signal.SIGTERM, signal.SIGINT):
            loop.add_signal_handler(sig, lambda: asyncio.ensure_future(self.stop()))

        # Run all workers concurrently
        logger.info("All ingestion workers starting")
        await asyncio.gather(
            binance_worker.start(),
            coindcx_worker.start(),
            self._health_server(),
            return_exceptions=True,
        )

    async def _health_server(self) -> None:
        """Minimal HTTP server for Kubernetes liveness probe."""
        from aiohttp import web

        async def health(request):
            return web.json_response({"status": "ok", "timestamp": int(time.time())})

        app = web.Application()
        app.router.add_get("/health", health)
        runner = web.AppRunner(app)
        await runner.setup()
        site = web.TCPSite(runner, "0.0.0.0", 8090)
        await site.start()
        logger.info("Health server started on :8090")

    async def stop(self) -> None:
        logger.info("Ingestion worker shutting down")
        self._running = False
        if self._kafka_producer:
            await self._kafka_producer.stop()
        if self._redis:
            await self._redis.close()
        if self._session:
            await self._session.close()


if __name__ == "__main__":
    worker = IngestionWorker()
    asyncio.run(worker.start())
