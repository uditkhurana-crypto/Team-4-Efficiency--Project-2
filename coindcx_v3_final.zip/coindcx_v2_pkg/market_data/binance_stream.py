"""
CoinDCX Algo Platform — Market Data Service
============================================
EXTENDS: coindcx_platform/ws_server.py (does not replace it)

Adds:
  1. BinanceStreamClient  — connects to Binance WS (when network available)
  2. MarketDataService    — aggregates prices from Binance OR simulator
  3. CandleCache          — stores last N candles per symbol per resolution
  4. /ws/market-stream    — unified WS endpoint broadcasting to frontend

The frontend connects to ws://localhost:8001 (existing WS server).
This module feeds that server with Binance data when available,
falling back to the GBM simulator seamlessly.

Signal format emitted on every candle close:
    {
        "type": "candle",
        "symbol": "BTCUSDT",
        "resolution": "1m",
        "open": 50000,  "high": 50100, "low": 49900, "close": 50050,
        "volume": 12.4,
        "timestamp_ms": 1234567890000,
        "indicators": {
            "ema_9": 50020, "ema_21": 49980,
            "rsi_14": 58.3,
            "macd": 124,  "macd_signal": 98,
            "bb_upper": 50400, "bb_mid": 50000, "bb_lower": 49600,
            "vwap": 50010
        }
    }
"""
from __future__ import annotations

import json
import math
import random
import socket
import ssl
import struct
import threading
import time
import base64
import hashlib
from collections import deque
from dataclasses import dataclass, field, asdict
from typing import Optional, Callable

import numpy as np


# ─────────────────────────────────────────────────────────────────────────────
# Candle data model
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class Candle:
    symbol:       str
    resolution:   str
    timestamp_ms: int
    open:         float
    high:         float
    low:          float
    close:        float
    volume:       float
    is_closed:    bool = True

    def to_dict(self) -> dict:
        return asdict(self)


# ─────────────────────────────────────────────────────────────────────────────
# In-memory candle cache (ring buffer per symbol+resolution)
# ─────────────────────────────────────────────────────────────────────────────

class CandleCache:
    """Stores last 500 candles per (symbol, resolution) pair."""

    def __init__(self, maxlen: int = 500):
        self._cache: dict[str, deque[Candle]] = {}
        self._maxlen = maxlen
        self._lock = threading.Lock()

    def _key(self, symbol: str, resolution: str) -> str:
        return f"{symbol}:{resolution}"

    def push(self, candle: Candle) -> None:
        key = self._key(candle.symbol, candle.resolution)
        with self._lock:
            if key not in self._cache:
                self._cache[key] = deque(maxlen=self._maxlen)
            self._cache[key].append(candle)

    def get(self, symbol: str, resolution: str, limit: int = 200) -> list[Candle]:
        key = self._key(symbol, resolution)
        with self._lock:
            buf = self._cache.get(key, deque())
            return list(buf)[-limit:]

    def get_closes(self, symbol: str, resolution: str, limit: int = 200) -> list[float]:
        return [c.close for c in self.get(symbol, resolution, limit)]

    def latest(self, symbol: str, resolution: str) -> Optional[Candle]:
        candles = self.get(symbol, resolution, 1)
        return candles[-1] if candles else None


# ─────────────────────────────────────────────────────────────────────────────
# Technical Indicator Engine (pure Python + numpy, no ta-lib)
# ─────────────────────────────────────────────────────────────────────────────

class IndicatorEngine:
    """Computes technical indicators from price arrays."""

    @staticmethod
    def ema(prices: list[float], period: int) -> list[float]:
        if len(prices) < 2:
            return prices[:]
        k = 2.0 / (period + 1)
        result = [prices[0]]
        for p in prices[1:]:
            result.append(p * k + result[-1] * (1 - k))
        return result

    @staticmethod
    def sma(prices: list[float], period: int) -> list[float]:
        result = []
        for i in range(len(prices)):
            if i < period - 1:
                result.append(None)
            else:
                result.append(sum(prices[i - period + 1:i + 1]) / period)
        return result

    @staticmethod
    def rsi(prices: list[float], period: int = 14) -> list[float]:
        if len(prices) < period + 1:
            return [50.0] * len(prices)
        deltas = [prices[i] - prices[i-1] for i in range(1, len(prices))]
        gains  = [max(0, d) for d in deltas]
        losses = [max(0, -d) for d in deltas]

        avg_gain = sum(gains[:period]) / period
        avg_loss = sum(losses[:period]) / period

        result = [None] * period
        if avg_loss == 0:
            result.append(100.0)
        else:
            result.append(100 - 100 / (1 + avg_gain / avg_loss))

        for i in range(period, len(deltas)):
            avg_gain = (avg_gain * (period - 1) + gains[i]) / period
            avg_loss = (avg_loss * (period - 1) + losses[i]) / period
            if avg_loss == 0:
                result.append(100.0)
            else:
                result.append(100 - 100 / (1 + avg_gain / avg_loss))
        return result

    @staticmethod
    def macd(prices: list[float], fast: int = 12, slow: int = 26,
             signal: int = 9) -> tuple[list, list, list]:
        if len(prices) < slow + signal:
            n = len(prices)
            return [0.0]*n, [0.0]*n, [0.0]*n
        ema_f = IndicatorEngine.ema(prices, fast)
        ema_s = IndicatorEngine.ema(prices, slow)
        macd_line = [a - b for a, b in zip(ema_f, ema_s)]
        sig_line  = IndicatorEngine.ema(macd_line, signal)
        histogram = [m - s for m, s in zip(macd_line, sig_line)]
        return macd_line, sig_line, histogram

    @staticmethod
    def bollinger(prices: list[float], period: int = 20,
                  std_dev: float = 2.0) -> tuple[list, list, list]:
        upper, mid, lower = [], [], []
        for i in range(len(prices)):
            if i < period - 1:
                upper.append(None); mid.append(None); lower.append(None)
            else:
                window = prices[i - period + 1:i + 1]
                m = sum(window) / period
                s = math.sqrt(sum((x - m)**2 for x in window) / period)
                upper.append(m + std_dev * s)
                mid.append(m)
                lower.append(m - std_dev * s)
        return upper, mid, lower

    @staticmethod
    def vwap(candles: list[Candle]) -> float:
        """Volume Weighted Average Price for the session."""
        total_vol = sum(c.volume for c in candles)
        if total_vol == 0:
            return candles[-1].close if candles else 0
        return sum(((c.high + c.low + c.close) / 3) * c.volume
                   for c in candles) / total_vol

    @classmethod
    def compute_all(cls, candles: list[Candle]) -> dict:
        """Compute all indicators and return latest values."""
        if not candles:
            return {}
        closes = [c.close for c in candles]
        n = len(closes)

        ema9  = cls.ema(closes, 9)
        ema21 = cls.ema(closes, 21)
        ema50 = cls.ema(closes, 50) if n >= 50 else closes[:]
        rsi   = cls.rsi(closes, 14)
        macd_line, sig_line, hist = cls.macd(closes)
        bb_upper, bb_mid, bb_lower = cls.bollinger(closes)
        vwap  = cls.vwap(candles[-50:])  # rolling session VWAP

        def last(arr):
            v = arr[-1] if arr else None
            return round(v, 4) if v is not None else None

        rsi_val = last(rsi)
        signal_strength = "NEUTRAL"
        if rsi_val:
            if rsi_val < 30:  signal_strength = "STRONG_BUY"
            elif rsi_val < 45: signal_strength = "BUY"
            elif rsi_val > 70: signal_strength = "STRONG_SELL"
            elif rsi_val > 55: signal_strength = "SELL"

        return {
            "ema_9":      round(last(ema9) or 0, 2),
            "ema_21":     round(last(ema21) or 0, 2),
            "ema_50":     round(last(ema50) or 0, 2),
            "rsi_14":     round(rsi_val or 50, 2),
            "macd":       round(last(macd_line) or 0, 4),
            "macd_signal": round(last(sig_line) or 0, 4),
            "macd_hist":  round(last(hist) or 0, 4),
            "bb_upper":   round(last(bb_upper) or 0, 2),
            "bb_mid":     round(last(bb_mid) or 0, 2),
            "bb_lower":   round(last(bb_lower) or 0, 2),
            "vwap":       round(vwap, 2),
            "signal":     signal_strength,
        }


# ─────────────────────────────────────────────────────────────────────────────
# Binance WebSocket Client (pure stdlib, no websockets library)
# ─────────────────────────────────────────────────────────────────────────────

class BinanceStreamClient:
    """
    Connects to Binance WebSocket kline stream.
    Falls back to simulator if network unavailable.
    
    Usage:
        client = BinanceStreamClient(
            symbols=["btcusdt", "ethusdt"],
            resolution="1m",
            on_candle=my_callback
        )
        client.start()
    """

    BINANCE_WS_HOST = "stream.binance.com"
    BINANCE_WS_PORT = 9443

    def __init__(self, symbols: list[str], resolution: str = "1m",
                 on_candle: Callable[[Candle], None] = None):
        self.symbols    = [s.lower() for s in symbols]
        self.resolution = resolution
        self.on_candle  = on_candle or (lambda c: None)
        self._thread: Optional[threading.Thread] = None
        self._running   = False
        self._connected = False

    def start(self):
        self._running = True
        self._thread  = threading.Thread(target=self._run, daemon=True, name="binance-ws")
        self._thread.start()

    def stop(self):
        self._running = False
        self._connected = False

    @property
    def connected(self) -> bool:
        return self._connected

    def _run(self):
        # Try Binance first, fall back to sim on any failure
        try:
            self._connect_binance()
        except Exception as e:
            print(f"[BinanceWS] Network unavailable ({e}), using simulator")
            self._connected = False

    def _connect_binance(self):
        """Connect using raw socket + TLS + WS handshake (pure stdlib)."""
        streams = "/".join(f"{sym}@kline_{self.resolution}" for sym in self.symbols)
        path    = f"/stream?streams={streams}"

        ctx = ssl.create_default_context()
        raw = socket.create_connection((self.BINANCE_WS_HOST, self.BINANCE_WS_PORT), timeout=10)
        sock = ctx.wrap_socket(raw, server_hostname=self.BINANCE_WS_HOST)

        # WebSocket handshake
        key_bytes = base64.b64encode(bytes(random.randint(0, 255) for _ in range(16))).decode()
        handshake = (
            f"GET {path} HTTP/1.1\r\n"
            f"Host: {self.BINANCE_WS_HOST}\r\n"
            f"Upgrade: websocket\r\n"
            f"Connection: Upgrade\r\n"
            f"Sec-WebSocket-Key: {key_bytes}\r\n"
            f"Sec-WebSocket-Version: 13\r\n\r\n"
        )
        sock.send(handshake.encode())
        resp = b""
        while b"\r\n\r\n" not in resp:
            resp += sock.recv(1024)

        if b"101" not in resp:
            raise RuntimeError("WebSocket upgrade failed")

        self._connected = True
        print(f"[BinanceWS] Connected to {len(self.symbols)} streams")

        # Read frames
        buf = b""
        while self._running:
            try:
                chunk = sock.recv(4096)
                if not chunk:
                    break
                buf += chunk
                while len(buf) >= 2:
                    # Parse WS frame header
                    b1, b2 = buf[0], buf[1]
                    # fin = (b1 >> 7) & 1
                    opcode = b1 & 0x0F
                    mask   = (b2 >> 7) & 1
                    length = b2 & 0x7F

                    header_len = 2
                    if length == 126:
                        if len(buf) < 4: break
                        length = struct.unpack(">H", buf[2:4])[0]
                        header_len = 4
                    elif length == 127:
                        if len(buf) < 10: break
                        length = struct.unpack(">Q", buf[2:10])[0]
                        header_len = 10

                    if mask:
                        header_len += 4

                    total = header_len + length
                    if len(buf) < total:
                        break

                    payload = buf[header_len:total]
                    buf = buf[total:]

                    if opcode == 8:  # close
                        return
                    if opcode == 1:  # text
                        self._parse_binance_message(payload.decode("utf-8", errors="ignore"))

            except socket.timeout:
                continue
            except Exception:
                break

        self._connected = False

    def _parse_binance_message(self, raw: str):
        try:
            msg  = json.loads(raw)
            data = msg.get("data", msg)
            k    = data.get("k", {})
            if not k:
                return
            candle = Candle(
                symbol       = k.get("s", "BTCUSDT"),
                resolution   = self.resolution,
                timestamp_ms = int(k.get("t", 0)),
                open         = float(k.get("o", 0)),
                high         = float(k.get("h", 0)),
                low          = float(k.get("l", 0)),
                close        = float(k.get("c", 0)),
                volume       = float(k.get("v", 0)),
                is_closed    = bool(k.get("x", False)),
            )
            self.on_candle(candle)
        except Exception:
            pass


# ─────────────────────────────────────────────────────────────────────────────
# Market Data Service
# ─────────────────────────────────────────────────────────────────────────────

class MarketDataService:
    """
    Unified market data service.
    
    - Tries Binance WebSocket first
    - Falls back to GBM simulator automatically
    - Populates CandleCache
    - Broadcasts enriched candles (with indicators) via callback
    - Generates strategy signals based on indicator crosses
    
    EXTENDS coindcx_platform/ws_server.py by feeding it enriched data.
    """

    SUPPORTED_RESOLUTIONS = ["1m", "5m", "15m", "1h", "4h", "1d"]

    # Base prices INR (kept in sync with ws_server.py)
    BASE_PRICES_INR = {
        "BTC": 3_482_450, "ETH": 248_600, "BNB": 47_200, "SOL": 14_820,
        "ADA": 48.2,      "MATIC": 74.5,  "DOT": 620,    "AVAX": 3_240,
        "LINK": 1_240,    "UNI": 1_050,   "LTC": 7_420,  "XRP": 52.4,
        "DOGE": 13.8,     "SHIB": 0.00092,"ATOM": 840,   "NEAR": 430,
        "FTM": 48.2,      "ALGO": 16.4,   "INJ": 2_840,  "OP": 284,
        "ARB": 148,       "SUI": 162,     "SEI": 44.2,   "WIF": 284,
    }

    INR_USD = 84.2

    def __init__(self, on_candle: Callable[[dict], None] = None,
                 on_signal: Callable[[dict], None] = None):
        self.cache    = CandleCache()
        self.ind      = IndicatorEngine()
        self._on_candle = on_candle or (lambda d: None)
        self._on_signal = on_signal or (lambda d: None)
        self._prices  = {s: p * (0.98 + random.random() * 0.04)
                         for s, p in self.BASE_PRICES_INR.items()}
        self._lock    = threading.Lock()
        self._running = False
        self._sim_thread: Optional[threading.Thread] = None
        self._binance: Optional[BinanceStreamClient] = None

    def start(self, use_binance: bool = True,
              symbols: list[str] = None,
              resolution: str = "1m"):
        """Start the service. Tries Binance first, falls back to simulator."""
        self._running = True

        if use_binance and symbols:
            binance_syms = [s.replace("/", "").lower() for s in symbols]
            self._binance = BinanceStreamClient(
                symbols    = binance_syms,
                resolution = resolution,
                on_candle  = self._handle_binance_candle,
            )
            self._binance.start()
            time.sleep(2)  # Give Binance time to connect

        if not (self._binance and self._binance.connected):
            # Start GBM simulator for all 24 supported symbols
            self._sim_thread = threading.Thread(
                target=self._run_simulator, daemon=True, name="mds-sim"
            )
            self._sim_thread.start()
            print("[MarketData] Running in simulator mode (GBM)")
        else:
            print(f"[MarketData] Connected to Binance ({len(symbols)} streams)")

    def stop(self):
        self._running = False
        if self._binance:
            self._binance.stop()

    def get_candles(self, symbol: str, resolution: str = "1h",
                    limit: int = 200) -> list[dict]:
        """Get cached candles for a symbol."""
        sym_clean = symbol.replace("/INR", "").replace("INR", "").replace("USDT", "").upper()
        candles = self.cache.get(sym_clean, resolution, limit)
        if not candles:
            # Bootstrap from simulator
            self._bootstrap_candles(sym_clean, resolution, limit)
            candles = self.cache.get(sym_clean, resolution, limit)
        return [c.to_dict() for c in candles]

    def get_indicators(self, symbol: str, resolution: str = "1h") -> dict:
        """Get latest computed indicators for a symbol."""
        sym_clean = symbol.replace("/INR", "").replace("INR", "").replace("USDT", "").upper()
        candles = self.cache.get(sym_clean, resolution, 200)
        if not candles:
            return {}
        return self.ind.compute_all(candles)

    def current_price(self, symbol: str) -> float:
        sym = symbol.replace("/INR", "").replace("INR", "").replace("USDT", "").upper()
        with self._lock:
            return self._prices.get(sym, 0.0)

    # ── Internal ────────────────────────────────────────────────────────────

    def _handle_binance_candle(self, candle: Candle):
        """Handle a candle from Binance (convert USDT → INR)."""
        # Binance prices are in USDT, convert to INR
        candle.open  *= self.INR_USD
        candle.high  *= self.INR_USD
        candle.low   *= self.INR_USD
        candle.close *= self.INR_USD
        sym = candle.symbol.replace("USDT", "").replace("BTC", "BTC").upper()
        candle.symbol = sym
        with self._lock:
            self._prices[sym] = candle.close
        self.cache.push(candle)
        if candle.is_closed:
            self._emit_enriched(candle)

    def _bootstrap_candles(self, symbol: str, resolution: str, n: int):
        """Generate N historical candles via GBM for bootstrapping."""
        base = self.BASE_PRICES_INR.get(symbol, 1000.0)
        res_seconds = {"1m": 60, "5m": 300, "15m": 900, "1h": 3600,
                       "4h": 14400, "1d": 86400}.get(resolution, 3600)
        vol = 0.003 * math.sqrt(res_seconds / 60)
        now_ms = int(time.time() * 1000)
        price  = base * (0.92 + random.random() * 0.16)

        for i in range(n):
            ts = now_ms - (n - i) * res_seconds * 1000
            r  = random.gauss(0.00005, vol)
            price = max(price * (1 + r), 0.001)
            o = price
            h = price * (1 + abs(random.gauss(0, vol * 0.5)))
            l = price * (1 - abs(random.gauss(0, vol * 0.5)))
            c = price
            v = base * (0.5 + random.random()) * 0.001
            self.cache.push(Candle(
                symbol=symbol, resolution=resolution,
                timestamp_ms=ts, open=o, high=h, low=l, close=c,
                volume=v, is_closed=True,
            ))

    def _run_simulator(self):
        """GBM price simulator — runs when Binance is unavailable."""
        # Bootstrap historical data for all symbols
        for sym in self.BASE_PRICES_INR:
            for res in ["1m", "5m", "1h"]:
                self._bootstrap_candles(sym, res, 200)

        # Tick interval in seconds
        tick = 3.0
        bar_counter = {sym: 0 for sym in self.BASE_PRICES_INR}

        while self._running:
            start = time.time()
            with self._lock:
                for sym in list(self._prices.keys()):
                    base = self.BASE_PRICES_INR.get(sym, 100)
                    mr   = 0.0001 * (base - self._prices[sym]) / base
                    noise = random.gauss(mr, 0.002)
                    self._prices[sym] = max(self._prices[sym] * (1 + noise), 0.001)

            # Every tick, push a new 1m candle for BTC and ETH (demo)
            for sym in ["BTC", "ETH", "SOL", "BNB"]:
                with self._lock:
                    p = self._prices.get(sym, 100)
                bar_counter[sym] = bar_counter.get(sym, 0) + 1

                # Generate synthetic 1m candle
                vol = abs(random.gauss(0, 0.003))
                o = p * (1 - vol * 0.3)
                h = p * (1 + vol)
                l = p * (1 - vol)
                c = p
                candle = Candle(
                    symbol=sym, resolution="1m",
                    timestamp_ms=int(time.time() * 1000),
                    open=round(o, 2), high=round(h, 2),
                    low=round(l, 2),  close=round(c, 2),
                    volume=round(abs(random.gauss(1.0, 0.3)), 4),
                    is_closed=True,
                )
                self.cache.push(candle)
                self._emit_enriched(candle)

            elapsed = time.time() - start
            time.sleep(max(0, tick - elapsed))

    def _emit_enriched(self, candle: Candle):
        """Attach indicators and emit enriched candle + check for signals."""
        candles = self.cache.get(candle.symbol, candle.resolution, 200)
        indicators = self.ind.compute_all(candles)

        enriched = {
            "type": "candle",
            **candle.to_dict(),
            "indicators": indicators,
        }
        self._on_candle(enriched)

        # Check for strategy signal conditions
        self._check_signals(candle, indicators)

    def _check_signals(self, candle: Candle, ind: dict):
        """Generate signals based on indicator conditions."""
        if not ind:
            return

        rsi   = ind.get("rsi_14", 50)
        ema9  = ind.get("ema_9",  candle.close)
        ema21 = ind.get("ema_21", candle.close)
        macd  = ind.get("macd", 0)
        macd_s = ind.get("macd_signal", 0)

        signal = None
        reason = ""

        if rsi < 28:
            signal = "BUY"
            reason = f"RSI oversold ({rsi:.1f})"
        elif rsi > 72:
            signal = "SELL"
            reason = f"RSI overbought ({rsi:.1f})"
        elif ema9 > ema21 and macd > macd_s and macd > 0:
            signal = "BUY"
            reason = "EMA bullish + MACD cross above"
        elif ema9 < ema21 and macd < macd_s and macd < 0:
            signal = "SELL"
            reason = "EMA bearish + MACD cross below"

        if signal:
            self._on_signal({
                "type": "signal",
                "strategy_id": f"mds_{candle.symbol.lower()}_auto",
                "symbol": candle.symbol,
                "action": signal,
                "price": candle.close,
                "reason": reason,
                "indicators": ind,
                "timestamp_ms": candle.timestamp_ms,
            })


# ─────────────────────────────────────────────────────────────────────────────
# Singleton accessor (used by api_server.py extensions)
# ─────────────────────────────────────────────────────────────────────────────

_mds_instance: Optional[MarketDataService] = None
_mds_lock = threading.Lock()


def get_market_data_service() -> MarketDataService:
    global _mds_instance
    with _mds_lock:
        if _mds_instance is None:
            _mds_instance = MarketDataService()
            _mds_instance.start(use_binance=True,
                                symbols=["BTCUSDT", "ETHUSDT", "BNBUSDT", "SOLUSDT"],
                                resolution="1m")
    return _mds_instance
