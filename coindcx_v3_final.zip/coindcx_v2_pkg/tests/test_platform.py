"""
CoinDCX Algo Platform — Test Suite

Tests for all critical components:
  - SDK models and strategy base class
  - Risk engine pre-trade checks
  - OMS order lifecycle
  - Backtest engine accuracy
  - Exchange adapter normalization
  - Analytics metrics computation
  - Copy trading order scaling
"""

from __future__ import annotations

import asyncio
import time
import uuid
from decimal import Decimal
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

# ─────────────────────────────────────────────────
# Fixtures
# ─────────────────────────────────────────────────

@pytest.fixture
def make_bar():
    from coindcx_algo.sdk.models import Bar
    def _make(
        symbol="BTCUSDT",
        open="50000",
        high="51000",
        low="49000",
        close="50500",
        volume="100",
        timestamp_ms=None,
        resolution="1h",
    ):
        return Bar(
            symbol=symbol,
            open=Decimal(open),
            high=Decimal(high),
            low=Decimal(low),
            close=Decimal(close),
            volume=Decimal(volume),
            timestamp_ms=timestamp_ms or int(time.time() * 1000),
            resolution=resolution,
        )
    return _make


@pytest.fixture
def make_order_request():
    from coindcx_algo.sdk.models import OrderRequest, OrderSide, OrderType, MarketType
    def _make(
        symbol="BTCUSDT",
        side="buy",
        quantity="0.001",
        order_type="market",
        price=None,
    ):
        return OrderRequest(
            symbol=symbol,
            side=OrderSide(side),
            order_type=OrderType(order_type),
            quantity=Decimal(quantity),
            price=Decimal(price) if price else None,
            idempotency_key=str(uuid.uuid4()),
            strategy_id="test_strategy",
        )
    return _make


@pytest.fixture
def base_portfolio():
    from coindcx_algo.sdk.models import Portfolio
    return Portfolio(
        strategy_id="test_strategy",
        base_currency="USDT",
        balances={"USDT": Decimal("10000")},
        peak_equity=Decimal("10000"),
    )


@pytest.fixture
def default_risk_config():
    from coindcx_algo.risk.engine import StrategyRiskConfig
    return StrategyRiskConfig(
        strategy_id="test_strategy",
        max_position_size_usd=Decimal("5000"),
        max_order_size_usd=Decimal("3000"),
        min_order_size_usd=Decimal("10"),
        max_drawdown_pct=Decimal("20"),
        max_daily_loss_pct=Decimal("10"),
        max_open_orders=20,
        kill_switch_active=False,
    )


@pytest.fixture
def default_risk_state():
    from coindcx_algo.risk.engine import StrategyRiskState
    return StrategyRiskState(
        strategy_id="test_strategy",
        session_start_equity=Decimal("10000"),
        session_high_equity=Decimal("10000"),
        daily_start_equity=Decimal("10000"),
        daily_realized_pnl=Decimal("0"),
    )


# ═══════════════════════════════════════════════════════════
# SDK MODEL TESTS
# ═══════════════════════════════════════════════════════════

class TestBarModel:
    def test_bar_is_bullish(self, make_bar):
        bar = make_bar(open="50000", close="50500")
        assert bar.is_bullish is True

    def test_bar_is_bearish(self, make_bar):
        bar = make_bar(open="50500", close="50000")
        assert bar.is_bullish is False

    def test_bar_body_size(self, make_bar):
        bar = make_bar(open="50000", close="50500")
        assert bar.body_size == Decimal("500")

    def test_bar_range(self, make_bar):
        bar = make_bar(high="51000", low="49000")
        assert bar.range == Decimal("2000")


class TestPortfolioModel:
    def test_total_equity_no_positions(self, base_portfolio):
        assert base_portfolio.total_equity == Decimal("10000")

    def test_get_balance(self, base_portfolio):
        assert base_portfolio.get_balance("USDT") == Decimal("10000")
        assert base_portfolio.get_balance("BTC") == Decimal("0")

    def test_max_drawdown_at_peak(self, base_portfolio):
        base_portfolio.peak_equity = Decimal("10000")
        # No drawdown when at peak
        assert base_portfolio.max_drawdown == Decimal("0")

    def test_max_drawdown_calculation(self, base_portfolio):
        base_portfolio.peak_equity = Decimal("12000")
        base_portfolio.balances["USDT"] = Decimal("9600")
        # DD = (12000 - 9600) / 12000 * 100 = 20%
        assert base_portfolio.max_drawdown == Decimal("20")


class TestOrderModel:
    def test_order_is_active_when_open(self):
        from coindcx_algo.sdk.models import Order, OrderSide, OrderType, OrderStatus, MarketType
        order = Order(
            order_id="test",
            client_order_id="client_test",
            exchange_order_id="ex_test",
            symbol="BTCUSDT",
            side=OrderSide.BUY,
            order_type=OrderType.MARKET,
            market_type=MarketType.SPOT,
            quantity=Decimal("0.001"),
            price=None,
            stop_price=None,
            status=OrderStatus.OPEN,
        )
        assert order.is_active is True

    def test_order_not_active_when_filled(self):
        from coindcx_algo.sdk.models import Order, OrderSide, OrderType, OrderStatus, MarketType
        order = Order(
            order_id="test",
            client_order_id="client_test",
            exchange_order_id="ex_test",
            symbol="BTCUSDT",
            side=OrderSide.BUY,
            order_type=OrderType.MARKET,
            market_type=MarketType.SPOT,
            quantity=Decimal("0.001"),
            price=None,
            stop_price=None,
            status=OrderStatus.FILLED,
            filled_quantity=Decimal("0.001"),
        )
        assert order.is_active is False

    def test_remaining_quantity(self):
        from coindcx_algo.sdk.models import Order, OrderSide, OrderType, OrderStatus, MarketType
        order = Order(
            order_id="test",
            client_order_id="c",
            exchange_order_id=None,
            symbol="BTCUSDT",
            side=OrderSide.BUY,
            order_type=OrderType.LIMIT,
            market_type=MarketType.SPOT,
            quantity=Decimal("1.0"),
            price=Decimal("50000"),
            stop_price=None,
            status=OrderStatus.PARTIALLY_FILLED,
            filled_quantity=Decimal("0.6"),
        )
        assert order.remaining_quantity == Decimal("0.4")


# ═══════════════════════════════════════════════════════════
# INDICATOR TESTS
# ═══════════════════════════════════════════════════════════

class TestIndicators:
    from coindcx_algo.sdk.strategy import IndicatorLibrary
    ind = IndicatorLibrary()

    def test_sma_basic(self):
        from coindcx_algo.sdk.strategy import IndicatorLibrary
        ind = IndicatorLibrary()
        values = [Decimal(str(i)) for i in range(1, 6)]  # [1, 2, 3, 4, 5]
        result = ind.sma(values, 3)
        assert len(result) == 3
        assert abs(result[0] - 2.0) < 0.0001
        assert abs(result[-1] - 4.0) < 0.0001

    def test_ema_length(self):
        from coindcx_algo.sdk.strategy import IndicatorLibrary
        ind = IndicatorLibrary()
        values = [Decimal(str(i * 1000)) for i in range(1, 31)]
        result = ind.ema(values, 10)
        assert len(result) == 21   # 30 - 10 + 1

    def test_rsi_range(self):
        from coindcx_algo.sdk.strategy import IndicatorLibrary
        ind = IndicatorLibrary()
        import random
        random.seed(42)
        values = [Decimal(str(50000 + random.uniform(-1000, 1000))) for _ in range(50)]
        result = ind.rsi(values, 14)
        assert all(0 <= r <= 100 for r in result)

    def test_bollinger_upper_above_lower(self):
        from coindcx_algo.sdk.strategy import IndicatorLibrary
        ind = IndicatorLibrary()
        values = [Decimal(str(50000 + i * 10)) for i in range(30)]
        upper, middle, lower = ind.bollinger_bands(values, 20, 2.0)
        assert all(u > m > l for u, m, l in zip(upper, middle, lower))

    def test_vwap_between_high_low(self):
        from coindcx_algo.sdk.strategy import IndicatorLibrary
        ind = IndicatorLibrary()
        highs = [Decimal("51000")] * 10
        lows = [Decimal("49000")] * 10
        closes = [Decimal("50000")] * 10
        volumes = [Decimal("100")] * 10
        result = ind.vwap(highs, lows, closes, volumes)
        assert all(49000 <= v <= 51000 for v in result)


# ═══════════════════════════════════════════════════════════
# RISK ENGINE TESTS
# ═══════════════════════════════════════════════════════════

class TestRiskEngine:
    def test_order_approved_normal_conditions(
        self, make_order_request, base_portfolio, default_risk_config, default_risk_state
    ):
        from coindcx_algo.risk.engine import RiskEngine
        engine = RiskEngine()
        request = make_order_request(quantity="0.001")
        result = engine.check_order(
            request=request,
            portfolio=base_portfolio,
            config=default_risk_config,
            state=default_risk_state,
            current_price=Decimal("50000"),
            open_order_count=0,
        )
        assert result.approved is True

    def test_kill_switch_blocks_all_orders(
        self, make_order_request, base_portfolio, default_risk_config, default_risk_state
    ):
        from coindcx_algo.risk.engine import RiskEngine, RiskViolation
        engine = RiskEngine()
        engine.activate_platform_kill_switch()
        request = make_order_request()
        result = engine.check_order(
            request=request,
            portfolio=base_portfolio,
            config=default_risk_config,
            state=default_risk_state,
            current_price=Decimal("50000"),
            open_order_count=0,
        )
        assert result.approved is False
        assert result.violation == RiskViolation.KILL_SWITCH_ACTIVE

    def test_order_too_small_rejected(
        self, make_order_request, base_portfolio, default_risk_config, default_risk_state
    ):
        from coindcx_algo.risk.engine import RiskEngine, RiskViolation
        engine = RiskEngine()
        # qty=0.0001 * price=50000 = $5 < $10 minimum
        request = make_order_request(quantity="0.0001")
        result = engine.check_order(
            request=request,
            portfolio=base_portfolio,
            config=default_risk_config,
            state=default_risk_state,
            current_price=Decimal("50000"),
            open_order_count=0,
        )
        assert result.approved is False
        assert result.violation == RiskViolation.ORDER_TOO_SMALL

    def test_order_too_large_rejected(
        self, make_order_request, base_portfolio, default_risk_config, default_risk_state
    ):
        from coindcx_algo.risk.engine import RiskEngine, RiskViolation
        engine = RiskEngine()
        # qty=1.0 * price=50000 = $50,000 > $3,000 max
        request = make_order_request(quantity="1.0")
        result = engine.check_order(
            request=request,
            portfolio=base_portfolio,
            config=default_risk_config,
            state=default_risk_state,
            current_price=Decimal("50000"),
            open_order_count=0,
        )
        assert result.approved is False
        assert result.violation == RiskViolation.ORDER_TOO_LARGE
        assert result.suggested_quantity is not None

    def test_insufficient_balance_rejected(
        self, make_order_request, base_portfolio, default_risk_config, default_risk_state
    ):
        from coindcx_algo.risk.engine import RiskEngine, RiskViolation
        engine = RiskEngine()
        base_portfolio.balances["USDT"] = Decimal("50")  # Only $50
        request = make_order_request(quantity="0.01")    # $500 order
        result = engine.check_order(
            request=request,
            portfolio=base_portfolio,
            config=default_risk_config,
            state=default_risk_state,
            current_price=Decimal("50000"),
            open_order_count=0,
        )
        assert result.approved is False
        assert result.violation == RiskViolation.INSUFFICIENT_BALANCE

    def test_max_drawdown_exceeded(
        self, make_order_request, base_portfolio, default_risk_config, default_risk_state
    ):
        from coindcx_algo.risk.engine import RiskEngine, RiskViolation
        engine = RiskEngine()
        # Simulate 25% drawdown (above 20% limit)
        default_risk_state.session_high_equity = Decimal("10000")
        base_portfolio.balances["USDT"] = Decimal("7500")  # 25% down
        request = make_order_request(quantity="0.001")
        result = engine.check_order(
            request=request,
            portfolio=base_portfolio,
            config=default_risk_config,
            state=default_risk_state,
            current_price=Decimal("50000"),
            open_order_count=0,
        )
        assert result.approved is False
        assert result.violation == RiskViolation.MAX_DRAWDOWN_EXCEEDED

    def test_max_open_orders_exceeded(
        self, make_order_request, base_portfolio, default_risk_config, default_risk_state
    ):
        from coindcx_algo.risk.engine import RiskEngine, RiskViolation
        engine = RiskEngine()
        default_risk_config.max_open_orders = 5
        request = make_order_request(quantity="0.001")
        result = engine.check_order(
            request=request,
            portfolio=base_portfolio,
            config=default_risk_config,
            state=default_risk_state,
            current_price=Decimal("50000"),
            open_order_count=5,  # At limit
        )
        assert result.approved is False
        assert result.violation == RiskViolation.MAX_OPEN_ORDERS_EXCEEDED

    def test_symbol_not_in_allowlist(
        self, make_order_request, base_portfolio, default_risk_config, default_risk_state
    ):
        from coindcx_algo.risk.engine import RiskEngine, RiskViolation
        engine = RiskEngine()
        default_risk_config.allowed_symbols = ["ETHUSDT"]  # Only ETH allowed
        request = make_order_request(symbol="BTCUSDT", quantity="0.001")
        result = engine.check_order(
            request=request,
            portfolio=base_portfolio,
            config=default_risk_config,
            state=default_risk_state,
            current_price=Decimal("50000"),
            open_order_count=0,
        )
        assert result.approved is False
        assert result.violation == RiskViolation.SYMBOL_NOT_ALLOWED


# ═══════════════════════════════════════════════════════════
# BACKTEST ENGINE TESTS
# ═══════════════════════════════════════════════════════════

class TestBacktestEngine:
    def _make_bars(self, n=100, base_price=50000):
        from coindcx_algo.sdk.models import Bar
        bars = []
        price = Decimal(str(base_price))
        for i in range(n):
            # Simple oscillating price
            change = Decimal("100") if i % 2 == 0 else Decimal("-100")
            price += change
            bars.append(Bar(
                symbol="BTCUSDT",
                open=price,
                high=price + Decimal("200"),
                low=price - Decimal("200"),
                close=price + Decimal("50"),
                volume=Decimal("50"),
                timestamp_ms=int(time.time() * 1000) + i * 3600000,
                resolution="1h",
            ))
        return bars

    @pytest.mark.asyncio
    async def test_backtest_runs_to_completion(self):
        from coindcx_algo.backtesting.engine import BacktestEngine, BacktestConfig
        from coindcx_algo.sdk.examples import MACrossoverStrategy

        bars = self._make_bars(100)
        config = BacktestConfig(
            strategy_class=MACrossoverStrategy,
            strategy_params={"fast_period": 5, "slow_period": 10, "quantity": "0.001"},
            symbol="BTCUSDT",
            resolution="1h",
            start_ms=bars[0].timestamp_ms,
            end_ms=bars[-1].timestamp_ms,
            initial_capital=Decimal("10000"),
            simulate_latency=False,
        )
        engine = BacktestEngine(config)
        result = await engine.run(bars)

        assert result.bars_processed == 100
        assert result.metrics is not None
        assert result.run_id is not None
        assert isinstance(result.equity_curve, list)

    @pytest.mark.asyncio
    async def test_backtest_equity_curve_length(self):
        from coindcx_algo.backtesting.engine import BacktestEngine, BacktestConfig
        from coindcx_algo.sdk.examples import MACrossoverStrategy

        bars = self._make_bars(50)
        config = BacktestConfig(
            strategy_class=MACrossoverStrategy,
            strategy_params={"fast_period": 5, "slow_period": 10},
            symbol="BTCUSDT",
            resolution="1h",
            start_ms=bars[0].timestamp_ms,
            end_ms=bars[-1].timestamp_ms,
            initial_capital=Decimal("10000"),
            simulate_latency=False,
        )
        engine = BacktestEngine(config)
        result = await engine.run(bars)
        assert len(result.equity_curve) == 50

    @pytest.mark.asyncio
    async def test_no_orders_without_signal(self):
        """Strategy with very long periods shouldn't trade on short bar series."""
        from coindcx_algo.backtesting.engine import BacktestEngine, BacktestConfig
        from coindcx_algo.sdk.examples import MACrossoverStrategy

        bars = self._make_bars(20)  # Only 20 bars, need 30 for slow MA
        config = BacktestConfig(
            strategy_class=MACrossoverStrategy,
            strategy_params={"fast_period": 10, "slow_period": 30},
            symbol="BTCUSDT",
            resolution="1h",
            start_ms=bars[0].timestamp_ms,
            end_ms=bars[-1].timestamp_ms,
            initial_capital=Decimal("10000"),
            simulate_latency=False,
        )
        engine = BacktestEngine(config)
        result = await engine.run(bars)
        assert len(result.trades) == 0  # No trades possible without enough bars

    def test_fill_simulator_market_order(self, make_bar):
        from coindcx_algo.backtesting.engine import FillSimulator, BacktestConfig
        from coindcx_algo.sdk.examples import MACrossoverStrategy
        from coindcx_algo.sdk.models import OrderSide, OrderType, MarketType
        from coindcx_algo.sdk.models import OrderRequest

        config = BacktestConfig(
            strategy_class=MACrossoverStrategy,
            strategy_params={},
            symbol="BTCUSDT",
            resolution="1h",
            start_ms=0,
            end_ms=0,
            slippage_pct=Decimal("0.001"),
            use_spread_slippage=False,
        )
        sim = FillSimulator(config)
        bar = make_bar(open="50000", high="51000", low="49000")
        request = OrderRequest(
            symbol="BTCUSDT",
            side=OrderSide.BUY,
            order_type=OrderType.MARKET,
            quantity=Decimal("0.001"),
        )
        fill_price, fill_qty = sim.simulate_market_fill(request, bar)
        # Fill price should be above open due to slippage
        assert fill_price > Decimal("50000")
        assert fill_qty == Decimal("0.001")

    def test_fill_simulator_limit_order_filled(self, make_bar):
        from coindcx_algo.backtesting.engine import FillSimulator, BacktestConfig
        from coindcx_algo.sdk.examples import MACrossoverStrategy
        from coindcx_algo.sdk.models import OrderSide, OrderType
        from coindcx_algo.sdk.models import OrderRequest

        config = BacktestConfig(
            strategy_class=MACrossoverStrategy,
            strategy_params={},
            symbol="BTCUSDT",
            resolution="1h",
            start_ms=0,
            end_ms=0,
        )
        sim = FillSimulator(config)
        bar = make_bar(low="49000", high="51000")
        request = OrderRequest(
            symbol="BTCUSDT",
            side=OrderSide.BUY,
            order_type=OrderType.LIMIT,
            quantity=Decimal("0.001"),
            price=Decimal("49500"),  # Within bar range
        )
        result = sim.simulate_limit_fill(request, bar)
        assert result is not None
        fill_price, fill_qty = result
        assert fill_price == Decimal("49500")

    def test_fill_simulator_limit_order_not_filled(self, make_bar):
        from coindcx_algo.backtesting.engine import FillSimulator, BacktestConfig
        from coindcx_algo.sdk.examples import MACrossoverStrategy
        from coindcx_algo.sdk.models import OrderSide, OrderType
        from coindcx_algo.sdk.models import OrderRequest

        config = BacktestConfig(
            strategy_class=MACrossoverStrategy,
            strategy_params={},
            symbol="BTCUSDT",
            resolution="1h",
            start_ms=0,
            end_ms=0,
        )
        sim = FillSimulator(config)
        bar = make_bar(low="49000", high="51000")
        request = OrderRequest(
            symbol="BTCUSDT",
            side=OrderSide.BUY,
            order_type=OrderType.LIMIT,
            quantity=Decimal("0.001"),
            price=Decimal("48000"),  # Below bar low — not filled
        )
        result = sim.simulate_limit_fill(request, bar)
        assert result is None


# ═══════════════════════════════════════════════════════════
# ANALYTICS TESTS
# ═══════════════════════════════════════════════════════════

class TestMetricsComputer:
    def _make_equity_curve(self, n=100, start=10000, drift=0.001, volatility=0.02):
        """Simulate a random-walk equity curve."""
        import random
        random.seed(42)
        equity = start
        curve = []
        base_ms = int(time.time() * 1000)
        for i in range(n):
            change = equity * (drift + random.gauss(0, volatility))
            equity = max(equity + change, 1.0)
            curve.append((base_ms + i * 86_400_000, equity))
        return curve

    def test_sharpe_positive_for_profitable_strategy(self):
        from coindcx_algo.analytics.metrics import MetricsComputer
        computer = MetricsComputer()
        # Consistently growing equity → positive Sharpe
        curve = [(int(time.time() * 1000) + i * 86_400_000, 10000 + i * 100)
                 for i in range(100)]
        metrics = computer.compute(
            strategy_id="test",
            period_label="100d",
            equity_curve=curve,
            trades=[],
            period_days=100.0,
        )
        assert metrics.sharpe_ratio > 0

    def test_max_drawdown_computation(self):
        from coindcx_algo.analytics.metrics import MetricsComputer
        computer = MetricsComputer()
        # Equity goes up then crashes 50%
        base = int(time.time() * 1000)
        curve = [(base + i * 3600000, float(10000 + i * 100)) for i in range(50)]  # Up
        curve += [(base + (50 + i) * 3600000, float(14900 - i * 300)) for i in range(17)]  # 50% down
        metrics = computer.compute(
            strategy_id="test",
            period_label="test",
            equity_curve=curve,
            trades=[],
            period_days=67.0,
        )
        assert metrics.max_drawdown_pct > 0

    def test_monthly_returns_bucketing(self):
        from coindcx_algo.analytics.metrics import MetricsComputer
        from datetime import datetime, timezone
        computer = MetricsComputer()

        jan_start = int(datetime(2024, 1, 1, tzinfo=timezone.utc).timestamp() * 1000)
        feb_start = int(datetime(2024, 2, 1, tzinfo=timezone.utc).timestamp() * 1000)
        mar_start = int(datetime(2024, 3, 1, tzinfo=timezone.utc).timestamp() * 1000)

        curve = [
            (jan_start, 10000.0),
            (jan_start + 1000000, 10500.0),
            (feb_start, 10500.0),
            (feb_start + 1000000, 11000.0),
            (mar_start, 11000.0),
            (mar_start + 1000000, 10800.0),
        ]
        metrics = computer.compute(
            strategy_id="test",
            period_label="3m",
            equity_curve=curve,
            trades=[],
            period_days=60.0,
        )
        assert "2024-01" in metrics.monthly_returns
        assert "2024-02" in metrics.monthly_returns


# ═══════════════════════════════════════════════════════════
# COPY TRADING TESTS
# ═══════════════════════════════════════════════════════════

class TestOrderScaler:
    def test_proportional_scaling(self):
        from coindcx_algo.marketplace.copy_trading import OrderScaler, Subscription, CopyMode
        scaler = OrderScaler()
        sub = Subscription(
            subscription_id="s1",
            subscriber_user_id="u1",
            master_strategy_id="m1",
            copy_mode=CopyMode.PROPORTIONAL,
            allocated_capital_usdt=Decimal("5000"),
            master_capital_reference_usdt=Decimal("10000"),  # 50% ratio
        )
        qty = scaler.scale_quantity(
            master_qty=Decimal("1.0"),
            master_price=Decimal("50000"),
            subscription=sub,
        )
        assert qty == Decimal("0.50000000")

    def test_fixed_lot_returns_fixed_qty(self):
        from coindcx_algo.marketplace.copy_trading import OrderScaler, Subscription, CopyMode
        scaler = OrderScaler()
        sub = Subscription(
            subscription_id="s2",
            subscriber_user_id="u2",
            master_strategy_id="m1",
            copy_mode=CopyMode.FIXED_LOT,
            allocated_capital_usdt=Decimal("5000"),
            master_capital_reference_usdt=Decimal("10000"),
            fixed_lot_qty=Decimal("0.01"),
        )
        qty = scaler.scale_quantity(
            master_qty=Decimal("1.0"),
            master_price=Decimal("50000"),
            subscription=sub,
        )
        assert qty == Decimal("0.01")

    def test_fixed_notional_scales_by_price(self):
        from coindcx_algo.marketplace.copy_trading import OrderScaler, Subscription, CopyMode
        scaler = OrderScaler()
        sub = Subscription(
            subscription_id="s3",
            subscriber_user_id="u3",
            master_strategy_id="m1",
            copy_mode=CopyMode.FIXED_NOTIONAL,
            allocated_capital_usdt=Decimal("5000"),
            master_capital_reference_usdt=Decimal("10000"),
            fixed_notional_usdt=Decimal("500"),
        )
        qty = scaler.scale_quantity(
            master_qty=Decimal("1.0"),
            master_price=Decimal("50000"),
            subscription=sub,
        )
        # 500 / 50000 = 0.01
        assert qty is not None
        assert abs(qty - Decimal("0.01")) < Decimal("0.0001")

    def test_too_small_returns_none(self):
        from coindcx_algo.marketplace.copy_trading import OrderScaler, Subscription, CopyMode
        scaler = OrderScaler()
        sub = Subscription(
            subscription_id="s4",
            subscriber_user_id="u4",
            master_strategy_id="m1",
            copy_mode=CopyMode.PROPORTIONAL,
            allocated_capital_usdt=Decimal("1"),   # Very small capital
            master_capital_reference_usdt=Decimal("10000"),
        )
        qty = scaler.scale_quantity(
            master_qty=Decimal("0.001"),
            master_price=Decimal("50000"),
            subscription=sub,
        )
        assert qty is None  # $0.005 < $10 minimum


# ═══════════════════════════════════════════════════════════
# STRATEGY LIFECYCLE TESTS
# ═══════════════════════════════════════════════════════════

class TestStrategyBase:
    def _build_strategy(self, strategy_class, params=None):
        from coindcx_algo.sdk.models import Portfolio
        from coindcx_algo.sdk.strategy import StrategyContext

        portfolio = Portfolio(
            strategy_id="test",
            base_currency="USDT",
            balances={"USDT": Decimal("10000")},
        )
        context = StrategyContext(
            strategy_id="test",
            user_id="user",
            mode="backtest",
            exchange="simulation",
        )
        order_cb = AsyncMock()
        cancel_cb = AsyncMock()

        instance = strategy_class(
            strategy_id="test",
            params=params or {},
            context=context,
            order_callback=order_cb,
            cancel_callback=cancel_cb,
            portfolio=portfolio,
        )
        return instance, order_cb, cancel_cb

    def test_ma_crossover_on_start(self):
        from coindcx_algo.sdk.examples import MACrossoverStrategy
        strategy, _, _ = self._build_strategy(
            MACrossoverStrategy,
            {"fast_period": 5, "slow_period": 15, "quantity": "0.001"},
        )
        strategy.on_start()
        assert strategy.fast_period == 5
        assert strategy.slow_period == 15

    def test_strategy_has_no_position_initially(self):
        from coindcx_algo.sdk.examples import MACrossoverStrategy
        strategy, _, _ = self._build_strategy(MACrossoverStrategy)
        assert strategy.has_position("BTCUSDT") is False

    def test_strategy_equity_reflects_portfolio(self):
        from coindcx_algo.sdk.examples import MACrossoverStrategy
        strategy, _, _ = self._build_strategy(MACrossoverStrategy)
        assert strategy.equity() == Decimal("10000")

    def test_bar_buffer_fills_on_handle_bar(self, make_bar):
        from coindcx_algo.sdk.examples import MACrossoverStrategy
        strategy, _, _ = self._build_strategy(
            MACrossoverStrategy, {"fast_period": 3, "slow_period": 5}
        )
        strategy.on_start()
        bar = make_bar()
        strategy._handle_bar(bar)
        assert len(strategy.bars) == 1

    def test_bar_buffer_respects_maxlen(self, make_bar):
        from coindcx_algo.sdk.examples import MACrossoverStrategy
        strategy, _, _ = self._build_strategy(
            MACrossoverStrategy,
            {"fast_period": 3, "slow_period": 5, "bar_buffer_size": 10},
        )
        strategy.on_start()
        for i in range(20):
            strategy._handle_bar(make_bar(close=str(50000 + i * 10)))
        assert len(strategy.bars) == 10  # capped at buffer size


# ═══════════════════════════════════════════════════════════
# INTEGRATION: OMS + Risk engine
# ═══════════════════════════════════════════════════════════

class TestOMSIntegration:
    @pytest.mark.asyncio
    async def test_oms_rejects_order_when_risk_fails(
        self, base_portfolio, default_risk_config, default_risk_state
    ):
        """OMS should return a rejected order (not raise) when risk check fails."""
        from coindcx_algo.engine.oms.order_manager import OrderManagementSystem
        from coindcx_algo.sdk.models import OrderRequest, OrderSide, OrderType, OrderStatus

        mock_adapter = AsyncMock()
        mock_adapter.get_ticker.return_value = MagicMock(price=Decimal("50000"))

        oms = OrderManagementSystem(
            strategy_id="test",
            user_id="user",
            exchange_adapter=mock_adapter,
            portfolio=base_portfolio,
            risk_config=default_risk_config,
            risk_state=default_risk_state,
            dry_run=False,
        )

        # Order that costs $50,000 (way above limits)
        request = OrderRequest(
            symbol="BTCUSDT",
            side=OrderSide.BUY,
            order_type=OrderType.MARKET,
            quantity=Decimal("1.0"),   # $50,000 — exceeds all limits
            idempotency_key=str(uuid.uuid4()),
            strategy_id="test",
        )
        order = await oms.submit_order(request)
        assert order.status == OrderStatus.REJECTED

    @pytest.mark.asyncio
    async def test_oms_blocks_duplicate_idempotency_key(
        self, base_portfolio, default_risk_config, default_risk_state
    ):
        """Same idempotency key submitted twice should only process once."""
        from coindcx_algo.engine.oms.order_manager import OrderManagementSystem
        from coindcx_algo.sdk.models import OrderRequest, OrderSide, OrderType, Order, OrderStatus

        mock_adapter = AsyncMock()
        mock_adapter.get_ticker.return_value = MagicMock(price=Decimal("50000"))

        # Mock adapter returns a filled order
        mock_exchange_order = MagicMock(spec=Order)
        mock_exchange_order.exchange_order_id = "ex123"
        mock_exchange_order.status = OrderStatus.OPEN
        mock_adapter.place_order.return_value = mock_exchange_order

        oms = OrderManagementSystem(
            strategy_id="test",
            user_id="user",
            exchange_adapter=mock_adapter,
            portfolio=base_portfolio,
            risk_config=default_risk_config,
            risk_state=default_risk_state,
            dry_run=False,
        )

        ikey = str(uuid.uuid4())
        request = OrderRequest(
            symbol="BTCUSDT",
            side=OrderSide.BUY,
            order_type=OrderType.MARKET,
            quantity=Decimal("0.001"),
            idempotency_key=ikey,
            strategy_id="test",
        )

        order1 = await oms.submit_order(request)
        # Second submit with same key should not call exchange again
        with pytest.raises(ValueError, match="Duplicate"):
            request2 = OrderRequest(
                symbol="BTCUSDT",
                side=OrderSide.BUY,
                order_type=OrderType.MARKET,
                quantity=Decimal("0.001"),
                idempotency_key=ikey,  # Same key!
                strategy_id="test",
            )
            await oms.submit_order(request2)

        # Exchange should only be called once
        assert mock_adapter.place_order.call_count == 1
